// QC 조회 화면의 요청만 받아 은행연합회 탭에서 실행한다.
importScripts("creport.js");

const QC_PAGE = "https://tojidi-debug.github.io/doyaa1/QC/creport/";

async function handle(msg) {
  switch (msg && msg.type) {
    case "ping":
      return { ok: true };
    case "check":   // 없는 번호로 회사검색만 해서 로그인 여부를 본다
      return { ok: true, ...(await inTab("0000000000", "")) };
    case "query":
      if (!/^\d{10}$/.test(msg.biz) || !/^\d{8}$/.test(msg.inq)) throw new Error("입력값 오류");
      return { ok: true, ...(await inTab(msg.biz, msg.inq)) };
    case "openLogin":
      await ensureTab(true);
      return { ok: true };
    default:
      throw new Error("알 수 없는 요청");
  }
}

chrome.runtime.onMessageExternal.addListener((msg, sender, respond) => {
  if (!String(sender.url || "").startsWith(QC_PAGE)) {
    respond({ ok: false, error: "허용되지 않은 화면" });
    return false;
  }
  handle(msg).then(respond, (e) => respond({ ok: false, error: e.message }));
  return true;
});

// 확장 아이콘을 누르면 조회 화면을 연다(이미 열려 있으면 그 탭으로 간다).
chrome.action.onClicked.addListener(async () => {
  const [tab] = await chrome.tabs.query({ url: QC_PAGE + "*" });
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: QC_PAGE });
  }
});
