// 은행연합회 호출. 다른 도메인에서는 로그인 세션을 쓸 수 없으므로, 열려 있는 creport 탭 안에서 실행한다.
const CREPORT_HOME = "https://www.creport.co.kr/";
const CREPORT_TABS = ["https://www.creport.co.kr/*", "https://creport.co.kr/*"];
const 조회사유 = "009";

function waitComplete(tabId) {
  return new Promise((resolve, reject) => {
    const done = () => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); };
    const timer = setTimeout(() => { done(); reject(new Error("은행연합회 화면이 열리지 않습니다.")); }, 30000);
    const listener = (id, info) => { if (id === tabId && info.status === "complete") { done(); resolve(); } };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function ensureTab(active = false) {
  const tabs = await chrome.tabs.query({ url: CREPORT_TABS });
  if (tabs.length) {
    const tab = tabs.find((t) => t.status === "complete") || tabs[0];
    if (active) {
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return tab.id;
  }
  const tab = await chrome.tabs.create({ url: CREPORT_HOME, active });
  await waitComplete(tab.id);
  return tab.id;
}

// 탭 안에서 실행된다. 바깥 변수를 쓸 수 없다. inq가 비어 있으면 로그인 여부만 본다.
async function pageQuery(biz, inq, rsn) {
  const post = async (trxCd, params) => {
    const r = await fetch("/serviceEndpoint/httpService/request.json", {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json;charset=UTF-8" },
      body: JSON.stringify({ dma_headers: { trxCd, chlType: "CR", domainId: "CRP" }, dma_params: params }),
    });
    return r.json();
  };
  const needLogin = (o) => /login\s*session|session\s*(invalid|expired)|로그인|세션/i.test(JSON.stringify(o || {}).slice(0, 2000));
  let s;
  try {
    s = await post("CP0602R003", { searchGb: "002", searchWord: biz, pagingYn: "Y", pageNum: 1, pageCnt: "10" });
  } catch (e) {
    return { status: "login" };
  }
  if (needLogin(s)) return { status: "login" };
  if (!inq) return { status: "ready" };
  const c = ((s && s.SCP060201OutDto && s.SCP060201OutDto.cmpList) || []).find((x) => String(x.bizNo) === biz);
  if (!c) return { status: "none" };
  const q = await post("CP0603R001", {
    rlmnnoGb: "", bizNo: c.bizNo, corpNo: c.corpNo, cmpCd: c.cmpCd, cmpGb: "", cmpNm: c.cmpNm, infoYmd: "",
    crgrtInqRsn: rsn, loanInqNm: "[월보]업체별 월보 은행별 계정과목별 조회(잔액)", loanInqCd: "M002",
    inqYmd: inq, ceoNm: c.ceoNm, lastYmd: "",
  });
  if (q && q.SCP060301OutDto) return { status: "ok", c, dto: q.SCP060301OutDto };
  return { status: needLogin(q) ? "login" : "empty", c };
}

async function inTab(biz, inq) {
  const tabId = await ensureTab();
  const [res] = await chrome.scripting.executeScript({
    target: { tabId }, world: "MAIN", func: pageQuery, args: [biz, inq, 조회사유],
  });
  if (res.error) throw new Error(res.error.message || "조회 실패");
  return res.result;
}
