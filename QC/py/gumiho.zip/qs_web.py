"""[품감] 개별선정 — GitHub(정적) 사이트의 「서버 대신」(브라우저 Pyodide, 2026-10-15).

개발서버 api/v1/qc_sample.py · finstmt(회사 찾기·발행 이력) · qc.py(조서) 가 하던 일을 **같은 파이썬 코드**(gumiho.zip — 서버 소스 그대로)로
브라우저 안에서 한다. 바뀌는 것은 둘뿐이다:
  · 전자공시 → 구글 Apps Script 중계(httpx 대역, py/httpx.py)
  · 사내 재무 DB → 그 결산기 감사보고서 원문의 재무제표(integrations/external/dart_statements.py) — 사용자 지정 2026-10-15
공유 자료(일정·명부·서식·관리자 조정)는 화면(js/api.js)이 중계에서 받아 글로 넘겨준다 — 여기서는 읽고 계산만 한다.
사전제출자료·대사 자료는 이 브라우저 메모리에서 읽고 버린다(어디에도 보내지 않음).

입구는 `call(이름, 인자 JSON)` 하나 — 돌려주는 것도 JSON 글. 오류는 {"error": {"status", "detail"}}.
"""
from __future__ import annotations

import asyncio
import base64
import copy
import io
import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx

CACHE = Path("/tmp/dart")
KEY = "relay"                     # 인증키 자리 — 중계가 진짜 키로 바꿔 붙인다(여기에는 키가 없다)
KINDS = {"full": "상근용", "part": "비상근용"}
_CORPS: dict[str, list[dict[str, str]]] | None = None


class WebError(Exception):
    def __init__(self, status: int, detail: Any) -> None:
        super().__init__(str(detail))
        self.status, self.detail = status, detail


def _b(s: str) -> bytes:
    return base64.b64decode(s or "")


def _s(b: bytes) -> str:
    return base64.b64encode(b).decode()


def _today() -> date:
    return (datetime.utcnow() + timedelta(hours=9)).date()


async def _pdf_text(data: bytes) -> str:
    from pypdf import PdfReader
    return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(data)).pages)


async def _corp_index(client: Any, key: str, cache_dir: Path) -> dict[str, list[dict[str, str]]]:
    """전자공시 고유번호 목록 — 20MB zip 을 중계로 받지 않고, 꾸러미의 qc/static/corps.json(만들 때의 목록)을 쓴다."""
    global _CORPS
    if _CORPS is None:
        from gumiho.integrations.external import dart
        from pyodide.http import pyfetch  # type: ignore[import-not-found]
        rows = await (await pyfetch("qc/static/corps.json")).json()
        idx: dict[str, list[dict[str, str]]] = {}
        for code, name, stock in rows:
            idx.setdefault(dart.normalize_name(name), []).append({"corp_code": code, "corp_name": name, "stock_code": stock or ""})
        _CORPS = idx
    return _CORPS


def init(relay: str) -> str:
    httpx.RELAY = relay
    from gumiho.integrations.external import dart
    from gumiho.services import attachment_text
    attachment_text._pdf_text = _pdf_text          # pdftotext(프로그램) 대신 pypdf
    dart._corp_index = _corp_index
    return "ok"


# ── 사전제출자료 · 대사 ───────────────────────────────────────────────────

def parse(name: str, b64: str, fy: int | None = None) -> dict[str, Any]:
    from gumiho.services import qc_sample
    try:
        return qc_sample.parse_presubmit(_b(b64), fy=fy, name=name)
    except qc_sample.PresubmitError as exc:
        raise WebError(422, str(exc)) from exc


async def reconcile(files: list[dict[str, str]], fy: int | None = None) -> dict[str, Any]:
    from gumiho.services import attachment_text, qc_sample, qc_sample_checks, qc_sample_docs
    books = [(f["name"], _b(f["b64"])) for f in files if f["name"].lower().endswith((".xlsx", ".xlsm", ".xls"))]
    others = [(f["name"], _b(f["b64"])) for f in files if f["name"].lower().endswith(qc_sample_docs.DOC_SUFFIXES)]
    result, summary = None, []
    if books:
        try:
            result, summary = qc_sample.parse_many(books, fy=fy)
        except qc_sample.PresubmitError as exc:
            raise WebError(422, str(exc)) from exc
    names: list[str] = []
    if result:
        letter = result["roles"].get("company")
        names = [str(r["values"].get(letter) or "") for r in result["rows"]] if letter else []
    docs = []
    for name, data in others:
        row: dict[str, Any] = {"name": name, "kind": "문서"}
        try:
            text = await qc_sample_docs.read_text(data, name)
        except (attachment_text.AttachmentTextError, Exception) as exc:  # noqa: BLE001
            row.update(error=str(exc)); summary.append(row); continue
        f = qc_sample_docs.facts(text)
        company, hits = qc_sample_docs.best_company(text, names)
        row.update(chars=len(text), facts=f, company=company, hits=hits)
        summary.append(row)
        docs.append({"name": name, "company": company, "facts": f})
    if result and docs:
        parsed = {"s23": result, **result["others"]}
        result["checks"] = qc_sample_checks.run(parsed, fy=fy or result["checks"]["fy"], docs=docs)
    return {"files": summary, "result": result, "message": "" if result else "사전제출자료(엑셀)가 없어 문서 요약만 보여 드립니다."}


_INTERNAL = {"report_date", "collect_date", "reviewer", "partner_name", "partner_years_diff", "timely_mark",
             "consolidated", "submit_order", "partner_alias", "years_step", "firm_years_step"}


async def other(pre: dict[str, str], files: list[dict[str, str]], fy: int | None = None) -> dict[str, Any]:
    """기타 대사 — 서버 compare 는 문서 글을 asyncio.run 으로 읽는다. 브라우저는 이미 이벤트 루프 안이라 글을 먼저 읽어 두고 넘긴다."""
    from gumiho.services import qc_sample, qc_sample_docs, qc_sample_other
    try:
        parsed = qc_sample.parse_presubmit(_b(pre["b64"]), fy=fy, name=pre["name"])
    except qc_sample.PresubmitError as exc:
        raise WebError(422, str(exc)) from exc
    blobs = [(f["name"], _b(f["b64"])) for f in files]
    texts: dict[str, str] = {}
    for name, raw in blobs:
        if name.lower().endswith((".pdf", ".hwpx", ".hwp", ".docx")):
            try:
                texts[name] = await qc_sample_docs.read_text(raw, name)
            except Exception:  # noqa: BLE001
                texts[name] = ""

    async def cached(raw: bytes, name: str) -> str:
        return texts.get(name, "")

    def run_now(coro: Any) -> Any:
        try:
            coro.send(None)
        except StopIteration as stop:
            return stop.value
        raise RuntimeError("문서 읽기를 끝내지 못했습니다.")

    keep = (qc_sample_docs.read_text, qc_sample_other._in_loop, asyncio.run)
    qc_sample_docs.read_text, qc_sample_other._in_loop, asyncio.run = cached, (lambda: False), run_now
    try:
        ch = parsed["checks"]
        result = qc_sample_other.compare(parsed, blobs, fy=fy or ch["fy"])
    finally:
        qc_sample_docs.read_text, qc_sample_other._in_loop, asyncio.run = keep
    return {"fy": ch["fy"], "presubmit": {"name": pre["name"], "sheet": parsed["sheet"], "rows": len(parsed["rows"]),
                                          "others": [o["sheet"] for o in parsed["others"].values()]},
            "internal": [i for i in ch["items"] if i["code"] in _INTERNAL],
            "internal_ok": [i for i in ch["ok"] if i["code"] in _INTERNAL], **result}


# ── 품감 일정 · 명부 (원본은 중계의 공유 자료 — 화면이 글로 넘겨준다) ─────────────────

def schedule_view(xlsx_b64: str, settings: dict[str, Any]) -> dict[str, Any]:
    from gumiho.services import qc_schedule
    meta = settings.get("schedule") or {}
    if not xlsx_b64:
        return {"ready": False, "meta": meta}
    try:
        out = qc_schedule.parse_schedule(_b(xlsx_b64))
    except qc_schedule.ScheduleError as exc:
        raise WebError(422, str(exc)) from exc
    qc_schedule.apply_overrides(out, settings.get("firm_overrides") or {}, settings.get("meeting_people") or {})
    out.pop("outsiders", None)
    out["adjust"] = {"firm_overrides": settings.get("firm_overrides") or {}, "meeting_people": settings.get("meeting_people") or {}}
    out["history"] = qc_schedule.year_history(settings.get("history") or [], _today().year)
    return {"ready": True, **out, "meta": meta}


def schedule_check(xlsx_b64: str) -> dict[str, Any]:
    from gumiho.services import qc_schedule
    try:
        out = qc_schedule.parse_schedule(_b(xlsx_b64))
    except qc_schedule.ScheduleError as exc:
        raise WebError(422, str(exc)) from exc
    return {"ok": True, "staff": len(out["staff"]), "events": len(out["events"]), "firms": len(out["firms"])}


def holidays(start: str, end: str) -> dict[str, str]:
    from gumiho.services import qc_schedule
    a, b = date.fromisoformat(start), date.fromisoformat(end)
    if (b - a).days > 800 or b < a:
        raise WebError(422, "기간을 확인해 주세요(2년 이내).")
    return qc_schedule.holidays_between(a, b)


def _firm_now(xlsx_b64: str, firm: str, overrides: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    from gumiho.services import qc_schedule
    if not xlsx_b64:
        raise WebError(409, "일정 엑셀을 먼저 올려 주세요.")
    raw = qc_schedule.parse_schedule(_b(xlsx_b64))
    eff = qc_schedule.apply_overrides(copy.deepcopy(raw), overrides, {})
    pick = lambda out: next((f for f in out.get("firms") or [] if f.get("firm") == firm), None)  # noqa: E731
    orig, cur = pick(raw), pick(eff)
    if not orig or not cur:
        raise WebError(404, f"일정 엑셀에 없는 회계법인입니다: {firm}")
    return orig, cur


def _log(st: dict[str, Any], firm: str, changes: list[dict[str, Any]]) -> None:
    from gumiho.services import qc_schedule
    today = _today().isoformat()
    st["history"] = qc_schedule.year_history(st.get("history") or [], int(today[:4])) + [{"at": today, "firm": firm, **c} for c in changes]


def schedule_firm(xlsx_b64: str, settings: dict[str, Any], body: dict[str, Any], clear: bool = False) -> dict[str, Any]:
    """관리자 — 회계법인 일정·인원 조정(clear 면 되돌리기). {settings(새), result} — 화면이 settings 를 중계에 저장한다."""
    from gumiho.services import qc_schedule
    st = copy.deepcopy(settings)
    firm = str(body.get("firm") or "").strip()
    if clear:
        ov = st.get("firm_overrides") or {}
        orig, cur = _firm_now(xlsx_b64, firm, ov)
        changes = qc_schedule.firm_changes(cur, orig)
        ov.pop(firm, None)
        st["firm_overrides"] = ov
        if changes:
            _log(st, firm, changes)
        return {"settings": st, "result": {"ok": True, "changes": changes}}
    for k in ("start", "end"):
        if body.get(k) and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", body[k]):
            raise WebError(422, "날짜를 YYYY-MM-DD 로 넣어 주세요.")
    if body.get("start") and body.get("end") and body["end"] < body["start"]:
        raise WebError(422, "종료일이 시작일보다 앞섭니다.")
    ov = st.setdefault("firm_overrides", {})
    orig, cur = _firm_now(xlsx_b64, firm, ov)
    want = {k: (str(body.get(k) or "")).strip()[:20] or orig.get(k) or "" for k in ("start", "end", "lead", "member")}
    changes = qc_schedule.firm_changes(cur, want)
    if not changes:
        return {"settings": settings, "result": {"ok": True, "changes": []}}
    diff = {k: v for k, v in want.items() if v != (orig.get(k) or "")}
    if diff:
        ov[firm] = diff
    else:
        ov.pop(firm, None)
    _log(st, firm, changes)
    return {"settings": st, "result": {"ok": True, "changes": changes}}


def schedule_meetings(settings: dict[str, Any], rules: dict[str, dict[str, list[str]]]) -> dict[str, Any]:
    clean: dict[str, dict[str, list[str]]] = {}
    for day, rs in (rules or {}).items():
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            raise WebError(422, f"날짜를 YYYY-MM-DD 로 넣어 주세요: {day}")
        for word, people in rs.items():
            names = [p.strip()[:20] for p in people if p and p.strip()]
            if word.strip() and names:
                clean.setdefault(day, {})[word.strip()[:20]] = names
    st = copy.deepcopy(settings)
    st["meeting_people"] = clean
    return {"settings": st, "result": {"ok": True, "rules": clean}}


REGISTERS = {"prev": "직전개별선정회사", "next": "차기수임신고내역", "review": "심사·감리 회사현황", "screened": "직전심사대상회사"}
_ALL_FIRMS = {"review"}
_KEEP = ("company", "biz_no", "corp_no", "firm", "year", "fy", "kind", "period", "note", "finding", "violation", "cancel")


def registers_view(regs: dict[str, Any], firm: str = "") -> dict[str, Any]:
    from gumiho.services import qc_sample
    out = {}
    for kind, label in REGISTERS.items():
        reg = regs.get(kind) or None
        items = (reg or {}).get("items") or []
        sel = items if kind in _ALL_FIRMS else (qc_sample.register_for(reg, firm) if firm else [])
        out[kind] = {"label": label, "ready": bool(reg), "name": (reg or {}).get("name"), "date": (reg or {}).get("date"),
                     "sources": (reg or {}).get("sources") or [], "total": len(items), "firms": len((reg or {}).get("firms") or []),
                     "items": [{k: i[k] for k in _KEEP if k in i} for i in sel]}
    return out


def register_upload(kind: str, name: str, b64: str, mode: str, old: dict[str, Any] | None) -> dict[str, Any]:
    from gumiho.services import qc_sample
    if kind not in REGISTERS:
        raise WebError(404, "모르는 명부입니다.")
    try:
        reg = qc_sample.parse_register(_b(b64), name)
    except qc_sample.PresubmitError as exc:
        raise WebError(422, str(exc)) from exc
    if kind == "prev":
        picked = [i for i in reg["items"] if i.get("kind") == "감사인감리(품감) 선정"]
        if picked:
            reg["items"] = picked
    now = datetime.utcnow().isoformat(timespec="seconds") + "+00:00"
    src = {"name": reg["name"], "date": now, "rows": len(reg["items"])}
    if mode == "append" and old:
        seen = {(i.get("company"), i.get("firm"), i.get("year"), i.get("biz_no")) for i in old.get("items") or []}
        add = [i for i in reg["items"] if (i.get("company"), i.get("firm"), i.get("year"), i.get("biz_no")) not in seen]
        items = (old.get("items") or []) + add
        sources = (old.get("sources") or [{"name": old.get("name"), "date": old.get("date"), "rows": len(old.get("items") or [])}]) + [src]
        src["rows"] = len(add)
    else:
        items, sources = reg["items"], [src]
    data = {"name": " + ".join(x["name"] or "" for x in sources), "date": now, "items": items, "sources": sources,
            "firms": sorted({str(i.get("firm") or "") for i in items} - {""})}
    return {"register": data, "result": {"ok": True, "rows": len(items), "added": src["rows"], "firms": len(data["firms"]), "mode": mode}}


def template_check(name: str, b64: str) -> dict[str, Any]:
    from gumiho.services import ar_format
    data = _b(b64)
    try:
        ar_format.reject_not_zip(data, name)
        ar_format.inspect(data)
    except ar_format.FormatError as exc:
        raise WebError(422, str(exc)) from exc
    return {"ok": True, "size": len(data)}


# ── 전자공시(중계) ───────────────────────────────────────────────────────

async def companies(q: str) -> dict[str, Any]:
    """[심사조서Down] 의 회사 찾기(사내 재무 DB) 대신 — 전자공시 고유번호 목록 + 기업개황(사업자번호·결산월)."""
    from gumiho.integrations.external import dart
    q = (q or "").strip()
    if len(q) < 2:
        raise WebError(422, "회사명을 두 글자 이상 넣어 주세요.")
    idx = await _corp_index(None, KEY, CACHE)
    key = dart.normalize_name(q)
    hits = [c for name, lst in idx.items() if key and key in name for c in lst]
    hits.sort(key=lambda c: (dart.normalize_name(c["corp_name"]) != key, not c["stock_code"], len(c["corp_name"]), c["corp_name"]))
    items = []
    async with httpx.AsyncClient() as client:
        for c in hits[:8]:
            try:
                p = (await client.get(f"{dart.OPENDART}/company.json", params={"crtfc_key": KEY, "corp_code": c["corp_code"]})).json()
            except Exception:  # noqa: BLE001
                p = {}
            mm = int(p.get("acc_mt") or 12) if str(p.get("acc_mt") or "").isdigit() else 12
            today = _today()
            periods = []
            for y in range(today.year, today.year - 7, -1):
                end = date(y, mm % 12 + 1, 1) - timedelta(days=1) if mm != 12 else date(y, 12, 31)
                if end < today:
                    periods.append(end.strftime("%Y%m%d"))
            items.append({"nice_id": c["corp_code"], "corp_code": c["corp_code"], "name": p.get("corp_name") or c["corp_name"],
                          "ceo": p.get("ceo_nm") or "", "biz": p.get("bizr_no") or "", "pub": "", "ind_cd": p.get("induty_code") or "",
                          "ind_nm": "", "latest": "", "periods": periods[:6]})
    return {"items": items, "total": len(items), "window": {}, "pub": "5", "pub_label": "전자공시"}


async def versions(company: str, year: int, basis: str = "indi", fiscal_month: int = 12, corp_code: str = "", auditor: str = "") -> dict[str, Any]:
    from gumiho.integrations.external import dart, dart_finance
    try:
        return await dart_finance.report_versions(
            KEY, company, int(year), basis=basis, fiscal_month=int(fiscal_month), cache_dir=CACHE, corp_code=corp_code,
            hint={"auditor": auditor, "base_dt": f"{year}{int(fiscal_month):02d}28"} if auditor else None)
    except dart.AmbiguousCompany as exc:
        raise WebError(409, {"message": f"{exc} — 같은 이름의 회사가 여럿입니다.", "candidates": exc.candidates}) from exc
    except dart.DartError as exc:
        raise WebError(422, str(exc)) from exc
    except httpx.HTTPError as exc:
        raise WebError(502, f"전자공시에 연결하지 못했습니다: {exc}") from exc


async def dart_pdf(rcept_no: str) -> dict[str, Any]:
    from gumiho.integrations.external import dart
    try:
        data, filename = await dart.download_pdf_by_receipt(rcept_no)
    except dart.DartError as exc:
        raise WebError(422, str(exc)) from exc
    except httpx.HTTPError as exc:
        raise WebError(502, f"전자공시에 연결하지 못했습니다: {exc}") from exc
    if not filename.lower().endswith(".pdf"):
        filename += ".pdf"
    return {"b64": _s(data), "name": filename, "type": "application/pdf"}


def _xml_text(xml: bytes) -> str:
    from lxml import etree
    from gumiho.integrations.external.dart_statements import _utf8
    root = etree.fromstring(_utf8(xml), etree.XMLParser(recover=True, resolve_entities=False, no_network=True))
    lines = []
    for el in root.iter("P", "TD", "TH", "TE", "TITLE"):
        t = " ".join("".join(el.itertext()).split())
        if t:
            lines.append(t)
    return "\n".join(lines)


async def opinion_basis(company: str, year: int, fiscal_month: int = 12, corp_code: str = "", auditor: str = "") -> dict[str, Any]:
    """변형의견 사유 — 서버는 PDF 를 MarkItDown 으로 읽는다. 여기서는 같은 보고서의 원문(XML) 글로 읽는다."""
    from gumiho.integrations.external import dart_firm
    from gumiho.services import qc_sample_docs
    v = await versions(company, year, "indi", fiscal_month, corp_code, auditor)
    items = v.get("items") or []
    if not items:
        raise WebError(404, f"전자공시에 {year}.{int(fiscal_month):02d} 결산기 감사보고서가 없습니다.")
    item = next((i for i in items if i["receipt"] == v.get("suggested_receipt")), items[0])
    try:
        xml = await dart_firm.fetch_document(KEY, item["receipt"], cache_dir=CACHE)
    except Exception as exc:  # noqa: BLE001
        raise WebError(502, f"감사보고서 원문을 받지 못했습니다: {exc}") from exc
    basis = qc_sample_docs.opinion_basis(_xml_text(xml))
    return {"company": v.get("company"), "corp_code": v.get("corp_code"), "receipt": item["receipt"],
            "filed_date": item.get("filed_date"), "report": item.get("name"), "url": item.get("url"), **basis}


async def _docs(company: str, corp: str, base_dt: str, basis: str) -> list[bytes]:
    """Y·Y-2·Y-4 결산기 감사보고서(가장 나중 제출본) 원문 — 5개년을 채운다. 없는 해는 건너뛴다."""
    from gumiho.integrations.external import dart_firm
    y, m = int(base_dt[:4]), int(base_dt[4:6])
    out: list[bytes] = []
    for yy in (y, y - 2, y - 4):
        try:
            v = await versions(company, yy, basis, m, corp)
        except WebError:
            continue
        items = v.get("items") or []
        if items:
            out.append(await dart_firm.fetch_document(KEY, items[-1]["receipt"], cache_dir=CACHE))
    return out


async def indepth(body: dict[str, Any], tpl_b64: str) -> dict[str, Any]:
    """인뎁스 조서 — 서버 /qc-sample/indepth 와 같은 채우기. 재무 값만 사내 재무 DB 대신 감사보고서 원문 재무제표."""
    from gumiho.integrations.external import dart_statements
    from gumiho.services import ar_format, qc_sample, qc_sample_review
    if not tpl_b64:
        raise WebError(404, f"{KINDS.get(body.get('kind'), '')} 서식이 아직 없습니다. 관리자가 올려 주세요.")
    raw = _b(tpl_b64)
    corp, base_dt, name = str(body.get("nice_id") or ""), str(body.get("base_dt") or ""), str(body.get("company_name") or "")
    if not re.fullmatch(r"\d{8}", corp) or not re.fullmatch(r"\d{8}", base_dt):
        raise WebError(422, "회사(전자공시 고유번호)·결산일자를 확인해 주세요.")
    docs = await _docs(name, corp, base_dt, "indi")
    indi = dart_statements.review(docs, base_dt, "indi", name=name)
    if indi is None:
        raise WebError(404, f"전자공시 감사보고서({base_dt[:4]}.{base_dt[4:6]})에서 재무제표를 읽지 못했습니다.")
    con = None
    if body.get("consolidated"):
        cdocs = await _docs(name, corp, base_dt, "con")
        con = dart_statements.review(cdocs, base_dt, "con", name=name) if cdocs else None
    patch, total = ar_format.fill_workbook(raw, indi, con)
    done = qc_sample.fill_inputs(patch, raw, {
        "base_dt": base_dt, "report_date": str(body.get("report_date") or "").strip(),
        "consolidated": bool(body.get("consolidated")) or bool(con), "industry": str(body.get("industry") or ""),
        "lead": body.get("lead") or "", "member": body.get("member") or "", "schedule": body.get("schedule") or ""})
    try:
        done += qc_sample_review.material_list(patch)
    except Exception:  # noqa: BLE001
        pass
    if body.get("kind") == "full" and docs:
        try:
            rc = str(body.get("rcept_no") or "")
            done += qc_sample_review.place(patch, raw, qc_sample_review.comments(docs[0], rc or "00000000000000"))
        except Exception:  # noqa: BLE001
            pass
    if total == 0:
        raise WebError(422, "채울 재무 값이 없습니다. 결산일자를 다시 골라 주세요.")
    safe = re.sub(r'[\\/:*?"<>|]', "_", name or "회사")[:40]
    return {"b64": _s(patch.to_bytes(strip_macros=True)), "name": f"인뎁스({KINDS.get(body.get('kind'), '')})_{safe}_{base_dt}.xlsx",
            "type": ar_format.XLSX_MIME, "filled": total}


def workpaper(kind: str, payload: dict[str, Any], tpl_b64: str) -> dict[str, Any]:
    """[품감] 심의안의 조직 조서·개별 조서 — 서버 /qc/workpaper 와 같은 코드(services/qc_workpaper.py)."""
    from gumiho.services import qc_workpaper
    firm = re.sub(r'[\\/:*?"<>|]', "_", str(payload.get("firm") or "회계법인"))[:40]
    try:
        if kind == "org":
            data, _ = qc_workpaper.org_xlsx(_b(tpl_b64), payload)
            return {"b64": _s(data), "name": f"조직조서(초안)_{firm}.xlsx", "type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
        if not tpl_b64:
            raise WebError(404, "인뎁스 서식(상근용)이 없습니다. [품감] 개별선정 관리자설정에서 올려 주세요.")
        data, ext, _n = qc_workpaper.indi_zip(_b(tpl_b64), payload)
        one = next((c for c in payload.get("companies") or [] if str(c.get("name") or "").strip()), {})
        name = f"개별조서(초안)_{firm}.zip" if ext == "zip" else f"개별조서(초안)_{firm}_{qc_workpaper.safe(one.get('name') or '')}.xlsx"
        return {"b64": _s(data), "name": name, "type": "application/zip" if ext == "zip" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    except qc_workpaper.WorkpaperError as exc:
        raise WebError(422, str(exc)) from exc


# ── 입구 ────────────────────────────────────────────────────────────────

FUNCS = {f.__name__: f for f in (parse, reconcile, other, schedule_view, schedule_check, holidays, schedule_firm, schedule_meetings,
                                  registers_view, register_upload, template_check, companies, versions, dart_pdf, opinion_basis,
                                  indepth, workpaper)}


async def call(name: str, args_json: str) -> str:
    try:
        fn = FUNCS[name]
        args = json.loads(args_json or "[]")
        out = fn(*args) if isinstance(args, list) else fn(**args)
        if asyncio.iscoroutine(out):
            out = await out
        return json.dumps(out, ensure_ascii=False, default=str)
    except WebError as exc:
        return json.dumps({"error": {"status": exc.status, "detail": exc.detail}}, ensure_ascii=False, default=str)
    except Exception as exc:  # noqa: BLE001 — 화면에 그대로 알린다
        return json.dumps({"error": {"status": 500, "detail": f"{type(exc).__name__}: {exc}"}}, ensure_ascii=False)
