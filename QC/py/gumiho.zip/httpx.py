"""GitHub(정적) 사이트 전용 `httpx` 대역 — 서버의 전자공시 코드(dart*.py)를 고치지 않고 브라우저(Pyodide)에서 돌리려고(2026-10-15).

브라우저는 전자공시를 직접 부를 수 없어(CORS) 모든 요청을 구글 Apps Script 중계(backend/scripts/qc_relay/Code.gs)로 보낸다.
    opendart.fss.or.kr/api/<list.json|company.json|document.xml>  → op=api  (인증키는 중계가 붙인다 — 여기의 crtfc_key 는 버림)
    dart.fss.or.kr/<공시뷰어 세 주소>                               → op=web  (리다이렉트·쿠키는 여기서 따라간다)
서버 코드가 쓰는 만큼만 흉내 낸다: AsyncClient(get) · Response(status_code·content·text·json·headers·url·raise_for_status) · Timeout · HTTPError.
"""
from __future__ import annotations

import base64
import json
import re
from typing import Any
from urllib.parse import urlencode, urljoin, urlsplit

RELAY = ""                 # qs_web.init 이 채운다
TRANSPORT = None           # 시험용: async def (payload: dict) -> dict


class HTTPError(Exception):
    pass


class RequestError(HTTPError):
    pass


class HTTPStatusError(HTTPError):
    pass


class TimeoutException(HTTPError):
    pass


class Timeout:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass


URL = str


class Headers(dict):
    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        return super().get(key.lower(), default)

    def __getitem__(self, key: str) -> Any:
        return super().__getitem__(key.lower())


class Response:
    def __init__(self, status: int, content: bytes, headers: dict[str, Any], url: str) -> None:
        self.status_code = status
        self.content = content
        self.headers = Headers({k.lower(): v for k, v in headers.items()})
        self.url = url

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", "replace")

    def json(self) -> Any:
        return json.loads(self.content.decode("utf-8"))

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise HTTPStatusError(f"전자공시 응답 {self.status_code}: {self.url}")


async def _relay(payload: dict[str, Any]) -> dict[str, Any]:
    """중계 호출 — 구글 Apps Script 가 가끔 「사용할 수 없는 주소」로 전자공시 호출을 놓치거나 연결이 끊긴다(2026-11-13): 두 번까지 다시 부른다."""
    import asyncio
    for left in (2, 1, 0):
        try:
            return await _relay_once(payload)
        except RequestError as exc:
            if left == 0 or not re.search(r"사용할 수 없는 주소|연결하지 못했습니다|일시|timeout|Timeout", str(exc)):
                raise
            await asyncio.sleep(1.5)
    raise RequestError("전자공시 중계 오류")


async def _relay_once(payload: dict[str, Any]) -> dict[str, Any]:
    if TRANSPORT is not None:
        data = await TRANSPORT(payload)
    else:
        if not RELAY:
            raise RequestError("전자공시 중계(구글 Apps Script) 주소가 없습니다.")
        from pyodide.http import pyfetch  # type: ignore[import-not-found]
        try:
            r = await pyfetch(RELAY, method="POST", body=json.dumps(payload), headers={"Content-Type": "text/plain;charset=utf-8"})
            data = await r.json()
        except Exception as exc:  # noqa: BLE001
            raise RequestError(f"전자공시 중계에 연결하지 못했습니다: {exc}") from exc
    if not data.get("ok"):
        raise RequestError(str(data.get("error") or "전자공시 중계 오류"))
    return data


class AsyncClient:
    def __init__(self, headers: dict[str, str] | None = None, timeout: Any = None, follow_redirects: bool = False, **_: Any) -> None:
        self.follow = follow_redirects
        self.cookies: dict[str, str] = {}

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        return None

    async def aclose(self) -> None:
        return None

    async def get(self, url: str, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None, **_: Any) -> Response:
        full = url + (("&" if "?" in url else "?") + urlencode(params) if params else "")
        host = urlsplit(full).netloc
        if host == "opendart.fss.or.kr":
            path = urlsplit(url).path.rsplit("/", 1)[-1]
            q = {k: v for k, v in (params or {}).items() if k != "crtfc_key"}
            d = await _relay({"op": "api", "path": path, "params": q})
            return Response(int(d.get("status") or 200), base64.b64decode(d.get("b64") or ""), {"content-type": d.get("ctype") or ""}, full)
        if host == "dart.fss.or.kr":
            referer = (headers or {}).get("Referer") or ""
            for _hop in range(6):
                d = await _relay({"op": "web", "url": full, "referer": str(referer),
                                  "cookie": "; ".join(f"{k}={v}" for k, v in self.cookies.items())})
                h = d.get("headers") or {}
                for c in h.get("set-cookie") or []:
                    name, _, rest = str(c).partition("=")
                    if name.strip():
                        self.cookies[name.strip()] = rest.split(";", 1)[0]
                status = int(d.get("status") or 0)
                if self.follow and status in (301, 302, 303, 307, 308) and h.get("location"):
                    referer, full = full, urljoin(full, h["location"])
                    continue
                return Response(status, base64.b64decode(d.get("b64") or ""), {k: v for k, v in h.items() if k != "set-cookie"}, full)
            raise RequestError("공시뷰어 리다이렉트가 너무 많습니다.")
        raise RequestError(f"이 사이트에서는 부를 수 없는 주소입니다: {host}")
