"""GitHub(정적) 사이트 전용 — 서버 설정 대신(파일 자리만, 브라우저 메모리 안). 서버의 gumiho/config.py 를 덮어쓴다."""
from types import SimpleNamespace

_S = SimpleNamespace(filestore_dir="/tmp/fs", ar_template_dir="/tmp/ar_templates")


def get_settings():
    return _S
