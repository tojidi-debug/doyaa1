"""감사보고서 원문(전자공시) → 인뎁스 서식의 계정코드별 금액 — 사내 재무 DB 를 쓸 수 없는 곳의 대신(2026-10-15).

[품감] 개별선정의 GitHub(정적) 판은 사내 재무 DB(오라클)에 닿지 못한다(사용자 지정 2026-10-15: 「DART 원문으로 채움」).
그래서 그 결산기 감사보고서 원문(document.xml)의 **본표**(재무상태표·손익계산서·현금흐름표)를 읽어,
`ar_format.fill_workbook` 이 받는 꼴(`integrations/oracle/finstmt.get_review` 와 같은 모양)로 만든다.

    {"company": {"name", "ind_nm"}, "periods": [YYYYMMDD × 5], "audits": [],
     "statements": {"bs": [{"code", "values": [5개년, 백만원]}], "pl": [...], "cf": [...]}}

## 계정코드 잇기 — 이름으로, 아는 것만

오라클은 계정코드를 주지만 원문에는 이름뿐이다. 그래서 **이름(씻은 것) → 코드** 표(`RULES`)로 잇는다.
서식의 합계·주요 계정(유동자산·매출채권·재고·유형·차입금·매출·영업이익·현금흐름 합계 …)만 둔다.
표에 없는 이름은 버린다 — 잘못 이은 금액이 조서에 조용히 실리는 것보다 빈 칸이 낫다(dart_finance 와 같은 규칙).
같은 코드가 한 표에 두 번 나오면 먼저 읽은 것을 둔다(본표의 위쪽이 그 계정이다).

## 해(열)

원문 한 건이 당기·전기 두 해를 준다. 5개년은 Y·Y-2·Y-4 감사보고서 세 건으로 채운다(`review` 가 부른다).
머리글의 해는 「…까지」·「…현재」 앞의 날짜로 정한다 — 3월 결산처럼 「2024년 4월 1일부터 2025년 3월 31일까지」 꼴이면
모든 「YYYY년」을 세면 해가 넷이 되어 짝이 안 맞는다.
"""
from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from lxml import etree

from gumiho.integrations.external.dart import DartError
from gumiho.integrations.external.dart_finance import SCALE, _label, _text, amount

KIND = (("bs", r"재무상태표|대차대조표"), ("pl", r"손익계산서"), ("cf", r"현금흐름표"))
NEED = {"bs": "5000", "pl": "9000", "cf": "1000"}      # 본표인지 — 이 코드가 읽혀야 그 표를 쓴다(주석의 표 거르기)

# (종류, 구역, 이름 정규식(씻은 이름 전체), 코드). 구역: ca 유동자산 · nca 비유동자산 · cl 유동부채 · ncl 비유동부채 · "" 어디든
_R = [
    ("bs", "", r"유동자산(합계|계)?", "2000"), ("bs", "", r"비유동자산(합계|계)?", "4000"),
    ("bs", "", r"자산(총계|합계|총액)", "5000"), ("bs", "", r"유동부채(합계|계)?", "6000"), ("bs", "", r"비유동부채(합계|계)?", "7000"),
    ("bs", "", r"부채(총계|합계|총액)", "8000"), ("bs", "", r"자본금", "8100"), ("bs", "", r"(기타)?자본잉여금", "8200"),
    ("bs", "", r"자본조정", "8400"), ("bs", "", r"자기주식", "8430"), ("bs", "", r"기타포괄손익누계액", "8600"),
    ("bs", "", r"이익잉여금(결손금)?|결손금|이익잉여금\(결손금\)", "8300"), ("bs", "", r"자본(총계|합계|총액)", "8900"),
    ("bs", "", r"부채(와|및)자본(총계|합계)", "9000"),
    ("bs", "ca", r"현금및현금성자산|현금및현금등가물|현금및예금", "1100"), ("bs", "ca", r"단기금융상품|단기예금|단기금융자산", "1220"),
    ("bs", "ca", r"매출채권(및기타채권|및기타유동채권)?", "1150"), ("bs", "ca", r"단기대여금", "1170"),
    ("bs", "ca", r"미수금", "1180"), ("bs", "ca", r"미수수익", "1190"), ("bs", "ca", r"이연법인세자산", "1210"),
    ("bs", "ca", r"선급금", "1410"), ("bs", "ca", r"선급비용", "1420"), ("bs", "ca", r"재고자산", "1400"),
    ("bs", "ca", r"상품", "1310"), ("bs", "ca", r"제품", "1320"), ("bs", "ca", r"반제품", "1330"),
    ("bs", "ca", r"재공품", "1340"), ("bs", "ca", r"원재료", "1350"),
    ("bs", "nca", r"장기금융상품", "2111"), ("bs", "nca", r"장기대여금", "2210"),
    ("bs", "nca", r"매도가능증권|매도가능금융자산|기타포괄손익-?공정가치측정금융자산", "2121"),
    ("bs", "nca", r"만기보유증권|만기보유금융자산", "2122"),
    ("bs", "nca", r"지분법적용투자주식|관계기업투자(주식)?|(종속기업및)?관계기업(및공동기업)?투자(주식)?", "2147"),
    ("bs", "nca", r"유형자산", "3200"), ("bs", "nca", r"토지", "3110"), ("bs", "nca", r"건물", "3120"),
    ("bs", "nca", r"기계장치", "3140"), ("bs", "nca", r"건설중인자산", "3199"), ("bs", "nca", r"무형자산", "3400"),
    ("bs", "nca", r"개발비", "3296"), ("bs", "nca", r"임차보증금|보증금", "2261"), ("bs", "nca", r"장기미수금", "2230"),
    ("bs", "nca", r"장기선급금", "2251"),
    ("bs", "cl", r"매입채무(및기타채무|및기타유동채무)?", "5110"), ("bs", "cl", r"단기차입금", "5130"),
    ("bs", "cl", r"유동성장기(부채|차입금)", "5190"), ("bs", "cl", r"미지급금", "5140"), ("bs", "cl", r"선수금", "5150"),
    ("bs", "cl", r"미지급비용", "5180"), ("bs", "cl", r"선수수익", "5210"),
    ("bs", "ncl", r"사채", "6050"), ("bs", "ncl", r"장기차입금", "6200"), ("bs", "ncl", r"장기선수금", "6280"),
    ("bs", "ncl", r"장기미지급금", "6400"), ("bs", "ncl", r"퇴직급여충당부채|순?확정급여부채", "6610"),
    ("bs", "ncl", r"임대보증금", "6800"), ("bs", "ncl", r"이연법인세부채", "6900"),
    ("pl", "", r"매출액?|매출액합계|수익\(?매출액\)?|영업수익", "1000"), ("pl", "", r"상품매출(액)?", "1110"),
    ("pl", "", r"제품매출(액)?", "1120"), ("pl", "", r"공사수익", "1140"), ("pl", "", r"분양수익", "1150"),
    ("pl", "", r"임대수익", "1160"), ("pl", "", r"매출원가", "2000"), ("pl", "", r"상품매출원가", "2100"),
    ("pl", "", r"제품매출원가", "2200"), ("pl", "", r"공사원가", "2300"), ("pl", "", r"분양원가", "2400"),
    ("pl", "", r"임대원가", "2500"), ("pl", "", r"매출총(이익|손실|이익손실|손익)", "3000"),
    ("pl", "", r"판매비와관리비", "4000"), ("pl", "", r"영업(이익|손실|이익손실|손익)", "5000"),
    ("pl", "", r"영업외수익", "5100"), ("pl", "", r"이자수익", "5101"), ("pl", "", r"임대료(수익)?", "5105"),
    ("pl", "", r"지분법이익", "5127"), ("pl", "", r"영업외비용", "6000"), ("pl", "", r"이자비용", "6110"),
    ("pl", "", r"지분법손실", "6310"), ("pl", "", r"법인세(비용)?차감전(계속사업)?(순이익|순손실|순이익손실|순손익|이익|손실|손익)", "8000"),
    ("pl", "", r"(계속사업)?법인세(비용|수익|비용수익)", "8100"), ("pl", "", r"중단사업(손익|이익|손실)", "8170"),
    ("pl", "", r"당기순(이익|손실|이익손실|손익|손실이익)", "9000"),
    ("cf", "", r"영업활동(으로인한)?현금흐름", "1000"), ("cf", "", r"당기순(이익|손실|이익손실|손익)", "1100"),
    ("cf", "", r"투자활동(으로인한)?현금흐름", "2000"), ("cf", "", r"투자활동(으로인한)?현금유입(액)?", "2100"),
    ("cf", "", r"투자활동(으로인한)?현금유출(액)?", "2500"), ("cf", "", r"재무활동(으로인한)?현금흐름", "3000"),
    ("cf", "", r"재무활동(으로인한)?현금유입(액)?", "3100"), ("cf", "", r"재무활동(으로인한)?현금유출(액)?", "3500"),
    ("cf", "", r"현금(및현금성자산)?의(순)?(증가|감소|증가감소|증감)", "4000"),
    ("cf", "", r"기초(의)?현금(및현금성자산)?", "5000"), ("cf", "", r"기말(의)?현금(및현금성자산)?", "6000"),
]
RULES = [(k, sec, re.compile(rf"(?:{pat})"), code) for k, sec, pat, code in _R]
_SECTION = (("유동자산", "ca"), ("비유동자산", "nca"), ("유동부채", "cl"), ("비유동부채", "ncl"), ("자본", "eq"))


def code_of(kind: str, section: str, label: str) -> str | None:
    """씻은 계정 이름 → 서식 코드. 모르면 None"""
    for k, sec, rx, code in RULES:
        if k == kind and (not sec or sec == section) and rx.fullmatch(label):
            return code
    return None


def _years(prefix: str) -> list[int]:
    ends = re.findall(r"((?:19|20)\d{2})\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일\s*(?:까지|현재)", prefix)
    found = ends or re.findall(r"((?:19|20)\d{2})\s*년", prefix)
    return list(dict.fromkeys(int(y) for y in found))


def _utf8(raw: bytes) -> bytes:
    """옛 원문(2022년 무렵까지)은 머리에 utf-8 이라 적고 실제로는 EUC-KR(cp949) 이다 — 그대로 읽으면 글자가 깨져 표를 못 찾는다."""
    try:
        raw.decode("utf-8")
        return raw
    except UnicodeDecodeError:
        return raw.decode("cp949", "replace").encode("utf-8")


def statements(raw: bytes) -> dict[str, dict[str, dict[int, dict[str, float]]]]:
    """원문 XML → {basis: {kind: {해: {코드: 금액(천원)}}}}. 본표만(필요 코드가 읽힌 표), 못 정한 칸은 버린다."""
    raw = _utf8(raw)
    parser = etree.XMLParser(recover=True, resolve_entities=False, no_network=True, huge_tree=False)
    root = etree.fromstring(raw, parser)
    if root is None:
        raise DartError("공시 원문을 읽을 수 없습니다.")
    report_name = root.findtext(".//DOCUMENT-NAME") or ""
    out: dict[str, dict[str, dict[int, dict[str, float]]]] = {}
    last_unit = ""
    for table in root.iter("TABLE"):
        group = table.getparent()
        if group is None:
            continue
        title = re.sub(r"\s+", "", " ".join(_text(e) for e in group.findall("./TITLE")))
        prefix = ""
        if re.search(r"재무상태표|대차대조표|손익계산서|현금흐름표", title) and "주석" not in title:
            children = list(group)
            prefix = " ".join(_text(el) for el in children if el is not table and children.index(el) < children.index(table))
        else:
            if "재무제표" not in title or table.find("./THEAD/TR") is None:
                continue
            head = table.getprevious()
            while head is not None and head.tag == "P" and not _text(head).strip():
                head = head.getprevious()
            if head is None or head.tag != "TABLE" or head.find("./THEAD") is not None:
                continue
            first = head.find(".//TR")
            name = re.sub(r"\s+", "", _text(first) if first is not None else "")
            if not re.search(r"재무상태표|대차대조표|손익계산서|현금흐름표", name) or len(name) > 20:
                continue
            title, prefix = name, _text(head)
        kind = next((k for k, rx in KIND if re.search(rx, title)), None)
        if kind is None or not prefix:
            continue
        units = re.findall(r"단위\s*[:：]\s*(백만원|천원|원)", prefix) or ([last_unit] if last_unit else [])
        if not units:
            continue
        last_unit = units[-1]
        scale = SCALE[units[-1]]
        years = _years(prefix)
        header = table.find("./THEAD/TR")
        if header is None or not 1 <= len(years) <= 4:
            continue
        groups: list[tuple[int, int]] = []
        others: list[tuple[int, int]] = []
        offset = 0
        for index, cell in enumerate([c for c in header if c.tag in ("TH", "TD", "TE")]):
            span = int(cell.get("COLSPAN", "1"))
            if re.search(r"제\s*\d+|당기|전기|20\d{2}", _text(cell)):
                groups.append((offset, offset + span))
            if index and not re.search(r"주\s*석|과\s*목|구\s*분", _text(cell)):
                others.append((offset, offset + span))
            offset += span
        if len(groups) != len(years) and len(others) == len(years):
            groups = others
        if len(groups) != len(years):
            continue
        basis = "con" if "연결" in title or ("연결" in report_name and "별도" not in title) else "indi"
        found: dict[int, dict[str, float]] = {y: {} for y in years}
        section = ""
        for row in table.findall("./TBODY/TR"):
            cells = [c for c in row if c.tag in ("TD", "TE", "TH")]
            if not cells:
                continue
            label = _label(_text(cells[0]))
            if kind == "bs":
                for word, sec in _SECTION:
                    if re.fullmatch(rf"{word}(합계|계)?", label):
                        section = sec
            code = code_of(kind, section, label)
            if not code:
                continue
            expanded: list[str] = []
            for cell in cells:
                expanded += [_text(cell)] * int(cell.get("COLSPAN", "1"))
            for year, (start, end) in zip(years, groups, strict=True):
                vals = list(dict.fromkeys(v for v in (amount(x) for x in expanded[start:end]) if v is not None))
                if len(vals) != 1 or code in found[year]:
                    continue                      # 애매한 칸·이미 읽은 코드는 두지 않는다
                found[year][code] = float(Decimal(vals[0]) * scale)
        if not any(NEED[kind] in v for v in found.values()):
            continue                              # 본표가 아니다(주석의 표)
        target = out.setdefault(basis, {}).setdefault(kind, {})
        for year, vals in found.items():
            for code, v in vals.items():
                target.setdefault(year, {}).setdefault(code, v)
    if not out:
        raise DartError("원문에서 재무상태표·손익계산서를 찾지 못했습니다.")
    return out


def review(docs: list[bytes], base_dt: str, basis: str, *, name: str = "") -> dict[str, Any] | None:
    """원문 여러 건(최근 것 먼저) → `ar_format.fill_workbook` 이 받는 한 벌. 그 기준(개별·연결) 표가 하나도 없으면 None.
    5개년(base_dt 의 해부터 한 해씩 거꾸로) 칸마다 처음 읽은 원문 값을 쓴다. 금액은 천원 → 백만원."""
    year0, rest = int(base_dt[:4]), base_dt[4:]
    periods = [f"{year0 - k}{rest}" for k in range(5)]
    merged: dict[str, dict[int, dict[str, float]]] = {}
    for raw in docs:
        try:
            got = statements(raw).get(basis) or {}
        except DartError:
            continue
        for kind, by_year in got.items():
            for y, vals in by_year.items():
                slot = merged.setdefault(kind, {}).setdefault(y, {})
                for code, v in vals.items():
                    slot.setdefault(code, v)
    if not merged:
        return None
    years = [year0 - k for k in range(5)]
    st: dict[str, list[dict[str, Any]]] = {}
    for kind in ("bs", "pl", "cf"):
        by_year = merged.get(kind) or {}
        codes = sorted({c for v in by_year.values() for c in v})
        st[kind] = [{"code": c, "values": [None if (by_year.get(y) or {}).get(c) is None else round(by_year[y][c] / 1000, 3)
                                           for y in years]} for c in codes]
    return {"basis": basis, "company": {"name": name, "ind_nm": ""}, "periods": periods, "audits": [], "statements": st,
            "source": "전자공시 감사보고서 원문"}
