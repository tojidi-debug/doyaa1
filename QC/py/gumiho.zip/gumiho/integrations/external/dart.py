"""전자공시(DART)에서 감사보고서 PDF 를 받아 온다 (담당부서 요청, 2026-09-02).

## 한 번에 안 된다 — 세 곳을 거친다

OpenDART 는 **PDF 를 주지 않는다.** 공시 목록과 접수번호까지만 주고, PDF 는
공시뷰어(dart.fss.or.kr) 쪽에 있다. 그래서 담당부서 말씀대로 「내려받는 데
필요한 정보를 먼저 뽑고」 그 다음에 받는다.

    1. OpenDART  corpCode.xml   회사명 → **고유번호**(corp_code)   ← 인증키 필요
    2. OpenDART  list.json      고유번호 → **접수번호**(rcept_no)  ← 인증키 필요
    3. 공시뷰어  dsaf001/main   접수번호 → **문서번호**(dcm_no)    ← 인증키 없음
    4. 공시뷰어  pdf/download   접수·문서번호 → **PDF**            ← 인증키 없음

⚠️ **4번은 3번을 거친 같은 세션이어야 한다.** 접수·문서번호만 알고 `pdf.do` 를
바로 부르면 **200 에 0바이트**가 온다(실측). 뷰어가 내려 준 쿠키를 들고 가야
파일이 나온다. 그래서 한 `httpx.Client` 안에서 네 걸음을 이어서 밟는다.

## 회사를 이름으로 찾는 이유

OpenDART 에는 **이름으로 찾는 API 가 없다.** 전 회사 고유번호를 담은
`corpCode.xml`(zip)을 받아 두고 그 안에서 찾아야 한다. 우리 재무 DB 는
업체코드(`nice_id`)를 주지만 그건 사내 코드라 DART 와 이어지지 않고,
사업자등록번호도 `corpCode.xml` 에 없다. **남는 열쇠가 이름뿐이다.**

그래서 이름을 씻어서 맞춘다 — `삼성전자(주)` · `㈜삼성전자` · `주식회사 삼성전자`
가 모두 `삼성전자` 가 되게. 그래도 같은 이름이 여럿이면 **고르지 않고 알린다.**
엉뚱한 회사의 감사보고서를 받아 조서에 붙이는 것이 최악이다.

`corpCode.xml` 은 20MB 남짓이라 매번 받지 않는다. 파일로 캐시하고 하루가
지나면 다시 받는다.
"""
from __future__ import annotations

import asyncio
import io
import logging
import re
import unicodedata
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import httpx

logger = logging.getLogger(__name__)

OPENDART = "https://opendart.fss.or.kr/api"
VIEWER = "https://dart.fss.or.kr"

# 공시뷰어는 브라우저가 아닌 요청을 막는 일이 있다. 게시판 수집과 같은 값을 쓴다.
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0 Safari/537.36 GumihoPortal/1.0"
    ),
    "Accept-Language": "ko-KR,ko;q=0.9",
}

TIMEOUT = httpx.Timeout(30.0, read=120.0)   # PDF 가 수십 MB 인 공시가 있다

# 한 공시의 문서(본문+첨부)를 몇 개까지 훑을지. 사업보고서는 첨부가 여럿이라
# 상한이 없으면 감사보고서를 찾느라 열 번 넘게 왕복한다.
MAX_DOCS = 6

# 고유번호 목록 캐시. 20MB zip 을 매번 받지 않는다.
CACHE_TTL = timedelta(days=1)
_cache: dict[str, Any] = {"at": None, "index": None}

# OpenDART 가 status 로 알려 주는 실패. 숫자만 보고 「오류」라고 하면
# 담당자가 무엇을 고쳐야 하는지 알 수 없다.
STATUS_HELP = {
    "010": "등록되지 않은 인증키입니다. 관리자 화면 > 외부 API 키에서 다시 확인해 주세요.",
    "011": "사용할 수 없는 인증키입니다(오픈API 이용 등록 후 승인 대기 중일 수 있습니다).",
    "012": "접근할 수 없는 IP 입니다. OpenDART 에 이 서버 IP 를 등록해 주세요.",
    "013": "조회된 공시가 없습니다.",
    "020": "인증키의 일일 호출 한도(20,000건)를 넘었습니다. 내일 다시 시도해 주세요.",
    "021": "조회 가능한 범위를 넘었습니다.",
    "100": "요청 인자가 잘못되었습니다.",
    "800": "OpenDART 가 점검 중입니다.",
    "900": "정의되지 않은 오류입니다.",
    "901": "사용자 계정이 정지되었습니다.",
}


class DartError(Exception):
    """담당자에게 그대로 보여 줄 수 있는 문장을 담는다."""


@dataclass(frozen=True)
class Filing:
    corp_code: str
    corp_name: str
    report_nm: str
    rcept_no: str
    rcept_dt: str
    flr_nm: str

    def as_dict(self) -> dict[str, str]:
        return {
            "corp_code": self.corp_code, "corp_name": self.corp_name,
            "report_nm": self.report_nm, "rcept_no": self.rcept_no,
            "rcept_dt": self.rcept_dt, "flr_nm": self.flr_nm,
            "viewer_url": f"{VIEWER}/dsaf001/main.do?rcpNo={self.rcept_no}",
        }


# ── 회사 이름 ──────────────────────────────────────────────────────────

_LEGAL = re.compile(r"주식회사|유한회사|\(주\)|\(유\)|㈜|㈜|\(합\)|\(재\)|\(사\)")
_NOISE = re.compile(r"[\s\-·・,.'\"()\[\]]")


def normalize_name(value: str) -> str:
    """`삼성전자(주)` · `㈜삼성전자` · `주식회사 삼성전자` → `삼성전자`.

    NFKC 를 먼저 돌린다 — `㈜` 는 한 글자짜리 조합문자라 그대로 두면
    `(주)` 와 다른 글자다.
    """
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _LEGAL.sub("", text)
    return _NOISE.sub("", text).lower()


# ── 1. 고유번호 목록 ───────────────────────────────────────────────────

def _check_status(payload: dict[str, Any]) -> None:
    status = str(payload.get("status") or "")
    if status in ("000", ""):
        return
    raise DartError(
        STATUS_HELP.get(status)
        or f"OpenDART 오류({status}): {payload.get('message') or '내용 없음'}"
    )


async def _corp_index(client: httpx.AsyncClient, key: str, cache_dir: Path) -> dict[str, list[dict[str, str]]]:
    """씻은 이름 → [{corp_code, corp_name, stock_code}] 목록.

    같은 이름이 여럿일 수 있어 **목록**으로 담는다. 하나로 줄여 놓으면
    나중에 「왜 다른 회사가 나왔지」를 되짚을 수 없다.
    """
    now = datetime.now(UTC)
    if _cache["index"] is not None and _cache["at"] and now - _cache["at"] < CACHE_TTL:
        return _cache["index"]

    cache_dir.mkdir(parents=True, exist_ok=True)
    blob = cache_dir / "dart_corp_code.zip"
    fresh = (
        blob.exists()
        and now - datetime.fromtimestamp(blob.stat().st_mtime, UTC) < CACHE_TTL
    )
    if not fresh:
        response = await client.get(f"{OPENDART}/corpCode.xml", params={"crtfc_key": key})
        # 실패하면 JSON 이 온다. 성공하면 zip 이다.
        if response.headers.get("content-type", "").startswith("application/json"):
            _check_status(response.json())
            raise DartError("고유번호 목록을 받지 못했습니다.")
        response.raise_for_status()
        blob.write_bytes(response.content)
        logger.info("DART 고유번호 목록을 새로 받았습니다: %s bytes", len(response.content))

    index: dict[str, list[dict[str, str]]] = {}
    with zipfile.ZipFile(io.BytesIO(blob.read_bytes())) as archive:
        name = next((n for n in archive.namelist() if n.lower().endswith(".xml")), None)
        if name is None:
            raise DartError("고유번호 목록(zip) 안에 XML 이 없습니다.")
        root = ET.fromstring(archive.read(name))
    for node in root.iter("list"):
        corp_name = (node.findtext("corp_name") or "").strip()
        key_name = normalize_name(corp_name)
        if not key_name:
            continue
        index.setdefault(key_name, []).append({
            "corp_code": (node.findtext("corp_code") or "").strip(),
            "corp_name": corp_name,
            "stock_code": (node.findtext("stock_code") or "").strip(),
        })

    _cache["index"] = index
    _cache["at"] = now
    logger.info("DART 고유번호 %s개를 읽었습니다.", sum(len(v) for v in index.values()))
    return index


class AmbiguousCompany(DartError):
    """같은 이름이 여럿인데 우리가 아는 것만으로는 못 가른다.

    후보를 들고 다닌다 — 화면이 그것을 늘어놓고 **사람이 고르게** 하기 위해서다.
    """

    def __init__(self, message: str, candidates: list[dict[str, Any]]) -> None:
        super().__init__(message)
        self.candidates = candidates


# 한 번에 개황을 물어볼 후보 수. 같은 이름이 열 곳 넘게 있으면 그건 이름이
# 너무 흔한 것이라 물어봐야 소용이 없다.
MAX_CANDIDATES = 8


async def _profile(client: httpx.AsyncClient, key: str, corp_code: str) -> dict[str, Any]:
    """기업개황. 대표자·업종·주소·설립일 — **회사를 가르는 데 쓰는 것들**이다."""
    response = await client.get(f"{OPENDART}/company.json",
                                params={"crtfc_key": key, "corp_code": corp_code})
    response.raise_for_status()
    payload = response.json()
    if str(payload.get("status")) not in ("000", "013"):
        _check_status(payload)
    return payload


def _names(value: str) -> set[str]:
    """`전영현/노태문` → {전영현, 노태문}. 대표가 여럿인 회사가 흔하다."""
    return {part.strip() for part in re.split(r"[/,·]", str(value or "")) if part.strip()}


def _score(profile: dict[str, Any], hint: dict[str, str], raw_name: str) -> int:
    """우리가 아는 것과 몇 가지나 맞는가. 대표자가 가장 세다.

    ⚠️ 점수를 매길 뿐 **자동으로 고르지는 않는다.** 유일하게 앞서는 후보가
    있을 때만 고른다(아래 `_pick`). 어정쩡하면 사람에게 묻는 편이 낫다.
    """
    score = 0
    ceo = _names(hint.get("ceo", ""))
    if ceo and _names(profile.get("ceo_nm", "")) & ceo:
        score += 4
    # 표기까지 똑같은 이름. `(주)프레스코` 와 `주식회사 프레스코` 를 가른다.
    if raw_name and str(profile.get("corp_name") or "").strip() == raw_name.strip():
        score += 2
    # 업종코드는 DART 쪽이 짧다(`2591`), 우리 쪽이 길다(`25913`).
    industry = str(profile.get("induty_code") or "").strip()
    if industry and str(hint.get("ind_cd") or "").startswith(industry):
        score += 2
    month = str(profile.get("acc_mt") or "").strip().zfill(2)
    if month and month == str(hint.get("base_dt") or "")[4:6]:
        score += 1
    return score


def auditor_key(v: Any) -> str:
    """「회계법인 나루」·「나루회계법인」·「회계법인나루」 → 「나루」"""
    return re.sub(r"\s+|회계법인|감사반|\(.*?\)", "", str(v or ""))


async def _audited_by(client: httpx.AsyncClient, key: str, candidates: list[dict[str, str]],
                      auditor: str, base_dt: str) -> list[dict[str, str]]:
    """그 회계법인이 제출인인 외부감사관련(F) 공시가 결산기 앞뒤에 있는 후보만"""
    year = int(base_dt[:4]) if re.fullmatch(r"\d{8}", base_dt or "") else datetime.now(UTC).year - 1
    start, end = f"{year}0101", f"{year + 1}1231"

    async def one(c: dict[str, str]) -> bool:
        try:
            items = await _list(client, key, c["corp_code"], start, end, "F")
        except Exception:  # noqa: BLE001 — 하나를 못 읽어도 나머지로
            return False
        return any(auditor in re.sub(r"\s+", "", str(i.get("flr_nm") or "")) for i in items)

    flags = await asyncio.gather(*(one(c) for c in candidates))
    return [c for c, ok in zip(candidates, flags) if ok]


async def _pick(
    client: httpx.AsyncClient, key: str,
    candidates: list[dict[str, str]], name: str, hint: dict[str, str],
) -> dict[str, str]:
    """같은 이름이 여럿일 때 **우리가 이미 아는 것으로** 가른다.

    재무 DB 가 대표자·업종코드·결산일자를 준다. DART 기업개황이 같은 것을 준다.
    맞춰 보면 대부분 갈린다 — 실측(2026-09-03):

        (주)프레스코  김영근 / 29172  ↔  01147520 김영근 / 30
        (주)프레스코  김준홍 / 25913  ↔  01224290 김준홍 / 2591

    그래도 안 갈리면 **고르지 않고 후보를 올려 보낸다.** 사람이 고르는 편이
    엉뚱한 회사의 감사보고서를 조서에 붙이는 것보다 낫다.
    """
    if len(candidates) == 1:
        return candidates[0]

    listed = [c for c in candidates if c.get("stock_code")]
    if len(listed) == 1:
        return listed[0]

    # 감사인(감사보고서 제출인)을 알면 그 회계법인이 낸 감사보고서가 있는 회사로 가른다(사용자 지정 2026-10-15) —
    # 이름이 같아도 감사인이 다르면 한 곳으로 갈린다. 같은 법인이 둘 다 감사했으면 아래로 넘어가 사람이 고른다.
    auditor = auditor_key(hint.get("auditor"))
    if auditor and len(candidates) <= MAX_CANDIDATES:
        hits = await _audited_by(client, key, candidates, auditor, str(hint.get("base_dt") or ""))
        if len(hits) == 1:
            logger.info("DART 회사 자동 판별(감사인 %s): %s", auditor, hits[0]["corp_code"])
            return hits[0]

    if len(candidates) > MAX_CANDIDATES:
        raise AmbiguousCompany(
            f"'{name}' 이라는 이름의 회사가 DART 에 {len(candidates)}곳 있습니다. "
            "너무 많아 가려낼 수 없습니다 — 전자공시에서 직접 찾아 주세요.",
            [],
        )

    profiles = await asyncio.gather(
        *(_profile(client, key, c["corp_code"]) for c in candidates)
    )
    scored = [
        (_score(profile, hint, name), candidate, profile)
        for candidate, profile in zip(candidates, profiles)
    ]
    scored.sort(key=lambda row: row[0], reverse=True)

    best, runner = scored[0], scored[1]
    # 유일하게 앞서고 **근거가 충분할 때만** 고른다.
    # 4점은 「대표자가 맞다」 하나, 또는 「이름 표기가 똑같다 + 업종이 맞다」 둘이다.
    # ⚠️ 이름 표기만 같은 것(2점)으로는 안 고른다 — `(주)프레스코` 와
    #    `주식회사 프레스코` 는 표기가 다를 뿐, 같은 회사일 수도 아주 다른 회사일
    #    수도 있다. 그 정도로 찍었다가 엉뚱한 회사의 감사보고서가 조서에 붙는
    #    것이 이 기능에서 가장 나쁜 일이다.
    if best[0] > runner[0] and best[0] >= 4:
        logger.info("DART 회사 자동 판별: %s (%s점) — %s",
                    best[1]["corp_code"], best[0], best[2].get("ceo_nm"))
        return best[1]

    raise AmbiguousCompany(
        f"'{name}' 이라는 이름의 회사가 DART 에 {len(candidates)}곳 있습니다. "
        "대표자·업종으로도 가려지지 않아 멈췄습니다 — 어느 회사인지 골라 주세요.",
        [
            {
                "corp_code": candidate["corp_code"],
                "corp_name": str(profile.get("corp_name") or candidate["corp_name"]),
                "ceo_nm": str(profile.get("ceo_nm") or ""),
                "adres": str(profile.get("adres") or ""),
                "induty_code": str(profile.get("induty_code") or ""),
                "est_dt": str(profile.get("est_dt") or ""),
                "acc_mt": str(profile.get("acc_mt") or ""),
                "bizr_no": str(profile.get("bizr_no") or ""),
                "jurir_no": str(profile.get("jurir_no") or ""),
                "score": score,
            }
            for score, candidate, profile in scored
        ],
    )


# ── 2. 감사보고서 찾기 ─────────────────────────────────────────────────

# ⚠️ 회사마다 감사보고서가 **다른 자리에** 있다 (2026-09-02 실측).
#
#   포레스코(비상장)  「외부감사관련(F)」에 **감사보고서** 공시가 따로 있다
#   삼성전자(상장)    F 가 **0건**. 감사보고서는 「사업보고서(A)」의 **첨부**다
#
# 그래서 두 길을 다 본다. F 를 먼저 보고, 없으면 그 결산기의 사업보고서를 집는다.
AUDIT_WORD = re.compile(r"감\s*사\s*보\s*고\s*서")
ANNUAL_WORD = re.compile(r"사\s*업\s*보\s*고\s*서")


async def _list(
    client: httpx.AsyncClient, key: str, corp_code: str,
    start: str, end: str, kind: str,
) -> list[dict[str, Any]]:
    response = await client.get(f"{OPENDART}/list.json", params={
        "crtfc_key": key, "corp_code": corp_code,
        "bgn_de": start, "end_de": end, "pblntf_ty": kind, "page_count": "100",
    })
    response.raise_for_status()
    payload = response.json()
    if str(payload.get("status")) == "013":     # 그 구분에는 공시가 없다
        return []
    _check_status(payload)
    return list(payload.get("list") or [])


async def _find_filing(
    client: httpx.AsyncClient, key: str, corp: dict[str, str], base_dt: str,
) -> Filing:
    """결산일자 뒤 15개월 안에서 감사보고서가 든 공시 하나.

    감사보고서는 결산일 뒤 몇 달 지나 올라온다(12월 결산이면 이듬해 3월).
    그래서 **결산일부터 앞으로** 훑는다. 넉넉히 15개월을 본다 — 지연 제출과
    재감사가 있다.
    """
    start = datetime.strptime(base_dt, "%Y%m%d").date()
    end = start + timedelta(days=460)
    bgn, fin = start.strftime("%Y%m%d"), end.strftime("%Y%m%d")

    def make(item: dict[str, Any]) -> Filing:
        return Filing(
            corp_code=corp["corp_code"], corp_name=corp["corp_name"],
            report_nm=str(item.get("report_nm") or "").strip(),
            rcept_no=str(item.get("rcept_no") or "").strip(),
            rcept_dt=str(item.get("rcept_dt") or "").strip(),
            flr_nm=str(item.get("flr_nm") or "").strip(),
        )

    # 1) 외부감사관련 — 감사보고서 공시가 따로 있는 회사(대부분의 비상장사)
    audits = [i for i in await _list(client, key, corp["corp_code"], bgn, fin, "F")
              if AUDIT_WORD.search(str(i.get("report_nm") or ""))]
    if audits:
        audits.sort(key=lambda i: str(i.get("rcept_dt") or ""))
        return make(audits[0])

    # 2) 정기공시 — 그 결산기의 사업보고서. 감사보고서가 **첨부**로 붙어 있다.
    #    `report_nm` 이 `사업보고서 (2023.12)` 꼴이라 결산연월으로 가른다.
    #    ⚠️ 연월을 안 보면 다음 해 사업보고서를 집어 **한 해 어긋난** 감사보고서가
    #       조서에 붙는다.
    period = f"{base_dt[:4]}.{base_dt[4:6]}"
    regular = await _list(client, key, corp["corp_code"], bgn, fin, "A")
    annual = [i for i in regular
              if ANNUAL_WORD.search(str(i.get("report_nm") or ""))
              and period in str(i.get("report_nm") or "")]
    if annual:
        annual.sort(key=lambda i: str(i.get("rcept_dt") or ""))
        return make(annual[0])

    # 3) 드물게 정기공시 쪽에 이름부터 감사보고서인 것이 있다.
    named = [i for i in regular if AUDIT_WORD.search(str(i.get("report_nm") or ""))]
    if named:
        named.sort(key=lambda i: str(i.get("rcept_dt") or ""))
        return make(named[0])

    raise DartError(
        f"{corp['corp_name']} 의 {period} 결산 감사보고서를 DART 에서 찾지"
        " 못했습니다. 외부감사 대상이 아니거나 아직 제출 전일 수 있습니다."
    )


# ── 3·4. 공시뷰어에서 PDF ──────────────────────────────────────────────

# ⚠️ 문서번호를 **`viewDoc(...)` 에서** 읽는다. 2026-09-02 실측:
#
#     viewDoc("20260401004873", "11230958", …)      ← 본문  = 감사보고서
#     <option value="rcpNo=…&dcmNo=11230959">       ← 첨부  = 기업개황자료
#
# 처음에는 `dcmNo=(\d+)` 로 그냥 첫 번째를 잡았는데, 그 꼴로 적혀 있는 것은
# **첨부 고르는 드롭다운**이라 담당부서가 누를 때마다 「기업개황자료」가
# 내려왔다. 본문은 `viewDoc("rcpNo", "dcmNo", …)` 로 적힌다 — 모양이 다르다.
_MAIN_DOC = re.compile(r'viewDoc\(\s*"(\d+)"\s*,\s*"(\d+)"')
_ATTACH = re.compile(r"dcmNo=(\d+)")
_ROW = re.compile(r'<td class="tL">([^<]+)</td>')
_LINK = re.compile(r'href="(/pdf/download/pdf\.do\?[^"]+)"')


def _pdf_choices(html: str) -> list[tuple[str, str]]:
    """내려받기 안내 화면의 `(파일 이름, 링크)` 목록. 짝이 맞는 것만."""
    names = [name.strip() for name in _ROW.findall(html)]
    links = [link.replace("&amp;", "&") for link in _LINK.findall(html)]
    return list(zip(names, links))


async def _fetch_pdf(client: httpx.AsyncClient, filing: Filing, want: re.Pattern[str] = AUDIT_WORD) -> tuple[bytes, str]:
    """접수번호로 PDF 바이트와 파일 이름을 얻는다. `want` = 고를 파일 이름 규칙(기본 「감사보고서」, 회계법인 사업보고서는 「사업보고서」).

    ⚠️ 세 걸음을 **한 세션 안에서** 밟아야 한다. `pdf.do` 를 곧바로 부르면
    200 에 0바이트가 온다(실측 2026-09-02). 뷰어가 준 쿠키가 있어야 파일이 나온다.
    """
    viewer = f"{VIEWER}/dsaf001/main.do?rcpNo={filing.rcept_no}"
    page = await client.get(viewer)
    page.raise_for_status()

    # 문서번호를 **본문부터** 모은다. 순서가 곧 우선순위다.
    #   · 감사보고서 공시(F)  → 본문이 감사보고서다
    #   · 사업보고서 공시(A)  → 본문은 사업보고서고 **첨부**에 감사보고서가 있다
    # 그래서 둘 다 훑고, 이름에 「감사보고서」가 든 것을 고른다.
    main = _MAIN_DOC.search(page.text)
    numbers: list[str] = []
    if main:
        numbers.append(main.group(2))
    for found in _ATTACH.finditer(page.text):
        if found.group(1) not in numbers:
            numbers.append(found.group(1))
    if not numbers:
        raise DartError(
            "공시뷰어에서 문서번호를 찾지 못했습니다. 전자공시 화면이 바뀌었을 수"
            f" 있습니다. 직접 보시려면: {viewer}"
        )

    first: tuple[str, str, httpx.URL] | None = None
    for dcm_no in numbers[:MAX_DOCS]:
        listing = await client.get(
            f"{VIEWER}/pdf/download/main.do",
            params={"rcp_no": filing.rcept_no, "dcm_no": dcm_no, "lang": "ko"},
            headers={"Referer": viewer},
        )
        listing.raise_for_status()
        choices = _pdf_choices(listing.text)
        if not choices:
            continue
        for name, link in choices:
            if want.search(name):
                first = (name, link, listing.url)
                break
        if first and want.search(first[0]):
            break
        if first is None:
            # 아무 데도 감사보고서가 없으면 본문 첫 장이라도 준다.
            first = (choices[0][0], choices[0][1], listing.url)

    if first is None:
        raise DartError(
            "이 공시에는 내려받을 PDF 가 없습니다. 직접 보시려면: " + viewer
        )
    name, link, referer = first
    # 이름은 여기서 읽는다. 응답 헤더의 이름은 EUC-KR 이라 깨져서 온다(실측).
    filename = name or f"{filing.report_nm}.pdf"

    pdf = await client.get(VIEWER + link, headers={"Referer": str(referer)})
    pdf.raise_for_status()
    if not pdf.content.startswith(b"%PDF"):
        raise DartError(
            "전자공시가 PDF 대신 다른 것을 돌려주었습니다. 잠시 뒤 다시 시도하거나"
            f" 직접 보십시오: {viewer}"
        )
    return pdf.content, filename


# ── 바깥에서 부르는 것 ─────────────────────────────────────────────────

async def _resolve_corp(
    client: httpx.AsyncClient, key: str, company_name: str,
    hint: dict[str, str], corp_code: str, cache_dir: Path,
) -> dict[str, str]:
    """회사명(+우리가 아는 것) → DART 고유번호. **이 모듈의 유일한 식별 경로다.**

    ⚠️ 2026-09-16 에 `download_audit_report` 안에 있던 것을 그대로 꺼냈다.
    [안건·후속서류]의 `GET /finstmt/company-info` 가 같은 문제를 푸는데,
    거기서 따로 만들면 **고유번호 캐시가 둘**이 되고 가르는 규칙도 둘이 된다.
    한쪽만 고쳐졌을 때 두 화면이 **다른 회사**를 집는 것이 최악이다.

    같은 이름이 여럿인데 못 가르면 `AmbiguousCompany` 를 낸다 — 자동으로 고르지
    않는다. 잘못 고르면 안건에 남의 법인등록번호가 실린다.
    """
    if corp_code:
        # 사람이 고른 것이다. 이름 대신 그 번호로 곧장 간다.
        profile = await _profile(client, key, corp_code)
        return {
            "corp_code": corp_code,
            "corp_name": str(profile.get("corp_name") or company_name),
            "stock_code": str(profile.get("stock_code") or ""),
        }
    wanted = normalize_name(company_name)
    if not wanted:
        raise DartError("회사명이 비어 있습니다.")
    index = await _corp_index(client, key, cache_dir)
    candidates = index.get(wanted)
    if not candidates:
        raise DartError(
            f"'{company_name}' 을(를) DART 고유번호 목록에서 찾지 못했습니다. "
            "전자공시 대상이 아니거나 등록된 이름이 다를 수 있습니다."
        )
    return await _pick(client, key, candidates, company_name, hint)


async def download_audit_report(
    key: str, company_name: str, base_dt: str, *, cache_dir: Path,
    hint: dict[str, str] | None = None, corp_code: str = "",
) -> tuple[bytes, str, dict[str, str]]:
    """`(PDF 바이트, 파일 이름, 어떻게 찾았는지)`.

    `hint` 는 재무 DB 가 아는 그 회사의 대표자·업종코드·결산일자다. 같은 이름이
    여럿일 때 **이것으로 가른다**(`_pick`).

    `corp_code` 가 오면 회사 찾기를 건너뛴다 — 화면에서 사람이 이미 고른 것이다.

    세 번째 값은 화면이 「무엇을 받았는지」를 말할 수 있게 하는 것이다 —
    이름이 비슷한 회사가 많아, 받은 뒤에 무엇을 받았는지 알 수 있어야 한다.
    """
    if not key:
        raise DartError(
            "DART 인증키가 등록되어 있지 않습니다. "
            "관리자 화면 > 외부 API 키에서 `dart_opendart` 를 등록해 주세요."
        )
    hint = dict(hint or {})
    hint.setdefault("base_dt", base_dt)

    async with httpx.AsyncClient(headers=HEADERS, timeout=TIMEOUT,
                                 follow_redirects=True) as client:
        corp = await _resolve_corp(client, key, company_name, hint, corp_code, cache_dir)

        filing = await _find_filing(client, key, corp, base_dt)
        data, filename = await _fetch_pdf(client, filing)

    return data, filename, filing.as_dict()


async def download_pdf_by_receipt(rcept_no: str, *, want: re.Pattern[str] = AUDIT_WORD,
                                  report_nm: str = "감사보고서") -> tuple[bytes, str]:
    """접수번호 하나로 감사보고서 PDF 를 받는다 — `(PDF 바이트, 파일 이름)`.

    「오류검증(검토)2」의 ② 감사보고서 자리에서 쓴다(담당부서 요청, 2026-09-22): 담당자가
    공시뷰어 주소를 붙여넣으면 그 접수번호의 PDF 를 받아 조치안과 맞춘다. 회사 찾기·목록
    조회(1·2번 걸음, 인증키 필요)를 건너뛰고 3·4번 걸음만 밟으므로 **인증키가 필요 없다.**
    접수번호는 `dart_finance.receipt_no()` 로 미리 확인한 것을 준다(호스트 검사 포함).
    """
    if not re.fullmatch(r"\d{14}", rcept_no or ""):
        raise DartError("14자리 접수번호가 아닙니다.")
    filing = Filing(corp_code="", corp_name="", report_nm=report_nm, rcept_no=rcept_no,
                    rcept_dt="", flr_nm="")
    async with httpx.AsyncClient(headers=HEADERS, timeout=TIMEOUT,
                                 follow_redirects=True) as client:
        return await _fetch_pdf(client, filing, want)


async def company_profile(
    key: str, company_name: str, base_dt: str, *, cache_dir: Path,
    hint: dict[str, str] | None = None, corp_code: str = "",
) -> tuple[dict[str, Any], dict[str, str]]:
    """`(기업개황, 어떤 회사로 잡았는지)`. 회사 찾기는 `download_audit_report` 와 **같은 길**이다.

    안건·후속서류에 필요한데 사내 재무 DB 에는 없는 값들을 DART 「기업개황」에서
    가져온다 — 법인등록번호·사업자등록번호·설립일·주소·결산월.

    ⚠️ 감사보고서 받기와 **같은 `_resolve_corp` 를 쓴다.** 고유번호 목록 캐시도,
    같은 이름을 가르는 규칙도 하나다. 둘로 나뉘면 두 화면이 같은 회사를 다르게
    집을 수 있고, 안건에는 그 결과가 법인등록번호로 박힌다.

    못 가르면 `AmbiguousCompany` 가 후보를 들고 올라간다 — 화면이 늘어놓고
    사람이 고른 뒤 `corp_code` 로 다시 부른다.
    """
    if not key:
        raise DartError(
            "DART 인증키가 등록되어 있지 않습니다. "
            "관리자 화면 > 외부 API 키에서 `dart_opendart` 를 등록해 주세요."
        )
    hint = dict(hint or {})
    hint.setdefault("base_dt", base_dt)

    async with httpx.AsyncClient(headers=HEADERS, timeout=TIMEOUT,
                                 follow_redirects=True) as client:
        corp = await _resolve_corp(client, key, company_name, hint, corp_code, cache_dir)
        # `_resolve_corp` 가 `corp_code` 로 간 경우 개황을 이미 한 번 받았지만,
        # 그 값을 들고 나오지 않는다. 한 번 더 받는 편이 이름으로 온 경우와
        # 같은 길이 되어 읽기 쉽다(개황은 가볍고 20,000회/일 안에서 한 번이다).
        profile = await _profile(client, key, corp["corp_code"])

    return profile, corp


def company_fields(profile: dict[str, Any], corp: dict[str, str], fallback_name: str = "") -> dict[str, Any]:
    """기업개황 원본 → 화면이 쓰는 칸들.

    ⚠️ 이름은 프로토타입(`server_patch/finstmt_company_info.py`)이 정한 그대로다 —
    화면의 `applyCompanyInfo` 가 이 이름으로 읽는다. 바꾸면 화면이 조용히 빈칸이 된다.

    `founded_text` 는 안건 회사 개요에 그대로 들어가는 모양이다(`2011.3.2.`).
    """
    est = str(profile.get("est_dt") or "").strip()
    return {
        "name": str(profile.get("corp_name") or corp.get("corp_name") or fallback_name),
        "ceo": str(profile.get("ceo_nm") or ""),
        "corp_no": str(profile.get("jurir_no") or ""),      # 법인등록번호
        "biz_no": str(profile.get("bizr_no") or ""),        # 사업자등록번호
        "founded": est,                                     # YYYYMMDD
        "founded_text": f"{est[:4]}.{int(est[4:6])}.{int(est[6:8])}." if len(est) == 8 and est.isdigit() else "",
        "address": str(profile.get("adres") or ""),
        "acc_month": str(profile.get("acc_mt") or ""),
        "corp_code": corp.get("corp_code", ""),
        "homepage": str(profile.get("hm_url") or ""),
    }
