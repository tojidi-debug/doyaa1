"""전자공시 **원문에서 재무수치**를 읽는다 — 접수번호로 못 박아서 (2026-09-17).

HEMNA 로컬본(`docs/hemna/dart_finance.py`)을 옮긴 것이다. 옮긴 뒤에도 같은 수치가
나오는지는 `backend/scripts/dart_finance_check.py` 가 그 폴더의 공시 원문을 읽어
견준다.

## 왜 「재무정보 API」를 안 쓰나 — 이것이 이 모듈의 존재 이유다

안건은 **수정 전 감사보고서의 금액**으로 쓴다. 그런데 OpenDART 의 재무정보 API
(`fnlttSinglAcnt` 따위)도, 우리 재무 DB 도 **지금 유효한 값**을 준다. 회사가
재감사를 받아 정정공시를 내면 그 값은 **정정 후 금액**으로 바뀌어 있다. 그것을
그대로 안건에 실으면 지적 대상이 아닌 숫자로 조치안을 쓰게 된다.

그래서 여기서는 **사람이 지정한 접수번호 하나**의 원문(`document.xml`)만 읽는다.

  · 최신본으로 **자동 대체하지 않는다.**
  · 어느 발행본을 쓸지는 화면에서 **사람이 고른다**(`report_versions` 가 목록을 준다).
  · `last_reprt_at=N` 으로 **모든 발행본**을 받는다. `Y` 면 최초 제출본이 숨는다.

## 읽지 못하면 **비워 둔다**

원문은 회사마다 표가 다르다. 단위가 「천원」인 곳도 「백만원」인 곳도 있고, 한 해가
두 칸(소계·합계)을 차지하기도 한다. 그래서 확정할 수 없는 자리는 **추측하지 않고
버린다** — 칸에서 숫자가 둘 이상 나오면 그 항목을 건너뛰고, 본표·연도·단위를 못
정하면 아예 오류를 낸다. 화면은 그때 「엑셀에서 붙여넣기」로 넘어간다.

잘못 읽은 금액이 조용히 조치안에 실리는 것보다 **안 읽히는 것이 낫다.**
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import re
import zipfile
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

import httpx
from lxml import etree

from gumiho.integrations.external.dart import (
    HEADERS,
    OPENDART,
    TIMEOUT,
    VIEWER,
    DartError,
    _check_status,
    _resolve_corp,
    normalize_name,
)

logger = logging.getLogger(__name__)

# 원문 한 건의 상한. 본문에 그림이 많은 감사보고서가 있다.
MAX_DOCUMENT = 32 * 1024 * 1024
MAX_UNPACKED = 64 * 1024 * 1024

# 계정과목 → 우리 재무표의 칸. 회사마다 이름이 달라 여러 이름을 한 칸으로 모은다.
FIELDS = {
    "자산총계": "assets", "자산총액": "assets", "총자산": "assets",
    "부채총계": "liabilities",
    "자본총계": "equity", "자기자본": "equity",
    "자본금": "capital",
    "매출액": "sales", "수익매출액": "sales",
    "매출원가": "cogs",
    "당기순이익": "netIncome", "당기순손실": "netIncome", "당기순이익손실": "netIncome",
    # 연결손익계산서는 「Ⅹ. 연결당기순이익」으로 적는다(부천공업㈜ 연결감사보고서, 2026-09-28)
    "연결당기순이익": "netIncome", "연결당기순손실": "netIncome", "연결당기순이익손실": "netIncome",
    "당기순손익": "netIncome", "연결당기순손익": "netIncome",
    "이자부차입금": "borrowings",
}

# 회사마다 계정 이름이 다르다(사용자 지정, 2026-09-29: 「매출액은 영업수익, 매출원가는 영업비용 등 다른
# 이름으로 들어가 있어도 그게 그 계정이다」). 아래는 **제 이름(FIELDS)이 그 표에 없을 때** 대신 읽는 이름이다 —
# 제 이름이 같은 표에 함께 있으면 제 이름의 금액을 쓴다(둘 다 읽어 「수치가 다르다」로 멈추지 않게).
FALLBACK = {
    "자산합계": "assets", "자산계": "assets",
    "부채총액": "liabilities", "총부채": "liabilities", "부채합계": "liabilities", "부채계": "liabilities",
    "자본총액": "equity", "총자본": "equity", "자본합계": "equity", "자본계": "equity", "순자산": "equity",
    "납입자본": "capital", "납입자본금": "capital", "보통주자본금": "capital", "출자금": "capital",
    "영업수익": "sales", "매출": "sales", "수익": "sales", "수익합계": "sales", "영업수익합계": "sales",
    "순매출액": "sales", "총매출액": "sales", "매출액합계": "sales", "사업수익": "sales",
    "영업비용": "cogs", "매출원가합계": "cogs", "영업비용합계": "cogs", "사업비용": "cogs",
    "당기순이익순손실": "netIncome", "당기순손실순이익": "netIncome", "당기순손익순손실": "netIncome",
    "연결당기순이익순손실": "netIncome", "연결당기순손익순손실": "netIncome",
    "총당기순이익": "netIncome", "총당기순손익": "netIncome", "당기운영이익": "netIncome",
    "당기순이익연결": "netIncome",
}


def field_of(name: str) -> tuple[str | None, int]:
    """계정 이름 → (칸, 차례). 차례 0 = 제 이름, 1 = 대신 읽는 이름. 모르는 이름은 `(None, 9)`."""
    if name in FIELDS:
        return FIELDS[name], 0
    if name in FALLBACK:
        return FALLBACK[name], 1
    return None, 9


def is_debt(name: str) -> bool:
    """이자부차입금에 더할 계정인가 — 아래 DEBT 의 이름이거나 「…차입금」으로 끝나는 계정.

    「국민주택기금차입금」·「관계회사단기차입금」처럼 회사마다 이름이 붙는다(석미건설㈜, 2026-09-29).
    합계 줄(차입금합계·차입금계)은 더하지 않는다 — 이중계상이다.
    """
    if name in DEBT:
        return True
    return bool(re.search(r"차입금$", name)) and name != "이자부차입금" and not re.search(r"합계|총계", name)


# 이자부차입금은 재무상태표에 **그 이름으로 서 있는 일이 드물다.** 아래 항목들의
# 장부금액을 더해서 만든다. ⚠️ 이름이 겹치는 조합(리스부채 ↔ 유동/비유동리스부채,
# 유동성장기부채 ↔ 유동성장기차입금)이 보이면 **더하지 않고 알린다** — 이중계상이다.
DEBT = {
    "단기차입금", "장기차입금", "유동성장기부채", "유동성장기차입금",
    "사채", "유동성사채", "전환사채", "유동성전환사채",
    "신주인수권부사채", "유동성신주인수권부사채",
    "리스부채", "유동리스부채", "비유동리스부채", "유동성리스부채",
    "금융리스부채", "유동성금융리스부채",
    "사채할인발행차금", "유동성사채할인발행차금",
}

# 원문의 단위 → 천원 배수. 화면·저장은 천원으로 맞춘다.
SCALE = {"원": Decimal("0.001"), "천원": Decimal(1), "백만원": Decimal(1000)}


def receipt_no(value: str) -> str:
    """공시뷰어 주소 또는 14자리 접수번호 → 접수번호.

    주소를 통째로 붙여넣는 것이 사람이 실제로 하는 일이라 둘 다 받는다. 다만
    **호스트를 확인한다** — 아무 주소나 받으면 우리 서버가 남의 주소를 대신
    열어 주는 창구가 된다.
    """
    text = str(value or "").strip()
    if re.fullmatch(r"\d{14}", text):
        return text
    url = urlsplit(text)
    if url.scheme not in ("https", "http") or url.hostname not in (
            "dart.fss.or.kr", "m.dart.fss.or.kr"):
        raise DartError("DART 감사보고서 주소 또는 14자리 접수번호를 입력하세요.")
    number = parse_qs(url.query).get("rcpNo", [""])[0]
    if not re.fullmatch(r"\d{14}", number):
        raise DartError("주소에 올바른 접수번호(rcpNo)가 없습니다.")
    return number


def amount(value: str) -> Decimal | None:
    """표의 한 칸 → 금액. 읽을 수 없으면 `None`(추측하지 않는다).

    `△`·`▲`·`(1,234)` 는 음수다. `-` 한 글자는 0 이다(비어 있음이 아니라 「없음」).
    """
    text = re.sub(r"\s+", "", str(value))
    if not text:
        return None
    if text in ("-", "—", "–"):
        return Decimal(0)
    if not re.fullmatch(r"[△▲−-]?\(?[\d,]+(?:\.\d+)?\)?", text):
        return None
    negative = bool(re.match(r"[△▲−(-]", text))
    return Decimal(re.sub(r"[^\d.]", "", text)) * (-1 if negative else 1)


def _text(element: Any) -> str:
    return " ".join("".join(element.itertext()).split())


def _label(value: str) -> str:
    """계정과목 이름 씻기 — 주석 번호·로마숫자·괄호·가운뎃점을 걷는다."""
    text = re.sub(r"\([^)]*주[^)]*\)|\(주석[^)]*\)", "", value)
    # 「(1) 자본금」·「1) 자본금」·「① 자본금」·「가. 자본금」 — 앞의 번호를 뗀다(석미건설㈜ 연결: 「(1) 자본금」이 「1자본금」이 되어 못 읽었다)
    text = re.sub(r"^\s*(?:[(（]\s*(?:\d+|[가-힣])\s*[)）]|\d+\s*\)|[①-⑳]|[가-힣]\s*\.(?!\d))\s*", "", text)
    text = re.sub(r"^[\sⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫIVX\d.]+", "", text)
    return re.sub(r"[\s()·ㆍ]", "", text)


# ── 주석 「1. 회사의 개요」 ──────────────────────────────────────────────────
# 실측(㈜콘포테크 2025-03-28 제출본, 14쪽):
#     1.회사의 개요
#     (1) 설립일자 : 2008년 1월 17일
#     (2) 본사소재지 : 경기도 양주시 광적면 현석로42-38
#     (3) 주요영업내용 : 음식물쓰레기종량기 및 감량기 제조업
#     (4) 대표이사 : 신현목
#     (5) 주요주주 및 지분율 :
#     …
#     주주명 주식수(주) 지분율(%) 비고
#     신현목 298,143 76.2% 대표이사
#
# 「(2)」 같은 번호는 보고서마다 다르므로 **말**로 찾는다. 못 찾으면 그 칸은
# 비워 둔다 — 숫자와 같은 규칙이다. 추측해서 채우지 않는다.
PROFILE_KEYS: tuple[tuple[str, str], ...] = (
    ("founded", r"설\s*립\s*(?:일자|연월일|일)"),
    ("address", r"(?:본\s*사|본\s*점)\s*(?:소\s*재\s*지|주\s*소)"),
    ("industry", r"주\s*요\s*영\s*업\s*내\s*용|주\s*된\s*영\s*업|사\s*업\s*의\s*내\s*용|업\s*종"),
    ("ceo", r"대\s*표\s*이\s*사(?!\s*및)"),
)
# 「신현목 298,143 76.2% 대표이사」 — 이름 · 주식수 · 지분율
SHARE_ROW = re.compile(
    r"^\s*(?P<name>[^\d\s][^\d]{0,30}?)\s+(?P<shares>\d[\d,]*)\s+(?P<pct>\d{1,3}(?:\.\d+)?)\s*%")
SHARE_SKIP = re.compile(r"소\s*계|합\s*계|보\s*통\s*주|우\s*선\s*주|기\s*타|주\s*주\s*명")


def _profile_of(pages: list[str]) -> dict[str, str]:
    """주석 「회사의 개요」에서 설립일·본점 소재지·업종·대표이사·최대주주를 읽는다.

    감사보고서에 적힌 그대로다. 전자공시 기업개황(`dart.company_profile`)은 **오늘의**
    회사를 말하고 이름으로 찾기 때문에 같은 이름의 다른 회사를 집을 수 있다 —
    담당자가 붙인 그 보고서가 조치대상 연도의 회사다(사용자 지정, 2026-09-19).
    """
    found: dict[str, str] = {}
    for index, text in enumerate(pages):
        if not re.search(r"회\s*사\s*의\s*개\s*요", text):
            continue
        lines = text.splitlines()
        for line in lines:
            for key, pattern in PROFILE_KEYS:
                if key in found:
                    continue
                # ⚠️ 반드시 묶는다 — `가|나` 를 그냥 끼워 넣으면 `|` 가 바깥까지 갈라
                #    「^.*?주요영업내용」 과 「업종\s*[:：]」 이 따로 놀아 값 앞에 「: 」 가 남았다.
                if not re.search(rf"(?:{pattern})\s*[:：]", line):
                    continue
                value = re.sub(rf"^.*?(?:{pattern})\s*[:：]", "", line, count=1).strip(" \t·:：")
                value = re.sub(r"\s+", " ", value).strip()
                if value:
                    found[key] = value[:200]
        # 주주표는 개요와 같은 쪽이거나 바로 다음 쪽에 온다.
        if "shareholder" not in found:
            for text2 in pages[index:index + 2]:
                best: tuple[float, str] | None = None
                for line in text2.splitlines():
                    hit = SHARE_ROW.match(line.strip())
                    if not hit:
                        continue
                    name = hit.group("name").strip()
                    if not name or SHARE_SKIP.search(name):
                        continue
                    pct = float(hit.group("pct"))
                    if pct > 100:
                        continue
                    if best is None or pct > best[0]:
                        best = (pct, name)
                if best:
                    found["shareholder"] = best[1]
                    found["shareholderPct"] = f"{best[0]:g}"
                    break
        if found:
            break
    return found


def parse_document(raw: bytes, number: str) -> dict[str, Any]:
    """공시 원문 XML → `{statements, sources, periods, …}`. **바깥을 부르지 않는다.**

    순수 함수라 시험이 파일 하나로 돈다(`dart_finance_check.py`).

    ⚠️ `resolve_entities=False` · `no_network=True` 는 지운 적이 없다 — 남이 만든
       XML 을 파싱하는 자리다(XXE).
    """
    parser = etree.XMLParser(recover=True, resolve_entities=False,
                             no_network=True, huge_tree=False)
    root = etree.fromstring(raw, parser)
    if root is None:
        raise DartError("공시 원문을 읽을 수 없습니다.")

    company = root.findtext(".//COMPANY-NAME") or ""
    report_name = root.findtext(".//DOCUMENT-NAME") or ""
    statements: dict[str, dict[str, dict[str, float]]] = {}
    sources: dict[str, dict[str, dict[str, Any]]] = {}
    period_map: dict[int, int] = {}
    warnings: list[str] = []

    last_unit = ""
    for table in root.iter("TABLE"):
        group = table.getparent()
        if group is None:
            continue
        title = re.sub(r"\s+", "", " ".join(_text(e) for e in group.findall("./TITLE")))
        if re.search(r"재무상태표|대차대조표|손익계산서", title):
            # 표 앞에 오는 글(제목 다음, 표 앞)에 **단위와 사업연도**가 적혀 있다.
            children = list(group)
            prefix = " ".join(_text(el) for el in children
                              if el is not table and children.index(el) < children.index(table))
        else:
            # 본표에 제목(TITLE)이 따로 없는 원문(2026-09-29, 레보메드 20250409001068·1069):
            # 「(첨부)재무제표」 구역 안에 **테두리 없는 머리 표**(재무제표 이름·기수·회사·단위)가 오고
            # 바로 뒤에 금액 표가 온다. 그 머리 표를 제목과 앞글로 쓴다. 주석의 표는 구역이
            # 달라(SECTION-2) 여기 걸리지 않는다.
            if "재무제표" not in title or table.find("./THEAD/TR") is None:
                continue
            head = table.getprevious()
            while head is not None and head.tag == "P" and not _text(head).strip():
                head = head.getprevious()
            if head is None or head.tag != "TABLE" or head.find("./THEAD") is not None:
                continue
            first = head.find(".//TR")
            name = re.sub(r"\s+", "", _text(first) if first is not None else "")
            if not re.search(r"재무상태표|대차대조표|손익계산서", name) or len(name) > 20:
                continue
            title = name
            prefix = _text(head)
        if not prefix:
            continue
        units = re.findall(r"단위\s*[:：]\s*(백만원|천원|원)", prefix)
        if not units and last_unit:
            units = [last_unit]           # 머리글에 단위가 빠진 본표(석미건설㈜ 연결 손익계산서) — 같은 보고서의 앞 본표 단위를 쓴다
        if not units:
            continue                      # 단위를 못 읽으면 금액을 못 정한다
        last_unit = units[-1]
        scale = SCALE[units[-1]]

        terms = re.findall(r"제\s*(\d+)\s*[^\n]{0,18}?기\s*((?:19|20)\d{2})년", prefix)
        # 「제 16(당) 기말 : 2024년 12월 31일 현재」 · 「제 16(당) 기 : 2024년 01월 01일부터」 꼴
        terms += re.findall(
            r"제\s*(\d+)\s*\(\s*[당전]\s*\)\s*기\s*말?\s*[:：]\s*((?:19|20)\d{2})\s*년", prefix)
        years = list(dict.fromkeys(int(y) for y in re.findall(r"((?:19|20)\d{2})\s*년", prefix)))
        if not 1 <= len(years) <= 4:
            continue
        for term, year in terms:
            period_map[int(year)] = int(term)

        basis = "con" if "연결" in title or ("연결" in report_name and "별도" not in title) else "indi"

        header = table.find("./THEAD/TR")
        if header is None:
            continue
        # 한 해가 두 칸(소계·합계)을 차지하는 표가 있다. COLSPAN 을 그대로 센다.
        groups: list[tuple[int, int]] = []
        others: list[tuple[int, int]] = []     # 과목·주석이 아닌 칸 전부(머리글이 비었거나 잘못 적힌 표에 쓴다)
        offset = 0
        for index, cell in enumerate([c for c in header if c.tag in ("TH", "TD", "TE")]):
            span = int(cell.get("COLSPAN", "1"))
            if re.search(r"제\s*\d+|당기|전기|20\d{2}", _text(cell)):
                groups.append((offset, offset + span))
            if index and not re.search(r"주\s*석|과\s*목|구\s*분", _text(cell)):
                others.append((offset, offset + span))
            offset += span
        if len(groups) != len(years) and len(others) == len(years):
            # 머리글 한 칸이 비었거나 기수가 잘못 적힌 표(석미건설㈜ 2023 연결 손익계산서: 「(빈칸)」·「제 34(당) 기」) —
            # 금액 칸의 수가 해의 수와 같으면 앞글에 적힌 해의 차례대로 짝짓는다.
            groups = others
        if len(groups) != len(years):
            continue                      # 머리글과 해의 수가 안 맞으면 짝지을 수 없다

        values: dict[int, dict[str, Decimal]] = {y: {} for y in years}
        debts: dict[int, list[dict[str, Any]]] = {y: [] for y in years}
        ranks: dict[int, dict[str, int]] = {y: {} for y in years}
        for row in table.findall("./TBODY/TR"):
            cells = [c for c in row if c.tag in ("TD", "TE", "TH")]
            if not cells:
                continue
            name = _label(_text(cells[0]))
            field, rank = field_of(name)
            if not field and not is_debt(name):
                continue
            expanded: list[str] = []
            for cell in cells:
                expanded += [_text(cell)] * int(cell.get("COLSPAN", "1"))
            for year, (start, end) in zip(years, groups, strict=True):
                found = [amount(v) for v in expanded[start:end]]
                found = list(dict.fromkeys(v for v in found if v is not None))
                if len(found) != 1:
                    continue              # ⚠️ 애매한 칸은 **추측하지 않는다**
                value = found[0] * scale
                if field:
                    had = ranks[year].get(field)
                    if had is not None and had < rank:
                        continue          # 제 이름으로 이미 읽었다 — 대신 읽는 이름은 버린다
                    if had is not None and had == rank and values[year][field] != value:
                        if rank:
                            continue      # 대신 읽는 이름끼리 다르면 먼저 읽은 것을 둔다
                        raise DartError("원문에서 같은 계정의 수치가 중복됩니다. 원문 표를 확인하세요.")
                    values[year][field] = value
                    ranks[year][field] = rank
                elif value < 0 and "할인발행차금" not in name:
                    continue              # 자산에서 빼는 꼴로 적힌 차입금(음수)은 더하지 않는다 — 부채 쪽 금액만(석미건설㈜ 2023)
                else:
                    debts[year].append({"label": name, "value": float(value)})

        needed = ({"assets", "equity", "liabilities"}
                  if re.search(r"재무상태표|대차대조표", title)
                  else {"sales", "netIncome"})
        if not any(needed.issubset(v) for v in values.values()):
            continue                      # 본표가 아니라 주석의 표다

        for year, found in values.items():
            if not found:
                continue
            target = statements.setdefault(basis, {}).setdefault(str(year), {})
            for field, value in found.items():
                if field in target and target[field] != float(value):
                    raise DartError("서로 다른 재무제표 수치가 발견되었습니다. 자동 반영을 중단했습니다.")
                target[field] = float(value)
            record = sources.setdefault(basis, {}).setdefault(str(year), {"tables": []})
            record["tables"].append({"title": title, "unit": units[-1], "fields": list(found)})
            if debts[year] and "borrowings" not in target:
                names = {d["label"] for d in debts[year]}
                if (("리스부채" in names and names & {"유동리스부채", "비유동리스부채", "유동성리스부채"})
                        or ("유동성장기부채" in names and "유동성장기차입금" in names)):
                    warnings.append(f"{year}년 차입금 항목이 겹쳐 합산하지 않았습니다.")
                else:
                    target["borrowings"] = float(sum(Decimal(str(d["value"])) for d in debts[year]))
                    record["debt_components"] = debts[year]
                    # ⚠️ 이 문장은 원본과 **글자까지 같게** 둔다. 화면의 근거 상자에
                    #    그대로 나오고, `dart_finance_check.py` 가 결과를 통째로 견준다.
                    record["debt_note"] = (
                        "재무상태표에 표시된 차입금·사채·리스부채와 할인발행차금의 장부금액 "
                        "합계. 주석 및 이자부 여부 확인 필요.")

    if not statements:
        raise DartError(
            "원문의 본표·연도·단위를 확정하지 못했습니다. 자동 반영하지 않습니다. "
            "원문을 확인한 뒤 엑셀에서 붙여넣어 주세요.")

    order = sorted({int(y) for basis in statements.values() for y in basis}, reverse=True)
    # 주석 「회사의 개요」 — 업종·본점 소재지·최대주주. PDF 와 같은 읽개를 쓴다
    # (사용자 지정, 2026-09-19: 회사 개요는 전자공시 기업개황이 아니라 **그 보고서**
    #  기준으로 맞춘다). XML 에는 쪽이 없으니 글 전체를 한 쪽처럼 넘긴다.
    profile = _profile_of([" \n".join(root.itertext())])

    return {
        "receipt": number,
        "url": f"{VIEWER}/dsaf001/main.do?rcpNo={number}",
        "company": company,
        "report_name": report_name,
        "profile": profile,
        "filed_date": f"{number[:4]}-{number[4:6]}-{number[6:8]}",
        "unit": "천원",
        "statements": statements,
        "sources": sources,
        "periods": [{"year": y, "term": period_map.get(y)} for y in order],
        "warnings": warnings,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "retrieved_at": datetime.now(UTC).isoformat(),
    }


async def fetch_report(key: str, value: str, *, cache_dir: Path | None = None) -> dict[str, Any]:
    """접수번호(또는 공시뷰어 주소) → 그 **한 건**의 재무수치.

    `cache_dir` 을 주면 받은 원문 zip 과 읽은 값을 그대로 남긴다. 나중에 「그때
    무엇을 보고 썼는가」를 되짚을 수 있어야 해서다(안건은 조치의 근거가 된다).
    """
    if not key:
        raise DartError(
            "DART 인증키가 등록되어 있지 않습니다. "
            "관리자 화면 > 외부 API 키에서 `dart_opendart` 를 등록해 주세요.")
    number = receipt_no(value)

    async with httpx.AsyncClient(headers=HEADERS, timeout=TIMEOUT,
                                 follow_redirects=True) as client:
        response = await client.get(f"{OPENDART}/document.xml",
                                    params={"crtfc_key": key, "rcept_no": number})
        response.raise_for_status()
        raw = response.content

    if len(raw) > MAX_DOCUMENT:
        raise DartError("원문 파일이 크기 제한(32MB)을 넘습니다.")
    if not raw.startswith(b"PK"):
        # 오류는 XML 로 온다. 우리 말로 바꿔서 그대로 보여 준다.
        try:
            error = etree.fromstring(raw)
            payload = {"status": error.findtext("status") or "",
                       "message": error.findtext("message") or ""}
        except etree.XMLSyntaxError:
            raise DartError("공시 원문을 받지 못했습니다.") from None
        _check_status(payload)
        raise DartError(f"전자공시: {payload['message'] or '원문을 받지 못했습니다.'}")

    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = [i for i in archive.infolist() if i.filename.lower().endswith(".xml")]
        if sum(i.file_size for i in entries) > MAX_UNPACKED:
            raise DartError("원문 압축 해제 크기가 너무 큽니다.")
        results = []
        for entry in entries:
            # 같은 공시에 첨부문서가 여럿 든다. 접수번호로 시작하는 것이 본문이다.
            if not Path(entry.filename).name.startswith(number):
                continue
            try:
                results.append(parse_document(archive.read(entry), number))
            except DartError:
                continue
        if len(results) != 1:
            raise DartError(
                "지정한 공시에서 재무제표 원문을 하나로 확정하지 못했습니다. "
                "해당 감사보고서 본문 주소를 확인하세요.")
        result = results[0]

    if cache_dir is not None:
        folder = Path(cache_dir)
        folder.mkdir(parents=True, exist_ok=True)
        digest = result["sha256"][:12]
        (folder / f"{number}_{digest}.zip").write_bytes(raw)
        (folder / f"{number}_{digest}.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


async def report_versions(
    key: str, company_name: str, year: int, *, basis: str = "indi",
    fiscal_month: int = 12, cache_dir: Path, hint: dict[str, str] | None = None,
    corp_code: str = "",
) -> dict[str, Any]:
    """그 해 감사보고서의 **발행 이력 전부** — 최초 제출본과 정정본을 함께.

    ⚠️ `last_reprt_at=N` 이다. `Y` 로 부르면 「최종본만」이 와서 **수정 전 보고서가
       목록에서 사라진다.** 이 화면이 풀려는 문제가 바로 그것이라 그 값은 고르는
       것이 아니라 못 박는 것이다.

    고르지도 않는다 — 최초 제출본을 `suggested_receipt` 로 **가리키기만** 하고,
    어느 발행일자를 쓸지는 사람이 정한다. 재감사 뒤 정정본이 여럿인 해가 있고,
    그때 무엇이 「수정 전」인지는 심사 담당자만 안다.
    """
    if not key:
        raise DartError(
            "DART 인증키가 등록되어 있지 않습니다. "
            "관리자 화면 > 외부 API 키에서 `dart_opendart` 를 등록해 주세요.")
    year, fiscal_month = int(year), int(fiscal_month)
    if not 1999 <= year <= date.today().year or not 1 <= fiscal_month <= 12:
        raise DartError("대상 연도·결산월을 확인하세요.")

    # 결산일 **다음 날부터** 훑는다. 그 앞에 올라온 것은 그 해 보고서가 아니다.
    begin = f"{year + 1}0101" if fiscal_month == 12 else f"{year}{fiscal_month + 1:02}01"
    end = date.today().strftime("%Y%m%d")

    async with httpx.AsyncClient(headers=HEADERS, timeout=TIMEOUT,
                                 follow_redirects=True) as client:
        corp = await _resolve_corp(client, key, company_name, dict(hint or {}),
                                   corp_code, cache_dir)
        items: list[dict[str, Any]] = []
        for page in range(1, 21):
            response = await client.get(f"{OPENDART}/list.json", params={
                "crtfc_key": key, "corp_code": corp["corp_code"],
                "bgn_de": begin, "end_de": end, "pblntf_ty": "F",
                "last_reprt_at": "N", "page_count": "100", "page_no": str(page),
                "sort": "date", "sort_mth": "asc",
            })
            response.raise_for_status()
            payload = response.json()
            if str(payload.get("status")) == "013":
                break
            _check_status(payload)
            for item in payload.get("list") or []:
                name = str(item.get("report_nm") or "")
                if "감사보고서" not in name or not re.search(rf"\({year}\.{fiscal_month:02}\)", name):
                    continue
                if ("연결" in name) != (basis == "con"):
                    continue
                items.append({
                    "receipt": item["rcept_no"],
                    "filed_date": item["rcept_dt"],
                    "name": name,
                    "corrected": "정정" in name,
                    "url": f"{VIEWER}/dsaf001/main.do?rcpNo={item['rcept_no']}",
                })
            if page >= int(payload.get("total_page") or 1):
                break
        else:
            raise DartError("보고서 목록이 너무 많아 전체 버전을 확인하지 못했습니다. 정확한 주소를 입력하세요.")

    items.sort(key=lambda x: (x["filed_date"], x["receipt"]))
    return {
        "company": corp["corp_name"],
        "corp_code": corp["corp_code"],
        "year": year,
        "basis": basis,
        "items": items,
        "suggested_receipt": next((i["receipt"] for i in items if not i["corrected"]), None),
        "message": "최초 제출본은 수정 전 후보입니다. 적용할 발행일자와 원문을 직접 확인하세요.",
    }


def same_company(left: str, right: str) -> bool:
    """`㈜콘포테크` 와 `주식회사 콘포테크` 를 같게 본다(화면 경고용)."""
    return normalize_name(left) == normalize_name(right)
