"""감사보고서 원문(전자공시 XML)에서 **계정별 금액**을 읽는다 — 조치사전통지서 비교표용.

`dart_finance.parse_document` 는 우리 재무표의 칸(총자산·자기자본 …)만 읽는다. 조치사전
통지서의 「회사의 회계처리」에는 **토지·건물·이자비용** 같은 계정이 필요하다(사용자 지정,
2026-09-29). 그 금액은 같은 원문의 두 곳에 있다.

  1. 본표(재무상태표·손익계산서) — 계정 줄 × 당기·전기 칸
  2. 주석의 변동내역 표(유형자산 등) — 앞글에 「(당기)」·「(전기)」가 있고
       · 줄이 계정이고 칸에 「기말」이 있거나(줄: 토지 · 칸: 기초·취득·…·기말)
       · 칸이 계정이고 줄에 「기말」이 있다(칸: 토지·건물 · 줄: 기초·…·기말)

규칙은 `dart_finance` 와 같다 — **추측하지 않는다.**
  · 이름이 **똑같은** 계정만(씻은 이름으로 견준다).
  · 단위를 못 읽은 표, 연도를 못 정한 표는 쓰지 않는다.
  · 같은 계정·같은 해에 서로 다른 금액이 나오면 본표를 쓰고, 주석끼리 다르면 버린다.
`parse_document` 는 건드리지 않는다(그 결과는 `dart_finance_check.py` 가 통째로 견준다).
"""
from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from lxml import etree

from gumiho.integrations.external.dart import DartError
from gumiho.integrations.external.dart_finance import SCALE, _label, _text, amount, parse_document

CLOSING = re.compile(r"^(기말|당기말|전기말|기말금액|기말잔액|기말장부금액|장부금액|기말순장부금액|순장부금액)$")
UNIT = re.compile(r"단위\s*[:：]?\s*(백만원|천원|원)")


def _cells(row: Any) -> list[str]:
    out: list[str] = []
    for cell in row:
        if cell.tag in ("TD", "TE", "TH", "TU"):
            out += [_text(cell)] * int(cell.get("COLSPAN", "1") or 1)
    return out


def _before(table: Any, limit: int = 4) -> str:
    """표 앞의 글(단위·당기/전기·제목). 같은 구역의 앞 형제 몇 개만 본다."""
    parts: list[str] = []
    node = table.getprevious()
    while node is not None and len(parts) < limit:
        if node.tag == "TABLE":
            # 테두리 없는 머리 표(단위만 적은 표)는 글로 친다. 자료 표를 만나면 멈춘다.
            if node.find(".//THEAD") is not None or len(list(node.iter("TR"))) > 3:
                break
        text = _text(node)
        if text:
            parts.append(text)
        node = node.getprevious()
    group = table.getparent()
    if group is not None:
        parts += [_text(e) for e in group.findall("./TITLE")]
    return " ".join(parts)


def account_values(raw: bytes, number: str, names: list[str]) -> dict[str, Any]:
    """`names` 의 계정마다 `{해: 금액(천원)}` 과 출처를 돌려준다. 못 읽은 것은 빠진다."""
    base = parse_document(raw, number)          # 당기 연도·기수를 여기서 얻는다(읽는 규칙을 두 벌 만들지 않는다)
    years = [int(p["year"]) for p in base["periods"]]
    if not years:
        raise DartError("원문에서 사업연도를 확정하지 못했습니다.")
    current = max(years)
    terms = {int(p["term"]): int(p["year"]) for p in base["periods"] if p.get("term")}

    def year_of(text: str) -> int | None:
        found = re.search(r"((?:19|20)\d{2})", text)
        if found:
            return int(found.group(1))
        term = re.search(r"제\s*(\d+)", text)
        if term and int(term.group(1)) in terms:
            return terms[int(term.group(1))]
        if re.search(r"당\s*\)?\s*기|당기", text):
            return current
        if re.search(r"전\s*\)?\s*기|전기", text):
            return current - 1
        return None

    want = {_label(n): n for n in names if _label(n)}
    parser = etree.XMLParser(recover=True, resolve_entities=False, no_network=True, huge_tree=False)
    root = etree.fromstring(raw, parser)
    if root is None:
        raise DartError("공시 원문을 읽을 수 없습니다.")
    is_con_report = "연결" in (base.get("report_name") or "")

    main: dict[tuple[str, str, int], set[Decimal]] = {}
    notes: dict[tuple[str, str, int], set[Decimal]] = {}
    moves: dict[tuple[str, str, int], set[Decimal]] = {}   # 주석 변동내역의 기말 = **장부금액**
    where: dict[tuple[str, str, int], str] = {}
    last_unit = ""

    for table in root.iter("TABLE"):
        rows = [_cells(tr) for tr in table.iter("TR")]
        rows = [r for r in rows if r]
        if len(rows) < 2:
            continue
        before = _before(table)
        inside = " ".join(rows[0]) if len(set(rows[0])) == 1 else ""
        unit = UNIT.findall(before + " " + inside)
        title = re.sub(r"\s+", "", before)
        statement = bool(re.search(r"재무상태표|대차대조표|손익계산서", title)) and "주석" not in title[:6]
        if unit:
            last_unit = unit[-1] if statement else last_unit
            scale = SCALE[unit[-1]]
        elif statement and last_unit:
            scale = SCALE[last_unit]
        else:
            continue                       # 단위를 못 읽으면 금액을 못 정한다
        basis = "con" if ("연결" in title or (is_con_report and "별도" not in title)) else "indi"
        if inside:
            rows = rows[1:]
        if len(rows) < 2:
            continue
        head, body = rows[0], rows[1:]

        def put(store: dict, name: str, year: int, value: Decimal, note: str) -> None:
            key = (basis, name, year)
            store.setdefault(key, set()).add(value * scale)
            where.setdefault(key, note)

        # ① 줄 = 계정 · 칸 = 당기/전기(본표와 같은 꼴)
        period_cols: dict[int, list[int]] = {}
        for index, text in enumerate(head):
            if index == 0 or re.search(r"주\s*석|과\s*목|구\s*분", text):
                continue
            year = year_of(text)
            if year is not None and re.search(r"당|전|제\s*\d+|(?:19|20)\d{2}", text):
                period_cols.setdefault(year, []).append(index)
        if period_cols:
            for row in body:
                name = _label(row[0])
                if name not in want:
                    continue
                for year, cols in period_cols.items():
                    found = {amount(row[c]) for c in cols if c < len(row)} - {None}
                    found = {v for v in found}
                    if len(found) == 1 and (statement or next(iter(found)) != 0):
                        # 주석 표의 「-」(0)는 「해당 없음」일 때가 많다 — 본표가 아니면 0 은 읽지 않는다
                        put(main if statement else notes, want[name], year, next(iter(found)),
                            "본표" if statement else "주석 표")
            continue

        # ② ③ 변동내역 표 — 앞글에 (당기)/(전기) 가 있어야 해를 안다
        mark = re.findall(r"[(（<〈]\s*(당기말?|전기말?)\s*[)）>〉]", before)
        if not mark:
            continue
        year = current if mark[0].startswith("당") else current - 1
        labels = [_label(t) for t in head]
        closing_col = next((i for i, t in enumerate(labels) if i and CLOSING.match(t)), None)
        if closing_col is not None:            # ② 줄 = 계정 · 칸에 기말
            for row in body:
                name = _label(row[0])
                if name in want and closing_col < len(row):
                    value = amount(row[closing_col])
                    if value is not None:
                        put(moves, want[name], year, value, "주석 변동내역(기말 장부금액)")
            continue
        closing_row = next((r for r in body if CLOSING.match(_label(r[0]))), None)
        if closing_row is not None:            # ③ 칸 = 계정 · 줄에 기말
            for index, text in enumerate(labels):
                if index and text in want and index < len(closing_row):
                    value = amount(closing_row[index])
                    if value is not None:
                        put(moves, want[text], year, value, "주석 변동내역(기말 장부금액)")

    out: dict[str, dict[str, Any]] = {}
    # 차례: 변동내역의 기말(장부금액) → 본표 → 그 밖의 주석 표.
    # 본표의 건물·기계장치는 **취득원가**로 적히고 감가상각누계액이 따로 붙는 회사가 많다(연안알루미늄 2024:
    # 본표 건물 1,938백만원 · 주석 기말 887백만원). 회사의 회계처리는 장부금액이므로 주석의 기말을 먼저 쓴다.
    for store in (moves, main, notes):
        for (basis, name, year), values in store.items():
            slot = out.setdefault(basis, {}).setdefault(name, {})
            if str(year) in slot or len(values) != 1:
                continue                   # 본표에서 이미 읽었거나, 금액이 갈린다 — 버린다
            slot[str(year)] = {"value": float(next(iter(values))), "from": where[(basis, name, year)]}
    return {"receipt": number, "company": base["company"], "unit": "천원",
            "current_year": current, "accounts": out}
