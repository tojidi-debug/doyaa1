"""[품감] 손해배상준비금 적립 검증 (2026-11-13, 사용자 지정) — 회계법인 사업보고서 값으로, 백만원 단위.

근거: 공인회계사법 제28조제1항 · 같은 법 시행령 제20조 —
  직전 2개 사업연도와 당해 사업연도 **총 매출액 평균의 10%** 에 달할 때까지, **당해 사업연도 총 매출액의 2%** 를 매 사업연도 손해배상준비금으로 적립한다.
확인하는 것:
  ① 한도 미달인데 당기 적립이 필요액(당기 매출액의 2%, 한도 잔여액 한도)보다 적은가(적립 중단 포함)
  ② 적립이 끝난 법인(기초잔액 ≥ 한도)이 계속 적립하거나, 기말잔액이 한도보다 적은가
  ③ 적립액이 전기 매출액 기준(당기 매출액이 아님)으로 보이는가
  ④ 재무상태표 잔액 ↔ 적립현황(기초·당기적립·사용·기말) 산식·대조
특이사항이 없으면 「손해배상준비금 적립 특이사항 없음」. 순수 함수 — 서버(dart_firm)와 브라우저(GitHub 사이트 Pyodide)가 같은 코드를 쓴다.
"""
from __future__ import annotations

from typing import Any

LIMIT = 0.10      # 3개 사업연도 평균 매출액의 10%
ANNUAL = 0.02     # 당해 사업연도 매출액의 2%
TOL = 2.0         # 백만원 반올림 차이(매출·잔액·적립액 각각 ±0.5 반올림이 겹칠 수 있다)


def _n(v: Any) -> float | None:
    return None if v is None else float(v)


def _m(v: float) -> str:
    return f"{round(v):,}"


def check(finance: dict[str, Any], flow: dict[str, Any] | None) -> dict[str, Any]:
    """finance: 재무 값(백만원, 당기·전기·…) — revenue3 = [당기, 전기, 전전기], reserve = [당기말, 전기말]. flow: Ⅴ.1 적립 현황 {begin, add, use, end}."""
    rev = [_n(x) for x in (finance.get("revenue3") or finance.get("revenue") or [])]
    r0 = rev[0] if rev else None
    bal = [_n(x) for x in (finance.get("reserve") or [None, None])]
    fl = flow or {}
    begin = _n(fl.get("begin")) if fl.get("begin") is not None else (bal[1] if len(bal) > 1 else None)
    end = _n(fl.get("end")) if fl.get("end") is not None else bal[0]
    use = _n(fl.get("use")) or 0.0
    if r0 is None or begin is None or end is None:
        return {"status": "na", "summary": "손해배상준비금 적립을 검증하지 못했습니다", "issues": [], "notes": ["사업보고서에서 매출액 또는 손해배상준비금(기초·기말)을 읽지 못했습니다."], "calc": {}}
    add = _n(fl.get("add")) if fl.get("add") is not None else end - begin + use
    add_from_balance = fl.get("add") is None

    years = [x for x in rev[:3] if x is not None]
    avg = sum(years) / len(years)
    cap = avg * LIMIT
    required = r0 * ANNUAL
    complete = begin >= cap - TOL
    expected = 0.0 if complete else max(0.0, min(required, cap - begin))
    issues: list[str] = []
    notes: list[str] = []

    if len(years) < 3:
        notes.append(f"전전기 매출액을 읽지 못해 {len(years)}개 사업연도 평균으로 계산했습니다(확인 필요).")
    if add_from_balance:
        notes.append("적립현황표를 읽지 못해 당기 적립액은 재무상태표 잔액 증가분으로 계산했습니다.")
    calc = {"revenue": [round(x) if x is not None else None for x in rev[:3]], "avg": round(avg), "limit": round(cap), "required": round(required),
            "begin": round(begin), "add": round(add), "use": round(use), "end": round(end), "expected": round(expected), "complete": complete}

    if abs(begin + add - use - end) > TOL + 0.5:
        issues.append(f"잔액 산식 불일치 — 기초 {_m(begin)} + 적립 {_m(add)} − 사용 {_m(use)} = {_m(begin + add - use)}, 기말 {_m(end)}(차이 {round(end - (begin + add - use)):+,}백만원)")
    if len(bal) > 0 and bal[0] is not None and fl.get("end") is not None and abs(bal[0] - end) > TOL:
        issues.append(f"재무상태표 잔액 {_m(bal[0])}과 적립현황 기말잔액 {_m(end)}이 다름(차이 {round(bal[0] - end):+,}백만원)")

    if begin <= TOL and end <= TOL and r0 > 0:
        issues.append(f"적립 없음(잔액 0) — 한도 {_m(cap)}, 당기 필요 {_m(required)}. 보험·공제 가입으로 갈음하는지 확인(공인회계사법 제28조)")
    elif complete:
        if add > TOL:
            notes.append(f"이미 한도 도달(기초 {_m(begin)} ≥ 한도 {_m(cap)}) — 당기 적립 {_m(add)}은 필요액 0 대비 {round(add):+,}백만원")
        if end < cap - TOL:
            issues.append(f"적립 완료 후 기말잔액 {_m(end)}이 한도 {_m(cap)}보다 {_m(cap - end)} 부족(사용 {_m(use)})")
        elif end > cap + TOL:
            notes.append(f"기말잔액 {_m(end)}이 한도 {_m(cap)}를 {_m(end - cap)} 초과(적립 완료 — 추가 적립 불필요)")
    else:
        if add < expected - TOL:
            stop = " — 적립 중단" if add <= TOL else ""
            issues.append(f"추가 적립 필요 — 당기 적립 {_m(add)} < 필요 {_m(expected)}(당기 매출액 {_m(r0)}의 2% = {_m(required)}"
                          f"{', 한도 잔여 ' + _m(cap - begin) if cap - begin < required else ''}), 부족 {_m(expected - add)}백만원{stop}")
        elif add > expected + TOL:
            issues.append(f"초과 적립 — 당기 적립 {_m(add)} > 필요 {_m(expected)}(차이 +{_m(add - expected)}백만원)")
        if len(rev) > 1 and rev[1] is not None and abs(add - rev[1] * ANNUAL) <= TOL and abs(add - required) > TOL and add > TOL:
            issues.append(f"전기 매출액 {_m(rev[1])}의 2%({_m(rev[1] * ANNUAL)})와 일치 — 당기 매출액 기준이 아님")
        if end < cap - TOL:
            notes.append(f"기말잔액 {_m(end)} < 한도 {_m(cap)} — 한도 잔여 {_m(cap - end)}백만원, 계속 적립 필요")
    if use > TOL:
        notes.append(f"당기 사용액 {_m(use)}백만원{(' — ' + str(fl.get('use_note'))) if fl.get('use_note') and fl.get('use_note') != '-' else ''}")

    ok = not issues
    head = "손해배상준비금 적립 특이사항 없음" if ok else f"손해배상준비금 적립 특이사항 {len(issues)}건"
    basis = (f"당기 매출 {_m(r0)} · {len(years)}개년 평균 {_m(avg)} · 한도 10% {_m(cap)} · 기초 {_m(begin)} → 기말 {_m(end)}(당기 적립 {_m(add)}, 필요 {_m(expected)})")
    return {"status": "ok" if ok else "issue", "summary": head, "issues": issues, "notes": notes, "basis": basis, "calc": calc}
