"""GitHub(정적) 사이트 전용 — MarkItDown 대신. PDF 는 pypdf, 워드(.docx)는 문단·표를 마크다운 꼴로(표는 | 칸 | 칸 |)."""
import html
import io
import re
import zipfile


def _docx_markdown(data: bytes) -> str:
    xml = zipfile.ZipFile(io.BytesIO(data)).read("word/document.xml").decode("utf-8", "replace")
    body = re.search(r"<w:body>(.*)</w:body>", xml, re.S)
    xml = body.group(1) if body else xml
    out: list[str] = []
    text = lambda frag: "".join(html.unescape(t) for t in re.findall(r"<w:t[^>]*>(.*?)</w:t>", frag, re.S)).strip()  # noqa: E731
    pos = 0
    for m in re.finditer(r"<w:tbl>.*?</w:tbl>", xml, re.S):
        for para in re.split(r"<w:p[ >]", xml[pos:m.start()]):
            t = text(para)
            if t:
                out.append(t)
        rows = re.findall(r"<w:tr[ >].*?</w:tr>", m.group(0), re.S)
        for i, row in enumerate(rows):
            cells = [text(c).replace("|", "/") for c in re.findall(r"<w:tc>.*?</w:tc>", row, re.S)]
            out.append("| " + " | ".join(cells) + " |")
            if i == 0:
                out.append("|" + "---|" * len(cells))
        pos = m.end()
    for para in re.split(r"<w:p[ >]", xml[pos:]):
        t = text(para)
        if t:
            out.append(t)
    return "\n".join(out)


def _markitdown(data: bytes, suf: str) -> str:
    if suf == ".pdf":
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(data)).pages)
    if suf == ".docx":
        return _docx_markdown(data)
    raise ValueError(f"이 사이트에서는 {suf} 를 읽지 못합니다.")
