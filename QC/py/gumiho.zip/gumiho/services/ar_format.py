"""심사조서(In-depth A/R) 서식에 [재무데이터] 조회 결과를 채운다.

    docs/finance_templates/in-depth_AR_Format_20260403(standard).xlsx  → IPO,혐의심사조서
    docs/finance_templates/in-depth_AR_Format_20260403(simple).xlsm    → 일반심사조서

## 서식이 어떻게 생겼나 (2026-09-01 조사)

85~91개 시트짜리 큰 조서다. 그런데 **보이는 시트는 전부 수식**이다:

    심사조서(일반용)입력문서!C24  =BS!D4
    회사개요!D15                =IF(ISBLANK(BS!D78),"",BS!D78)
    요약FS!D5                   =BS!D4

즉 **숨김 데이터 시트(`BS`·`PL`·`CF`·`회사개요`)만 채우면 나머지는 엑셀이
계산한다.** 서식이 원래 그렇게 만들어져 있다 — 우리가 조서를 다시 그리는 것이
아니라, 담당자가 손으로 옮겨 적던 자리에 값을 놓아 줄 뿐이다.

## 값이 맞는다는 근거 — 계정코드

데이터 시트에 **`코드` 칸**이 있다.

    BS!C4  = 2000            유동자산
    BS!C5  = 1100+1220       (현금예금) = 현금및현금성자산 + 단기금융상품
    BS!C22 = 1170+1179-1171-1172   일반단기대여금

그리고 오라클 커서가 `(ITEMKR_NM, **ITEM_CD**, WORKCD, USEORD, YEAR1..YEAR5)` 를
준다(`integrations/oracle/finstmt.py:160`). 같은 계정코드다. 이름을 맞춰 보는
것이 아니라 **코드로 잇는다** — 이름은 표기가 흔들리지만 코드는 안 흔들린다.

## ⚠️ 자리를 코드에 박지 않는다

기간 열도 코드 행도 **서식에서 읽는다.** `BS` 는 D·F·H·J·L 이고 `PL` 은
D·E·F·G·H 로 서로 다른데, 이걸 박아 두면 담당부서가 서식을 손볼 때마다
**말없이 엉뚱한 칸에 숫자가 들어간다.** 조서에서 그건 최악이다.

  · 기간 열 : 2행에서 `=회사개요!…` 를 참조하는 칸을 찾는다(서식이 그렇게 표시한다)
  · 코드 행 : `코드` 칸(C열)에 값이 있는 행

## 단위

금액 커서는 **백만원**이고(`finstmt.py:41`) 서식도 `(단위:백만원)` 이다.
환산하지 않는다. 환산이 필요해지면 그때는 두 곳 다 고쳐야 한다.
"""
from __future__ import annotations

import logging
import re
from io import BytesIO
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from gumiho.config import get_settings
from gumiho.services.xlsx_patch import Workbook

logger = logging.getLogger(__name__)


def template_dir() -> Path:
    return Path(get_settings().ar_template_dir)

# 화면 단추 두 개. 값은 `kind` 로 API 에 넘어온다.
TEMPLATES: dict[str, dict[str, str]] = {
    "standard": {
        # 담당부서가 2026-09-01 에 둘 다 .xlsm 으로 다시 올려 주었다. 이쪽은
        # 매크로가 없지만 같은 형식으로 맞춰 둔다 — 서식이 둘로 갈리면 나중에
        # 한쪽만 갱신되는 일이 생긴다.
        "file": "in-depth_AR_Format_20260403(standard).xlsm",
        "label": "IPO,혐의심사조서",
        "suffix": ".xlsm",
        "mime": "application/vnd.ms-excel.sheet.macroEnabled.12",
    },
    "simple": {
        # ⚠️ 원본은 `.xls`(OLE·매크로 포함)라 서식을 지키며 프로그램으로 쓸 수
        #    없었다. 담당부서가 .xlsm 으로 다시 저장해 주어(2026-09-01) 속이 zip 이
        #    되었고, 이제 일반조서와 **똑같은 코드로** 무손실로 채운다.
        #    매크로(`xl/vbaProject.bin`)는 우리가 아예 만지지 않으므로 그대로 간다.
        "file": "in-depth_AR_Format_20260403(simple).xlsm",
        "label": "일반심사조서",
        "suffix": ".xlsm",
        "mime": "application/vnd.ms-excel.sheet.macroEnabled.12",
    },
}

# 재무제표 커서 이름 → 데이터 시트 이름
STATEMENTS = {"bs": "BS", "pl": "PL", "cf": "CF"}
CODE_COL = "C"
CODE_HEADER_ROW = 2      # 이 행에 「코드」라고 적혀 있다
FIRST_DATA_ROW = 4

# 회사개요 시트에서 채우는 자리. **B열의 이름표를 대조한 뒤에** 쓴다 —
# 서식이 바뀌어 행이 밀렸는데 그대로 쓰면 엉뚱한 줄에 감사보수가 들어간다.
OVERVIEW_ROWS = [
    (8, "감 사 인", "firm"),
    (9, "감사의견", "opinion"),
    (10, "의견제한사유", "remark"),
    (11, "감사보수", "fee"),
    (12, "감사투입시간", "hours"),
]
OVERVIEW_PERIOD_ROW = 50     # D50..H50 = 결산일자 YYYYMM (회사개요!D7 이 이걸 읽는다)
OVERVIEW_NAME = "D4"         # 회사명 (표지!E10 이 참조)
OVERVIEW_INDUSTRY = "D5"     # 업종
OVERVIEW_YEAR = "G4"         # 사업연도

_CODE_TOKEN = re.compile(r"([+-]?)\s*(\d+)")


class FormatError(RuntimeError):
    """서식이 예상과 다르다. 조용히 빈 조서를 주지 않으려고 던진다."""


class NotWorkpaper(FormatError):
    """엑셀로 **열리기는 한다.** 다만 `BS`·`PL`·`CF` 가 없어 채울 수 없다.

    2026-09-09 에 갈라 냈다. 그전에는 이것도 거절 사유였는데(422), 담당부서가
    점검표 같은 **일반 서식도 올려 빈 채로 내려받게** 해 달라고 해서 이제는
    거절이 아니라 **분류**다 — `ar_template.fillable = False` 로 앉는다.

    ⚠️ `FormatError` 를 물려받는다. 기존 `except FormatError` 자리들이 그대로
       잡으므로, 이 구분을 모르는 코드는 예전처럼 동작한다. 구분해 다루려는
       쪽만 이것을 **먼저** 잡으면 된다.
    """


# ── 서식 읽기 ──────────────────────────────────────────────────────────────

def _period_columns(ws: Any) -> list[str]:
    """기간 열. 2행에서 `=회사개요…` 를 참조하는 칸이 곧 기간이다."""
    out: list[tuple[int, str]] = []
    for cell in ws[CODE_HEADER_ROW]:
        v = cell.value
        if isinstance(v, str) and v.startswith("=") and "회사개요" in v:
            out.append((cell.column, cell.column_letter))
    return [letter for _, letter in sorted(out)]


def _code_rows(ws: Any) -> list[tuple[int, str]]:
    """(행번호, 코드식). 코드가 없는 행(소계·설명)은 건너뛴다."""
    out = []
    for row in range(FIRST_DATA_ROW, ws.max_row + 1):
        v = ws[f"{CODE_COL}{row}"].value
        if v is None:
            continue
        text = str(v).strip()
        if text and _CODE_TOKEN.search(text) and not text.startswith("="):
            out.append((row, text))
    return out


def parse_code_expr(text: str) -> list[tuple[int, str]]:
    """`1170+1179-1171-1172` → [(+1,'1170'), (+1,'1179'), (-1,'1171'), (-1,'1172')].

    `eval` 을 쓰지 않는다. 서식에서 온 문자열이라 우리가 만든 값이 아니다.
    """
    out: list[tuple[int, str]] = []
    for sign, code in _CODE_TOKEN.findall(text):
        out.append((-1 if sign == "-" else 1, code))
    return out


# ── 값 모으기 ──────────────────────────────────────────────────────────────

def _by_code(rows: list[dict[str, Any]]) -> dict[str, list[float | None]]:
    """계정코드 → 5개년 값. 같은 코드가 두 번 오면 **더한다**(세부 항목 분리)."""
    out: dict[str, list[float | None]] = {}
    for row in rows:
        code = str(row.get("code") or "").strip()
        if not code:
            continue
        values = list(row.get("values") or [])
        prev = out.get(code)
        if prev is None:
            out[code] = [None if v is None else float(v) for v in values]
            continue
        for i, v in enumerate(values):
            if v is None:
                continue
            prev[i] = float(v) if prev[i] is None else prev[i] + float(v)
    return out


def lookup(table: dict[str, list[float | None]], code: str) -> list[float | None] | None:
    """서식의 코드로 오라클 값을 찾는다.

    ⚠️ **현금흐름표만 자릿수가 다르다.** 2026-09-01 실측:

        서식 CF   161000  161100  161210  …   118개 **전부** 6자리이고 `16` 으로 시작
        오라클 CF   1000    1100    1210  …   4자리

        서식 BS/PL 4자리 · 오라클 BS/PL 4자리 — 이쪽은 그대로 맞는다.

    그래서 못 찾으면 앞 두 자리를 떼고 한 번 더 본다. 표는 시트마다 따로
    만들므로(BS 표에는 CF 코드가 없다) `161000` → `1000` 이 다른 계정과 부딪칠
    일은 없다.

    이 규칙을 조용히 두지 않는다 — `ar_format_check.py` 가 CF 가 **한 칸도
    안 채워지면 실패**하도록 되어 있어, 서식이나 커서가 바뀌면 검사가 먼저 운다.
    """
    values = table.get(code)
    if values is not None:
        return values
    if len(code) == 6:
        return table.get(code[2:])
    return None


def _sum_for(expr: str, table: dict[str, list[float | None]], index: int) -> float | None:
    """코드식 한 줄의 한 해 값. **기여하는 코드가 하나도 없으면 `None`**.

    0 과 빈 칸은 조서에서 뜻이 다르다 — 서식의 수식이 `IF(ISBLANK(D4),…)` 로
    그 둘을 갈라 본다. 「자료가 없다」를 0 으로 적으면 구성비가 0% 로 찍힌다.
    """
    total: float | None = None
    for sign, code in parse_code_expr(expr):
        values = lookup(table, code)
        if not values or index >= len(values) or values[index] is None:
            continue
        total = (total or 0.0) + sign * float(values[index])
    return total


# ── 채우기 ─────────────────────────────────────────────────────────────────

def _sheet_name(patch: Workbook, base: str, consolidated: bool) -> str | None:
    """개별이면 `BS`, 연결이면 `BS(연결)`. 없는 시트는 건너뛴다."""
    name = f"{base}(연결)" if consolidated else base
    if patch.has_sheet(name):
        return name
    # 간편 서식은 개별 회사개요가 「회사개요(공통)」 이다.
    if not consolidated and base == "회사개요" and patch.has_sheet("회사개요(공통)"):
        return "회사개요(공통)"
    return None


def fill_statements(
    patch: Workbook, layout: Any, data: dict[str, Any], *, consolidated: bool
) -> dict[str, int]:
    """BS·PL·CF 를 채운다. 채운 칸 수를 돌려준다(빈 조서를 조용히 안 주려고)."""
    filled: dict[str, int] = {}
    for key, base in STATEMENTS.items():
        sheet = _sheet_name(patch, base, consolidated)
        if sheet is None:
            continue
        ws = layout[sheet]
        columns = _period_columns(ws)
        if not columns:
            raise FormatError(f"{sheet} 시트에서 기간 열을 찾지 못했습니다.")
        table = _by_code(data.get("statements", {}).get(key) or [])
        count = 0
        for row, expr in _code_rows(ws):
            for i, col in enumerate(columns):
                value = _sum_for(expr, table, i)
                if value is None:
                    continue
                patch.set(sheet, f"{col}{row}", value)
                count += 1
        filled[sheet] = count
    return filled


def fill_overview(
    patch: Workbook, layout: Any, data: dict[str, Any], *, consolidated: bool
) -> None:
    """회사개요 — 결산일자·감사인·감사의견·감사보수·투입시간, 그리고 회사명."""
    sheet = _sheet_name(patch, "회사개요", consolidated)
    if sheet is None:
        return
    ws = layout[sheet]
    company = data.get("company") or {}
    periods = list(data.get("periods") or [])
    audits = {str(a.get("period") or ""): a for a in (data.get("audits") or [])}

    # 결산일자 — 서식은 `YYYYMM` 6자를 기대한다(`LENB(D50)=6`).
    cols = _period_columns(ws) or ["D", "E", "F", "G", "H"]
    for i, col in enumerate(cols):
        if i < len(periods) and periods[i]:
            patch.set(sheet, f"{col}{OVERVIEW_PERIOD_ROW}", str(periods[i])[:6])

    for row, label, field in OVERVIEW_ROWS:
        got = str(ws[f"B{row}"].value or "").replace(" ", "").replace("\n", "")
        want = label.replace(" ", "")
        if want not in got:
            # ⚠️ 이름표가 안 맞으면 **쓰지 않는다.** 서식이 바뀌어 행이 밀렸는데
            #    그대로 쓰면 감사보수가 감사의견 자리에 들어간다.
            logger.warning("%s!B%d 이 「%s」 가 아니라 「%s」 라 건너뜁니다.",
                           sheet, row, label, got[:20])
            continue
        for i, col in enumerate(cols):
            if i >= len(periods):
                break
            audit = audits.get(periods[i]) or {}
            value = audit.get(field)
            if value not in (None, ""):
                patch.set(sheet, f"{col}{row}", value)

    if company.get("name"):
        patch.set(sheet, OVERVIEW_NAME, company["name"])
    if company.get("ind_nm"):
        patch.set(sheet, OVERVIEW_INDUSTRY, company["ind_nm"])
    if periods:
        patch.set(sheet, OVERVIEW_YEAR, str(periods[0]))


XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MACRO_MIME = "application/vnd.ms-excel.sheet.macroEnabled.12"


# 옛 엑셀(.xls)은 zip 이 아니라 OLE2 복합문서다. 첫 8바이트로 확실히 갈린다.
OLE2_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def reject_not_zip(raw: bytes, original_name: str = "") -> None:
    """열 수 없는 형식이면 **무엇이고 어떻게 하면 되는지**까지 말해 준다.

    ⚠️ 옛 `.xls`(BIFF8)를 못 채우는 것은 게을러서가 아니다. 우리는 서식을
    **zip 안에서 시트 XML 만 고쳐 쓰는 방식**으로 채운다 — 그래야 도형 36개와
    인쇄설정 80개가 그대로 남는다(`services/xlsx_patch.py` 머리말). `.xls` 는
    zip 이 아니라 OLE2 라 그 수술을 할 수가 없고, 파이썬으로 `.xls` 를 쓰는
    길(xlwt 계열)은 **도형·조건부서식·인쇄설정을 통째로 잃는다.** 조서는
    인쇄물이라 숫자가 맞아도 그러면 못 쓴다.

    그래서 막되, 한 번의 「다른 이름으로 저장」이면 된다는 것을 분명히 적는다.
    """
    if raw[:2] == b"PK":
        return
    what = f"올리신 파일({original_name})은 " if original_name else "올리신 파일은 "
    if raw[:8] == OLE2_MAGIC:
        raise FormatError(
            what + "옛 엑셀 형식(.xls)입니다. 이 형식은 채울 수 없습니다 — "
            "채우는 동안 도형과 인쇄설정을 그대로 지키려면 .xlsx·.xlsm 이어야 합니다.\n\n"
            "엑셀에서 그 파일을 열고 [파일] → [다른 이름으로 저장] 에서 "
            "「Excel 통합 문서(*.xlsx)」로 한 번만 저장해 주시면 그대로 쓰실 수 있습니다."
        )
    raise FormatError(
        what + "엑셀 파일이 아닌 것 같습니다. .xlsx·.xlsm 파일인지 확인해 주세요."
    )


def inspect(raw: bytes) -> dict[str, Any]:
    """올린 서식이 **채울 수 있는 것인지** 미리 본다(2026-09-02).

    ⚠️ 이 검사가 없으면 이상한 파일을 기본 서식으로 앉힐 수 있고, 그 뒤로
    조서 단추가 **말없이 빈 파일**을 만든다. 담당자는 숫자가 안 들어간 조서를
    받고서야 알게 된다 — 조서는 인쇄물이라 그때는 늦다.

    오라클을 부르지 않는다. 채우는 코드가 보는 것과 **같은 것**을 본다 —
    `BS`·`PL`·`CF`·`회사개요` 시트, C열의 계정코드 행, 2행의 기간 열.
    """
    if not raw:
        raise FormatError("빈 파일입니다.")
    reject_not_zip(raw)
    try:
        patch = Workbook(raw)
        layout = load_workbook(BytesIO(raw), read_only=False, data_only=False)
    except Exception as exc:  # noqa: BLE001
        raise FormatError(f"엑셀로 열지 못했습니다: {exc}") from exc

    found: dict[str, Any] = {"sheets": {}, "overview": False, "codes": 0, "periods": 0}
    for key, base in STATEMENTS.items():
        for consolidated in (False, True):
            name = _sheet_name(patch, base, consolidated)
            if name is None or name not in layout.sheetnames:
                continue
            ws = layout[name]
            codes = _code_rows(ws)
            periods = _period_columns(ws)
            found["sheets"][name] = {"codes": len(codes), "periods": len(periods)}
            found["codes"] += len(codes)
            found["periods"] += len(periods)
        del key

    for consolidated in (False, True):
        if _sheet_name(patch, "회사개요", consolidated):
            found["overview"] = True

    if not found["sheets"]:
        raise NotWorkpaper(
            "심사조서 서식이 아닙니다. 값을 받는 숨김 시트 "
            "`BS`·`PL`·`CF` 를 찾지 못했습니다. "
            "받아 두신 서식을 고쳐 쓰시는 편이 확실합니다."
        )
    if found["codes"] == 0:
        raise NotWorkpaper(
            "시트는 있는데 **계정코드 칸이 비어 있습니다.** "
            "각 시트의 C열 4행 아래에 계정코드가 있어야 값을 어디에 넣을지 알 수 있습니다."
        )
    if found["periods"] == 0:
        raise NotWorkpaper(
            "시트는 있는데 **결산연도 열을 찾지 못했습니다.** "
            "각 시트 2행에 `=회사개요!…` 를 참조하는 칸이 연도별로 있어야 합니다."
        )
    return found


def fill_workbook(
    raw: bytes, indi: dict[str, Any], con: dict[str, Any] | None,
) -> tuple[Workbook, int]:
    """서식 바이트에 개별·연결을 채우고 `(수술기, 채운 칸 수)` 를 돌려준다.

    **자리를 코드에 박지 않는다**(머리말 참고). 그래서 이 함수는 마운트된
    붙박이 서식이든 관리자가 올린 서식이든 똑같이 동작한다 —
    `BS`·`PL`·`CF`·`회사개요` 시트를 찾고, 2행에서 기간 열을, C열에서 코드
    행을 읽어 그 자리에 놓는다.
    """
    patch = Workbook(raw)
    # ⚠️ 읽기는 openpyxl, 쓰기는 우리 수술기다. openpyxl 로 저장하면 도형과
    #    인쇄설정이 사라진다(2026-09-01 실측, `xlsx_patch.py` 머리말).
    layout = load_workbook(BytesIO(raw), read_only=False, data_only=False)

    total = 0
    for data, consolidated in ((indi, False), (con, True)):
        if not data:
            continue
        counts = fill_statements(patch, layout, data, consolidated=consolidated)
        fill_overview(patch, layout, data, consolidated=consolidated)
        total += sum(counts.values())
        logger.info("조서 채움 %s: %s", "연결" if consolidated else "개별", counts)
    return patch, total


def _out_name(label: str, indi: dict[str, Any] | None, suffix: str) -> str:
    company = (indi.get("company") or {}) if indi else {}
    name = re.sub(r"[\\/:*?\"<>|]", "_", str(company.get("name") or "회사"))[:40]
    base_dt = str(company.get("base_dt") or "")[:8]
    return f"{label}_{name}_{base_dt}{suffix}"


def build(
    kind: str, indi: dict[str, Any], con: dict[str, Any] | None,
    *, as_xlsx: bool = True, raw: bytes | None = None,
    meta: dict[str, str] | None = None,
) -> tuple[bytes, str, str]:
    """기본 서식을 채워 `(파일 바이트, 파일 이름, MIME)` 을 돌려준다.

    `raw` 가 오면 그것을 쓴다 — 관리자 화면에서 **올려 둔 서식**이다
    (`api/v1/admin/ar_templates.py`). 안 오면 컨테이너에 물려 둔 파일을 읽는다.
    올린 것이 없으면 마운트된 것이 기본값으로 남는 구조다.

    ## `as_xlsx`

    담당부서 요청(2026-09-01)으로 **기본이 `.xlsx`** 다. 서식 파일은 둘 다
    `.xlsm` 이지만 받는 파일은 xlsx 로 나간다.

    ⚠️ 간편 서식에는 매크로가 하나 있다 — `Module1` 의 `Ctrl+Shift` 단축키로
    IFRS 시트를 오가는 **탐색 편의 기능**이다(값을 계산하지 않는다). xlsx 로
    받으면 그 단축키가 없어진다. 매크로째 받아야 하면 `as_xlsx=False` 다.

    표지·수식·도형·인쇄설정은 어느 쪽이든 그대로다 — 걷어내는 것은
    `vbaProject.bin` 과 그 선언 두 줄뿐이다.
    """
    # `meta` 는 관리자가 올린 서식의 이름·확장자다(2026-09-09). 안 오면 붙박이 둘
    # 중 하나라는 뜻이라 TEMPLATES 에서 찾는다.
    meta = meta or TEMPLATES.get(kind)
    if meta is None:
        raise FormatError(f"모르는 조서입니다: {kind}")
    if raw is None:
        if not meta.get("file"):
            # 관리자가 올린 서식인데 바이트가 안 왔다. 켜진 판이 지워졌다는 뜻이다.
            raise FormatError(
                "이 서식의 파일을 찾지 못했습니다. "
                "관리자 화면 > 자료 관리에서 다시 올려 주세요."
            )
        path = template_dir() / meta["file"]
        if not path.exists():
            raise FormatError(
                f"서식 파일이 없습니다: {meta['file']}. "
                "관리자 화면 > 자료 관리에서 서식을 올리거나, "
                "docs/finance_templates 에 두어야 합니다."
            )
        raw = path.read_bytes()

    patch, total = fill_workbook(raw, indi, con)
    if total == 0:
        raise FormatError(
            "채울 값이 없습니다. 회사와 결산일자를 다시 골라 주세요 — "
            "금융업 회사는 재무제표 커서가 비어 오는 경우가 있습니다."
        )

    suffix = ".xlsx" if as_xlsx else meta["suffix"]
    mime = XLSX_MIME if as_xlsx else meta["mime"]
    return (patch.to_bytes(strip_macros=as_xlsx),
            _out_name(meta["label"], indi, suffix), mime)


def blank(meta: dict[str, str], raw: bytes) -> tuple[bytes, str, str]:
    """서식을 **채우지 않고** 그대로 돌려준다 (담당부서 요청, 2026-09-09).

    회사를 조회하기 전에도 서식을 받아 볼 수 있어야 하고, `BS`·`PL`·`CF` 가 없는
    일반 서식(점검표 따위)은 회사를 조회해도 채울 것이 없다. 두 경우가 여기로 온다.

    ## ⚠️ 매크로를 걷지 않는다

    채워 받을 때는 `.xlsx` 가 기본이다(담당부서 요청, 2026-09-01). 하지만 빈
    서식은 **담당자가 받아서 손으로 채울 물건**이라 원본 그대로가 맞다 — 간편
    서식의 `Ctrl+Shift` 탐색 매크로를 여기서 걷어 낼 이유가 없다.

    ## ⚠️ 열어 보지도 않는다

    바이트를 그대로 넘긴다. 채우지 않으므로 `openpyxl` 로 열 일이 없고, 그래서
    `fillable=False` 인 서식(엑셀이긴 하나 조서 구조가 아닌 것)도 여기로는
    멀쩡히 내려간다.
    """
    label = meta.get("label") or "서식"
    suffix = meta.get("suffix") or ".xlsx"
    name = re.sub(r'[\\/:*?"<>|]', "_", str(label))[:60]
    return raw, f"{name}{suffix}", meta.get("mime") or XLSX_MIME
