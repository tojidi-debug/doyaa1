# -*- coding: utf-8 -*-
"""조치안(hwpx) 읽기 — 문단과 표(표 안의 표 포함)를 자리 표기와 함께 내놓는다.

⚠️ 읽기만 한다. 파일을 고치거나 다시 저장하지 않는다.

자리 표기는 플랫폼(오류검증)과 같은 꼴을 쓴다.
  문단         sec0/p46            (0부터 세는 최상위 문단 번호)
  표의 칸      sec0/t2[r3,c1]      (0부터 세는 최상위 표 번호, 행, 열)
  표 안의 표   sec0/t1[r2,c0]/t0[r6,c3]   ← 플랫폼에는 아직 없는 꼴. 「회사와 감사 개요」 상자가
                                             바깥 표 한 칸 안에 재무 수치 표를 넣는 구조라 필요하다.
"""
from __future__ import annotations

import io
import re
import zipfile
from dataclasses import dataclass, field
from xml.etree import ElementTree as ET

HP = '{http://www.hancom.co.kr/hwpml/2011/paragraph}'


@dataclass
class Cell:
    r: int
    c: int
    rs: int
    cs: int
    paras: list                      # 칸 안 문단 글(중첩 표의 글은 빼고)
    tables: list = field(default_factory=list)
    anchor: str = ''
    page: int = 0                    # 조치안의 몇 쪽(모르면 0)
    height: int = 0                  # 칸 높이(HWPUNIT) — 표가 쪽을 넘어갈 때 행마다 쪽을 매기는 데 쓴다
    header: bool = False             # 머리행 칸(쪽이 넘어가면 되풀이된다)

    @property
    def text(self) -> str:
        return '\n'.join(p for p in self.paras if p.strip())

    @property
    def flat(self) -> str:
        return re.sub(r'\s', '', self.text)


@dataclass
class Table:
    anchor: str                      # sec0/t2  또는 sec0/t1[r2,c0]/t0
    rows: int
    cols: int
    cells: list
    para: int                        # 이 표를 품은 최상위 문단 번호
    depth: int = 0
    before: list = field(default_factory=list)   # 표 바로 앞 문단 글(제목·단위)
    height: int = 0                  # hp:sz 의 표 높이(HWPUNIT) — 옛 값일 수 있다
    inline: bool = False             # 글자처럼 취급(한 줄에 통째로 놓인다 — 쪽을 넘어 갈리지 않는다)
    repeat_header: bool = False
    v_offset: int = 0                # 문단 첫 줄에서 표 위쪽까지(HWPUNIT)

    def at(self, r: int, c: int):
        """(r,c) 를 덮는 칸(병합 포함)."""
        for cell in self.cells:
            if cell.r <= r < cell.r + cell.rs and cell.c <= c < cell.c + cell.cs:
                return cell
        return None

    def row(self, r: int):
        return sorted((x for x in self.cells if x.r == r), key=lambda x: x.c)

    @property
    def unit_text(self) -> str:
        """표에 걸린 단위 글: 표 안의 「(단위 : …)」 칸 또는 표 바로 앞 문단."""
        for cell in self.cells:
            if '단위' in cell.text and len(cell.flat) < 30:
                return cell.text
        for t in reversed(self.before):
            if '단위' in t:
                return t
        return ''


@dataclass
class Para:
    index: int
    text: str
    tables: list = field(default_factory=list)
    page: int = 0                    # 시작하는 쪽(모르면 0)
    page_end: int = 0                # 끝나는 쪽 — 문단이 쪽을 넘어가면 page 와 다르다

    @property
    def anchor(self) -> str:
        return 'sec0/p%d' % self.index


@dataclass
class AgendaDoc:
    name: str
    paras: list
    tables: list                     # 최상위 표
    warnings: list = field(default_factory=list)

    def all_tables(self):
        """중첩 표까지 깊이 우선으로."""
        out = []

        def walk(t):
            out.append(t)
            for cell in t.cells:
                for sub in cell.tables:
                    walk(sub)
        for t in self.tables:
            walk(t)
        return out

    @property
    def text(self) -> str:
        return '\n'.join(p.text for p in self.paras)

    def pages(self) -> dict:
        """자리 표기 → 조치안의 몇 쪽인지(「8쪽」, 쪽을 넘는 문단은 「8~9쪽」). 줄 배치 정보가 없는 파일이면 빈 dict."""
        out = {}
        for p in self.paras:
            if p.page:
                out[p.anchor] = '%d쪽' % p.page if p.page_end in (0, p.page) else '%d~%d쪽' % (p.page, p.page_end)
        for t in self.all_tables():
            for c in t.cells:
                if c.page:
                    out[c.anchor] = '%d쪽' % c.page
        return out

    def locations(self) -> dict:
        """자리 표기 → 사람이 조치안에서 찾아갈 수 있는 말.

        `sec0/t3[r4,c2]` 는 기계끼리 자리를 맞출 때 쓰는 것이고 담당자는 그것으로 문서를 찾아갈 수 없다
        (「조치안 어디서 나오는 거냐」— 담당부서, 2026-09-21). 그래서 목차 줄기(Ⅱ. › 가. › □ 사실관계)와
        표 제목, 행·열 이름표로 적는다: 「Ⅱ. 지적사항 등 › 가. … › □ 사실관계 › 「전환사채 발행 현황」 표 › 만기일 행」
        """
        if getattr(self, '_loc', None) is not None:
            return self._loc
        loc = {}
        crumbs = []                                   # [(깊이, 제목)]

        def level(text):
            t = text.strip()
            if re.match(r'^[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]+\s*\.', t) or re.match(r'^\(\s*붙임\s*\d*\s*\)', t):
                return 1
            if re.match(r'^[가-하]\s*\.\s', t):
                return 2
            if re.match(r'^□', t) and len(t) <= 26:          # 「□ 사실관계」. 「□ ㈜○○의 … 조치를 하려는 것임」 같은 문장은 아니다
                return 3
            if re.match(r'^[①-⑳]', t):
                return 4
            return 0

        def short(text, n=26):
            t = re.sub(r'\[[^\]]*\]', '', text)              # 제목 끝의 [제22기(‘24년) 9,217백만원]
            t = re.sub(r'\s+', ' ', t).strip(' :：')
            return t if len(t) <= n else t[:n].rstrip() + '…'

        def is_num(text):
            # 「6,363백만원」「26.03%」「3.6배」도 값이다 — 이름표로 쓰면 「6,363백만원 행」 같은 자리 이름이 나온다.
            t = re.sub(r'(백만\s*원|천\s*원|억\s*원|원|배|주)\s*$', '', (text or '').strip())
            return bool(re.fullmatch(r'[\s\d,.()%△▲∆\-−*＊~∼·]+', t)) or not t.strip()

        keyvalue = ('회사명', '대표이사', '업종', '법인구분', '설립일', '사업연도', '소재지')

        def caption_in(t):
            """표 안에 든 제목: 「< 회사와 감사 개요 >」, 첫 행에 홀로 있는 「(올바른 회계처리)」"""
            m = re.search(r'<\s*([^<>]{2,20}?)\s*>', ' '.join(x.text for x in t.cells if x.r <= 1))
            if m:
                return m.group(1).strip()
            first = [x for x in t.row(0) if x.flat]
            if len(first) == 1 and len(first[0].flat) <= 20 and '단위' not in first[0].text:
                return first[0].text.strip(' ()')
            return ''

        def walk(t, path, title):
            head_rows = 3
            for c in t.cells:
                # 행 이름표: 그 행에서 왼쪽에 있는 글자 칸(세로로 길게 병합된 갈래 이름은 뺀다)
                lefts = [x for x in t.cells if x.r <= c.r < x.r + x.rs and x.c < c.c and not is_num(x.text)]
                lefts = [x for x in lefts if x.rs == 1 or len(x.flat) <= 6] or lefts
                row = short(max(lefts, key=lambda x: x.c).text, 18) if lefts else ''
                # 열 머리글: 앞 세 행에서 그 열을 덮는 글자 칸 가운데 가장 아래 것. 없으면 위로 올라가며 만나는 「제22기(‘24년)」 꼴.
                col = ''
                if re.sub(r'\s', '', row) not in keyvalue:           # 「회사명 | ㈜○○ | 대표이사 | …」 줄에는 열 머리글이 없다
                    for r in range(min(head_rows, c.r) - 1, -1, -1):
                        h = t.at(r, c.c)
                        if h is not None and h is not c and not is_num(h.text) and '단위' not in h.text:
                            col = short(h.text, 18)
                            break
                    for r in range(c.r - 1, -1, -1):
                        h = t.at(r, c.c)
                        if h is not None and h is not c and re.search(r'제\s*\d+\s*기|\d{2,4}\s*년', h.text) and len(h.flat) <= 16:
                            col = short(h.text, 18)
                            break
                bits = [b for b in (row and row + ' 행', col and col + ' 열') if b]
                name = '「%s」 표' % title if title else '표'
                loc[c.anchor] = ' › '.join(x for x in (path, name, ' · '.join(bits)) if x)
                for sub in c.tables:
                    walk(sub, path, caption_in(sub) or caption_in(t) or title)

        in_law = False                                # (붙임2) 관계법규 안인가
        for p in self.paras:
            lv = level(p.text)
            if lv == 1:
                in_law = bool(re.match(r'^\(\s*붙임\s*[2-9]', p.text.strip())) or '관계법규' in p.text
            elif in_law and lv in (2, 4):
                lv = 0                                # 옮겨 적은 법 조문의 「라. …」「① …」은 조치안의 목차가 아니다
            if lv:
                crumbs[:] = [c for c in crumbs if c[0] < lv] + [(lv, short(p.text))]
            path = ' › '.join(c[1] for c in crumbs)
            loc[p.anchor] = path
            for t in p.tables:
                # 표 제목: 표 안에 든 제목 → 바로 앞의 짧은 제목 줄 → (없으면) 바로 앞 문장의 앞머리
                before = [x for x in t.before if '단위' not in x and not level(x)]
                title = caption_in(t) or next((short(x, 30) for x in reversed(before)
                                               if len(x) <= 40 and not re.match(r'^[◦\-*＊◈⇨]', x.strip())), '')
                if not title and before:
                    title = short(re.sub(r'^[\s◦\-*＊◈⇨]+', '', before[-1]), 24)
                walk(t, path, title)
        # 「8쪽 · Ⅱ. 지적사항 등 › 가. … › □ 지적사항」 — 담당자는 쪽으로 먼저 찾아간다(담당부서 지시, 2026-09-21).
        pages = self.pages()
        for anchor, text in list(loc.items()):
            pg = pages.get(anchor)
            if pg:
                loc[anchor] = pg + (' · ' + text if text else '')
        self._loc = loc
        return loc


def _own_text(p) -> str:
    """문단 자신의 글(표 안 글 제외)."""
    out = []

    def walk(el):
        for ch in el:
            if ch.tag == HP + 'tbl':
                continue
            if ch.tag == HP + 't':
                out.append(''.join(ch.itertext()))
            elif ch.tag == HP + 'lineBreak':
                out.append('\n')
            else:
                walk(ch)
    walk(p)
    return ''.join(out)


def _direct_tables(el):
    """el 아래에서 가장 먼저 만나는 표들(그 표 안의 표는 제외)."""
    for ch in el:
        if ch.tag == HP + 'tbl':
            yield ch
        else:
            yield from _direct_tables(ch)


def _read_table(tbl, anchor: str, para: int, depth: int) -> Table:
    cells = []
    for tr in tbl.findall(HP + 'tr'):
        for tc in tr.findall(HP + 'tc'):
            addr = tc.find(HP + 'cellAddr')
            span = tc.find(HP + 'cellSpan')
            r = int(addr.get('rowAddr', 0)) if addr is not None else 0
            c = int(addr.get('colAddr', 0)) if addr is not None else 0
            rs = int(span.get('rowSpan', 1)) if span is not None else 1
            cs = int(span.get('colSpan', 1)) if span is not None else 1
            csz = tc.find(HP + 'cellSz')
            ch = int(csz.get('height', 0) or 0) if csz is not None else 0
            cell_anchor = '%s[r%d,c%d]' % (anchor, r, c)
            paras, subs = [], []
            sub_list = tc.find(HP + 'subList')
            holder = sub_list if sub_list is not None else tc
            for p in holder.findall(HP + 'p'):
                paras.append(_own_text(p).strip())
                for k, sub in enumerate(_direct_tables(p)):
                    subs.append(_read_table(sub, '%s/t%d' % (cell_anchor, len(subs)), para, depth + 1))
            cells.append(Cell(r, c, rs, cs, paras, subs, cell_anchor, 0, ch, tc.get('header') == '1'))
    pos = tbl.find(HP + 'pos')
    table = Table(anchor, int(tbl.get('rowCnt', 0) or 0), int(tbl.get('colCnt', 0) or 0), cells, para, depth)
    sz = tbl.find(HP + 'sz')
    try:
        table.height = int(sz.get('height', 0) or 0) if sz is not None else 0
    except ValueError:
        table.height = 0
    table.inline = pos is not None and pos.get('treatAsChar') == '1'
    table.repeat_header = tbl.get('repeatHeader') == '1'
    if pos is not None and pos.get('vertRelTo') == 'PARA':
        try:
            table.v_offset = int(pos.get('vertOffset', 0) or 0)
        except ValueError:
            table.v_offset = 0
    return table


def _row_heights(table):
    """행 높이(HWPUNIT): 세로로 병합되지 않은 칸 가운데 가장 큰 것. hp:sz 의 표 높이가 더 크면 그만큼 고르게 늘린다
    (어느 쪽이 옛 값인지는 파일마다 다르다 — 석미건설: 표 높이 18,759 ↔ 행 합 28,287, 다른 표는 7,584 ↔ 5,312)."""
    hs = {}
    for c in table.cells:
        if c.rs == 1:
            hs[c.r] = max(hs.get(c.r, 0), c.height)
    rows = [hs.get(r, 0) for r in range(table.rows)]
    total = sum(rows)
    if total and table.height > total:
        rows = [h * table.height / total for h in rows]
    return rows


def _set_pages(table, row_page, default):
    for c in table.cells:
        c.page = row_page.get(c.r, default)
        for sub in c.tables:                     # 표 안의 표는 그 칸이 놓인 쪽
            for sc in _all_cells(sub):
                sc.page = c.page


def _paginate_table(table, page: int, top: float, body_h: int, next_v=None):
    """표의 행마다 쪽을 매긴다 → 표가 넘어간 쪽 수(0 = 그 쪽 안에서 끝났다).

    top = 표 위쪽의 세로 위치. 행이 쪽의 남은 자리에 안 들어가면 다음 쪽으로 넘기고, 머리행 반복이면 머리행 높이만큼 먼저 찬다.
    next_v = 다음 문단 첫 줄의 세로 위치(관측값). 그것이 이 표의 줄보다 위라면 표가 쪽을 넘은 것이 **확실**하므로, 어림으로는
    안 넘어갔더라도 끝에서부터 next_v 만큼의 행을 다음 쪽으로 돌린다."""
    heights = _row_heights(table)
    head_rows = [r for r in range(table.rows) if any(c.header for c in table.cells if c.r == r)] if table.repeat_header else []
    head_h = sum(heights[r] for r in head_rows)
    y, pg, row_page = top, page, {}
    for r, h in enumerate(heights):
        if body_h and y + h > body_h + 200 and y > 0 and r not in head_rows:
            pg += 1
            y = head_h
        y += h
        row_page[r] = pg
    if next_v is not None and pg == page:
        room, acc = next_v - 300 - head_h, 0            # 다음 쪽 위에서 표의 꼬리가 차지한 높이
        for r in range(len(heights) - 1, -1, -1):
            acc += heights[r]
            if acc > room or r in head_rows:
                break
            row_page[r] = page + 1
        pg = page + 1
    _set_pages(table, row_page, page)
    return pg - page


def _all_cells(table):
    for c in table.cells:
        yield c
        for sub in c.tables:
            yield from _all_cells(sub)


def _body_height(root) -> int:
    """구역의 본문 높이(HWPUNIT) = 용지 높이 − 위·아래·머리말·꼬리말 여백. 못 읽으면 0(쪽을 세지 않는다)."""
    pr = next(root.iter(HP + 'pagePr'), None)
    if pr is None:
        return 0
    try:
        w, h = int(pr.get('width')), int(pr.get('height'))
        m = pr.find(HP + 'margin')
        if pr.get('landscape') == 'NARROWLY':     # 가로로 돌린 용지
            h = w
        return h - sum(int(m.get(k, 0) or 0) for k in ('top', 'bottom', 'header', 'footer'))
    except (TypeError, ValueError, AttributeError):
        return 0


def read_hwpx(src, name: str = '') -> AgendaDoc:
    """src: 파일 경로 또는 bytes."""
    if isinstance(src, (bytes, bytearray)):
        data = src
    else:
        with open(src, 'rb') as fh:
            data = fh.read()
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ValueError('hwpx 파일이 아닙니다. 한글에서 「다른 이름으로 저장 → hwpx」로 바꿔 올려 주세요.')
    sections = sorted(n for n in z.namelist() if re.fullmatch(r'Contents/section\d+\.xml', n))
    if not sections:
        raise ValueError('hwpx 안에서 본문(section)을 찾지 못했습니다.')
    doc = AgendaDoc(name or (src if isinstance(src, str) else ''), [], [])
    # 구역이 여럿이어도 문단·표 번호는 이어서 센다(조치안은 거의 한 구역이다).
    if len(sections) > 1:
        doc.warnings.append('구역이 %d개입니다. 자리 표기는 첫 구역 기준으로 이어 셉니다.' % len(sections))
    pi = ti = 0
    info = []                                # [(문단, 줄[(세로 위치, 높이)], 쪽 나누기?, 구역 번호, 본문 높이)]
    for si, sec in enumerate(sections):
        root = ET.fromstring(z.read(sec))
        body_h = _body_height(root)
        for p in root.findall(HP + 'p'):
            para = Para(pi, _own_text(p).strip())
            segs = p.find(HP + 'linesegarray')
            lines = []
            if segs is not None:
                for sg in segs.findall(HP + 'lineseg'):
                    try:
                        lines.append((int(sg.get('vertpos')), int(sg.get('vertsize') or 0)))
                    except (TypeError, ValueError):
                        pass
            for tbl in _direct_tables(p):
                t = _read_table(tbl, 'sec0/t%d' % ti, pi, 0)
                t.before = [q.text for q in doc.paras[-3:] if q.text]
                para.tables.append(t)
                doc.tables.append(t)
                ti += 1
            doc.paras.append(para)
            info.append((para, lines, p.get('pageBreak') == '1', si, body_h))
            pi += 1
    _assign_pages(info)
    return doc


def _assign_pages(info):
    """문단·표의 칸마다 조치안의 몇 쪽인지 매긴다.

    한글은 문단마다 줄 배치(linesegarray: 줄의 세로 위치)를 저장해 둔다. 세로 위치는 쪽마다 0 에서 다시 시작하므로
    **되돌아가면 쪽이 바뀐 것**이다. 줄 배치가 없는 파일(도구가 만든 hwpx)은 쪽을 알 수 없다 → page = 0(화면에도 안 적는다).
    표(글자처럼 취급하지 않는 것)는 두 가지로 놓인다 — 줄이 표 **아래로 밀린** 배치(표는 그 줄 위, 같은 쪽)와 줄에서 표가 **시작하는**
    배치(쪽을 넘어 갈릴 수 있다). 앞 문단의 끝과 그 줄 사이에 표가 들어갈 자리가 있으면 앞엣것이다."""
    if not any(lines for _, lines, *_ in info):
        return
    page, last_v, last_h, cur_sec, pending = 1, -1, 0, 0, 0
    for i, (para, lines, page_break, sec, body_h) in enumerate(info):
        if sec != cur_sec:
            page, last_v, last_h, cur_sec, pending = page + 1 + pending, -1, 0, sec, 0   # 구역이 바뀌면 새 쪽
        if not lines:
            para.page = para.page_end = page
            for t in para.tables:
                _set_pages(t, {}, page)
            continue
        v0 = lines[0][0]
        reset = last_v >= 0 and v0 < last_v
        if reset:
            page += max(1, pending)
        else:
            page += pending + (1 if page_break and last_v > 0 else 0)   # 쪽 나누기인데 위치가 안 되돌아간 드문 경우
        pending = 0
        prev_end = 0 if (reset or last_v < 0) else last_v + last_h
        para.page = page
        for k in range(1, len(lines)):
            if lines[k][0] < lines[k - 1][0]:
                page += 1
        para.page_end = page
        last_v, last_h = lines[-1]
        for t in para.tables:
            total = sum(_row_heights(t))
            if t.inline or (v0 - prev_end) >= 0.9 * total:
                _set_pages(t, {}, para.page)           # 한 줄에 통째로 놓였거나, 줄이 표 아래로 밀린 배치 — 표는 이 쪽에 있다
                continue
            nxt = next((ln[0][0] for _, ln, _, s2, _ in info[i + 1:i + 4] if ln and s2 == sec), None)
            crossed = nxt is not None and nxt < v0       # 다음 문단이 이 줄보다 위에 있다 = 그 사이에 쪽이 넘어갔다(관측)
            if not crossed and total < 0.9 * body_h:
                _set_pages(t, {}, para.page)           # 다음 문단이 같은 쪽 아래로 이어진다 — 표는 이 쪽 안에서 끝났다
                continue                                # (티 안 나게 쪽을 넘으려면 표가 한 쪽보다 길어야 한다)
            over = _paginate_table(t, para.page, v0 + t.v_offset, body_h, nxt if crossed else None)
            if over:
                para.page_end = max(para.page_end, para.page + over)
                pending = max(pending, over)            # 다음 문단에서 쪽을 넘길 때 함께 더한다(되돌아감이 보이면 그 한 쪽에 포함)
