"""감사보고서 대사 · 조치안 검산 · 인용 대조 — 「오류검증(검토)2」의 엔진.

담당부서가 2026-09-21 에 넘긴 꾸러미(`docs/new ins2/engine/`)를 **그대로** 옮긴 것이다.
모델을 쓰지 않는다. 네트워크도 쓰지 않는다. 조치안(hwpx)과 감사보고서(PDF)의
바이트만 받아 JSON 을 낸다.

    pdf_reader.py    감사보고서 PDF → 재무제표 계정·기수·감사인·의견·주주·모든 숫자와 일자 (PyMuPDF)
    hwpx_reader.py   조치안 hwpx → 문단·표(표 안의 표 포함) + 자리 표기
    accounts.py      조치안 항목 이름 ↔ 감사보고서 계정, 비율 산식
    crosscheck.py    감사보고서 대사. crosscheck(doc, reports) → dict
    yangjeong.py     [별표 1] 조치양정기준 가운데 계산에 쓰는 부분
    selfcheck.py     조치안 검산. selfcheck(doc) → dict. 감사보고서 없이도 돈다
    quotecheck.py    인용 대조. quotecheck(doc) → dict. 기준서 원문은 data/kgaap.json
    cli.py           python -m gumiho.services.xcheck.cli 조치안.hwpx 감사보고서.pdf …
    run.py           워커가 부르는 자리. 예외를 밖으로 내지 않는다

⚠️ 엔진 파일은 꾸러미와 글자까지 같게 둔다. 고칠 것이 있으면 꾸러미 쪽(담당부서)과
   함께 고친다 — 두 벌이 갈리면 담당부서 PC 에서 맞던 것이 서버에서 틀린다.
   플랫폼에 맞춘 것은 `run.py` 하나뿐이다.

⚠️ 엔진은 **hwpx 만** 읽는다. `.hwp` 는 워커가 rhwp `export-hwpx` 로 바꿔 넣는다
   (`workers/tasks/doc_review.py`). 조치안이 PDF 면 이 엔진은 돌지 않고 그 이유를 적는다.
"""
