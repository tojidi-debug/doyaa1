"""[품감] 개별선정(개발) — 「감사인(회계법인) 감리일정 및 배정」 엑셀 읽기 (2026-10-14, 개발서버 전용).

    스케쥴표   차수 머리줄 아래 날짜 줄, 그 아래 사람마다(A열 이름) 병합 막대
               「나우회계법인\\n팀장(with전영조)」 · 「위탁위-양정위」 · 「심사종결\\n-양정위」
    배정       회계법인마다 회차·시작일·종료일·팀장·팀원·선정사유 + 회계법인 정보(설립·외감 개수·감리이력 …)

    비상근감리위원 시트   성명·소속·연락처·이메일만 읽어, 함께 나가는 막대의 마우스 오버 안내에 쓴다
                          (사용자 지정 2026-10-14). 등록번호는 읽지 않는다.
파일은 관리자가 화면에서 올리고 파일저장소(`qc_sample/schedule.xlsx`)에만 둔다(저장소에 넣지 않음).
"""
from __future__ import annotations

import re
from datetime import date, datetime
from io import BytesIO
from typing import Any

from openpyxl import load_workbook

MEETING = re.compile(r"위탁위|양정위|감리위|증선위|심사종결|회의|교육|워크숍")

# 배정 시트 머리 이름 → 키(공백·줄바꿈 없앤 이름으로 찾는다)
ASSIGN_COLS = {
    "회차": "round", "감사인코드": "code", "회계법인이름": "firm", "시작일": "start", "종료일": "end", "일수": "days",
    "개별감사보고서검토개수": "reviews", "팀장": "lead", "팀원": "member", "선정사유": "reason", "설립연월일": "founded",
    "외감개수": "audits", "최근감리": "last_review", "주사무소": "office", "구성원수": "members",
    "사무소(분실포함)": "branches", "구분": "region", "대표": "ceo", "결산월": "fiscal", "연락처": "phone",
}


class ScheduleError(ValueError):
    pass


def _k(v: Any) -> str:
    return re.sub(r"\s+", "", str(v or ""))


def _d(v: Any) -> str | None:
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    m = re.search(r"(20\d{2})[.\-/](\d{1,2})[.\-/](\d{1,2})", str(v or ""))
    return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}" if m else None


def short_firm(name: str) -> str:
    s = re.sub(r"회계\s*법인|\(주\)|주식회사", "", str(name or "")).strip()
    return re.sub(r"\s+", "", s) or str(name or "").strip()


_METRO = re.compile(r"^(부산|대구|인천|광주|대전|울산|세종)")


def region_of(region: Any, office: Any) -> str:
    """지방 이름 — 지방은 **서울·경기가 아닌 곳**(사용자 지정 2026-10-14). 주사무소 주소로 가르고,
    주소가 없을 때만 배정의 「구분」을 쓴다. 「부산 해운대구 …」→부산, 「충북 청주시 …」→청주, 「경기도 고양시 …」→없음."""
    addr = str(office or "").strip()
    if not addr:
        return str(region or "").strip()
    if re.match(r"^(서울|경기)", addr):
        return ""
    m = _METRO.match(addr)
    if m:
        return m.group(1)
    tokens = addr.split()
    for t in tokens[1:3]:
        m = re.match(r"^([가-힣]{1,4}?)(시|군)$", t)
        if m:
            return m.group(1)
    return ""


def _bar(text: str) -> dict[str, Any]:
    lines = [x.strip() for x in str(text).split("\n") if x.strip()]
    whole = " ".join(lines)
    if MEETING.search(whole) and not re.search(r"회계법인|팀장|팀원", whole):
        return {"kind": "meeting", "label": re.sub(r"\s*-\s*", "-", "".join(lines)), "firm": None, "role": None, "with": None}
    firm = lines[0] if lines else whole
    role, mate = None, None
    m = re.search(r"(팀장|팀원)\s*\(?\s*with\s*([^)]+)\)?", whole)
    if m:
        role, mate = m.group(1), m.group(2).strip()
    elif re.search(r"팀장", whole):
        role = "팀장"
    elif re.search(r"팀원", whole):
        role = "팀원"
    return {"kind": "lead" if role == "팀장" else "member" if role == "팀원" else "other",
            "label": f"{short_firm(firm)}({role})" if role else short_firm(firm), "firm": firm, "role": role, "with": mate}


def parse_schedule(raw: bytes) -> dict[str, Any]:
    try:
        wb = load_workbook(BytesIO(raw), data_only=True)
    except Exception as exc:  # noqa: BLE001
        raise ScheduleError(f"엑셀을 열지 못했습니다: {exc}") from exc
    sched = next((ws for ws in wb.worksheets if "스케" in ws.title or "일정" in ws.title), None)
    outside = next((ws for ws in wb.worksheets if "비상근" in ws.title), None)
    assign = next((ws for ws in wb.worksheets if "배정" in ws.title), None)
    if sched is None and assign is None:
        raise ScheduleError("「스케쥴표」·「배정」 시트를 찾지 못했습니다.")

    staff: list[str] = []
    events: list[dict[str, Any]] = []
    if sched is not None:
        merged = {}
        for rng in sched.merged_cells.ranges:
            merged[(rng.min_row, rng.min_col)] = (rng.max_row, rng.max_col)
        dates: dict[int, str] = {}           # 열 → 날짜(지금 블록의 날짜 줄)
        for r in range(1, sched.max_row + 1):
            row_dates = {c: _d(sched.cell(r, c).value) for c in range(2, sched.max_column + 1)}
            if sum(1 for v in row_dates.values() if v) >= 3:
                dates = {c: v for c, v in row_dates.items() if v}
                continue
            name = str(sched.cell(r, 1).value or "").strip()
            if not name or name == "이름" or not dates:
                continue
            if name not in staff:
                staff.append(name)
            for c in range(2, sched.max_column + 1):
                v = sched.cell(r, c).value
                if v in (None, ""):
                    continue
                end_c = merged.get((r, c), (r, c))[1]
                days = [dates[x] for x in range(c, end_c + 1) if x in dates]
                if not days:
                    continue
                ev = _bar(str(v))
                ev.update(person=name, start=min(days), end=max(days), days=sorted(days))
                events.append(ev)

    firms: list[dict[str, Any]] = []
    if assign is not None:
        head_row, cols = None, {}
        for r in range(1, min(assign.max_row, 10) + 1):
            keys = {_k(assign.cell(r, c).value): c for c in range(1, assign.max_column + 1)}
            if "회계법인이름" in keys or "회계법인명" in keys:
                head_row = r
                for label, key in ASSIGN_COLS.items():
                    if label in keys:
                        cols[key] = keys[label]
                if "firm" not in cols and "회계법인명" in keys:
                    cols["firm"] = keys["회계법인명"]
                for k2, c in keys.items():
                    if k2.startswith("과거감리이력"):
                        cols["history"] = c
                break
        if head_row:
            for r in range(head_row + 1, assign.max_row + 1):
                firm = str(assign.cell(r, cols.get("firm", 5)).value or "").strip()
                if not firm:
                    continue
                rec: dict[str, Any] = {"row": r}
                for key, c in cols.items():
                    v = assign.cell(r, c).value
                    rec[key] = _d(v) if key in ("start", "end", "founded") and _d(v) else (
                        int(v) if isinstance(v, float) and v.is_integer() else v)
                    if isinstance(rec[key], str):
                        rec[key] = rec[key].strip()
                rec["short"] = short_firm(firm)
                firms.append(rec)
    members: dict[str, dict[str, str]] = {}
    if outside is not None:
        for r in range(1, min(outside.max_row, 10) + 1):
            keys = {_k(outside.cell(r, c).value): c for c in range(1, outside.max_column + 1)}
            if "성명" in keys:
                col = {k: keys.get(k) for k in ("성명", "소속", "연락처", "이메일")}
                for rr in range(r + 1, outside.max_row + 1):
                    name = str(outside.cell(rr, col["성명"]).value or "").strip()
                    if not name:
                        continue
                    info = {"name": name}
                    for k, key in (("소속", "org"), ("연락처", "phone"), ("이메일", "email")):
                        v = str(outside.cell(rr, col[k]).value or "").strip() if col.get(k) else ""
                        if v:
                            info[key] = v
                    members[name] = info
                break
    # 스케쥴표에 같은 차수가 두 번 실려(11월 블록이 위·아래 둘) 같은 막대가 겹쳐 나오던 것 — 하나로 합친다.
    merged_ev: dict[tuple, dict[str, Any]] = {}
    for e in events:
        k = (e["person"], e["label"], e.get("firm"))
        same = merged_ev.get(k)
        if same and (set(same["days"]) & set(e["days"]) or same["end"] >= e["start"] and e["end"] >= same["start"]):
            same["days"] = sorted(set(same["days"]) | set(e["days"]))
            same["start"], same["end"] = same["days"][0], same["days"][-1]
            continue
        merged_ev[k if not same else k + (e["start"],)] = e
    events = sorted(merged_ev.values(), key=lambda e: (e["person"], e["start"]))
    # 지방(배정의 「구분」: 부산·대구·고양 …)은 막대 이름 뒤에 「_부산」(사용자 지정 2026-10-14)
    region = {f["short"]: region_of(f.get("region"), f.get("office")) for f in firms}
    region = {k: v for k, v in region.items() if v}
    for e in events:
        r = region.get(short_firm(e.get("firm") or "")) if e.get("firm") else None
        if r:
            e["region"] = r
            e["label"] = f"{e['label']}_{r}"
    # 비상근 = 일정표의 정규 멤버(사람 줄)에 없는 사람(사용자 지정 2026-10-14). 위원 시트에 정보가 있으면 붙이고,
    # 없으면 이름만. 정규 멤버끼리 나가는 막대에는 붙이지 않는다(화면이 회계법인 정보를 보여 준다).
    regular = {re.sub(r"\s+", "", n) for n in staff}

    def outsider(name: Any) -> dict[str, str] | None:
        n = re.sub(r"\s+", "", str(name or ""))
        if not n or n in regular:
            return None
        return members.get(n) or {"name": n}

    for e in events:
        m = outsider(e.get("with"))
        if m:
            e["mate"] = m
    for f in firms:
        for k in ("lead", "member"):
            m = outsider(f.get(k))
            if m:
                f[f"{k}_info"] = m
    return {"staff": staff, "events": events, "firms": firms, "outsiders": members,
            "sheets": [ws.title for ws in wb.worksheets if ws in (sched, assign)]}


# ── 공휴일(빨간 날) ────────────────────────────────────────────────────
# 이름은 짧게(사용자 지정 2026-10-15): 설·추석·3.1절·어린이날·부처님·X-mas·대체휴일 … 근로자날(5/1)은 공휴일이 아니지만 함께 표시.
_SHORT = [
    (r"대체", "대체휴일"), (r"설날", "설"), (r"추석", "추석"), (r"삼일절", "3.1절"), (r"신정", "신정"),
    (r"어린이날", "어린이날"), (r"부처님", "부처님"), (r"현충일", "현충일"), (r"광복절", "광복절"),
    (r"개천절", "개천절"), (r"한글날", "한글날"), (r"기독탄신일|성탄", "X-mas"), (r"선거", "선거일"),
]


def short_holiday(name: str) -> str:
    for pat, label in _SHORT:
        if re.search(pat, name):
            return label
    return name


def holidays_between(start: date, end: date) -> dict[str, str]:
    """{YYYY-MM-DD: 짧은 이름} — 대한민국 공휴일 + 근로자날(5/1)."""
    import holidays as _h
    years = list(range(start.year, end.year + 1))
    out: dict[str, str] = {}
    for d, name in sorted(_h.KR(years=years, language="ko").items()):
        if start <= d <= end:
            out.setdefault(d.isoformat(), short_holiday(name))
    for y in years:
        d = date(y, 5, 1)
        if start <= d <= end:
            out.setdefault(d.isoformat(), "근로자날")
    return out


# ── 관리자 조정(사용자 지정 2026-10-15) ───────────────────────────────────
# 일정 엑셀을 다시 올려도 유지되도록 파일저장소 settings.json 에 둔다 —
#   firm_overrides  {회계법인 이름: {start, end, lead, member}} — 그 법인 막대를 지우고 다시 만든다
#   meeting_people  {날짜: {회의 이름 일부: [참석자]}}        — 그날 그 회의 막대는 적힌 사람에게만

def _weekdays(a: str, b: str) -> list[str]:
    from datetime import timedelta
    try:
        d, e = date.fromisoformat(a), date.fromisoformat(b)
    except ValueError:
        return []
    out = []
    while d <= e and len(out) < 40:
        if d.weekday() < 5:
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def firm_changes(before: dict[str, Any], after: dict[str, Any]) -> list[dict[str, Any]]:
    """관리자 조정 이력 한 묶음 — 일정(시작·종료)과 참여인원(팀장·팀원)을 따로 적는다(사용자 지정 2026-10-15)."""
    norm = lambda v: re.sub(r"\s+", "", str(v or ""))  # noqa: E731
    out: list[dict[str, Any]] = []
    if (before.get("start"), before.get("end")) != (after.get("start"), after.get("end")):
        out.append({"kind": "schedule", "before": {k: before.get(k) or "" for k in ("start", "end")},
                    "after": {k: after.get(k) or "" for k in ("start", "end")}})
    people = [{"role": role, "before": before.get(k) or "", "after": after.get(k) or ""}
              for role, k in (("팀장", "lead"), ("팀원", "member")) if norm(before.get(k)) != norm(after.get(k))]
    if people:
        out.append({"kind": "people", "changes": people})
    return out


def year_history(history: list[dict[str, Any]], year: int) -> list[dict[str, Any]]:
    """이력은 그해 것만(사용자 지정 2026-10-15 — 해가 바뀌면 지난해 이력은 필요 없음)"""
    return [h for h in history or [] if str(h.get("at") or "")[:4] == str(year)]


def apply_overrides(out: dict[str, Any], firm_ov: dict[str, Any], meetings: dict[str, Any]) -> dict[str, Any]:
    staff = out.get("staff") or []
    regular = {re.sub(r"\s+", "", n) for n in staff}
    members = out.get("outsiders") or {}

    def outsider(name: Any) -> dict[str, str] | None:
        n = re.sub(r"\s+", "", str(name or ""))
        if not n or n in regular:
            return None
        return members.get(n) or {"name": n}

    for f in out.get("firms") or []:
        ov = firm_ov.get(f["firm"]) or firm_ov.get(f.get("short") or "")
        if not ov:
            continue
        for k in ("start", "end", "lead", "member"):
            if ov.get(k) not in (None, ""):
                f[k] = ov[k]
        f["overridden"] = True
        for k in ("lead", "member"):
            m = outsider(f.get(k))
            if m:
                f[f"{k}_info"] = m
            else:
                f.pop(f"{k}_info", None)
        key = short_firm(f["firm"])
        old = [e for e in out["events"] if e.get("firm") and short_firm(e["firm"]) == key]
        region = next((e.get("region") for e in old if e.get("region")), None) or region_of(f.get("region"), f.get("office"))
        out["events"] = [e for e in out["events"] if e not in old]
        days = _weekdays(f.get("start") or "", f.get("end") or "")
        for role, kind, person, mate_name in (("팀장", "lead", f.get("lead"), f.get("member")), ("팀원", "member", f.get("member"), f.get("lead"))):
            if not person or person not in staff or not days:
                continue                      # 비상근(정규 멤버 줄이 없는 사람)은 막대 대신 함께 나가는 사람으로
            ev = {"kind": kind, "label": f"{short_firm(f['firm'])}({role})" + (f"_{region}" if region else ""), "firm": f["firm"],
                  "role": role, "with": mate_name, "person": person, "start": days[0], "end": days[-1], "days": days}
            if region:
                ev["region"] = region
            m = outsider(mate_name)
            if m:
                ev["mate"] = m
            out["events"].append(ev)
    if meetings:
        def keep(e: dict[str, Any]) -> bool:
            if e.get("kind") != "meeting":
                return True
            for day, rules in meetings.items():
                if day in (e.get("days") or [e.get("start")]):
                    for word, people in rules.items():
                        if word in str(e.get("label") or "") and e.get("person") not in people:
                            return False
            return True
        out["events"] = [e for e in out["events"] if keep(e)]
    out["events"].sort(key=lambda e: (e["person"], e["start"]))
    return out
