"""[품감] 심의안(개발) — 조직 조서(초안)·개별 조서(초안) (사용자 지정 2026-10-15).

심의안 초안 작성에서 체크한 상태(조직 항목 분류·문안, 개별 항목의 회사별 지적)로 한공회 서식을 채운다.

    조직 조서  frontend/qc/templates/조직조서.xlsx  (「팀장_조직_체크리스트_확인서작성용」)
               발견사항요약표 C열(A 미설계 · B 미운영 · C 일부미흡, 개별 항목 지적 수, 법규위반 건수)
               checklist-조직 C열「발견된 특이사항」 · 확인서-조직 B열 · 첫 문장(대상기간·회계법인) · 날짜·대표이사
               조직·운영특성(사업보고서로 알 수 있는 것: 분사무소 수·CPA·이사·외감·상장) — 서식의 보기값은 지운다
    개별 조서  인뎁스 서식(상근용, 관리자가 [품감] 개별선정에 올린 것)
               2.checklist-개별 D열「확인서 문구」(점검회사마다 한 파일) · 회사명·감사인·심사팀장

칸은 **이름표로 찾는다**(서식이 바뀌어 줄이 밀려도 엉뚱한 칸을 덮지 않게). 쓰기는 xlsx_patch(도형·인쇄설정 보존).
서버에 남기지 않는다. GitHub(정적) 사이트는 같은 파일을 브라우저 파이썬(Pyodide)으로 돌린다.
"""
from __future__ import annotations

import io
import re
import zipfile
from datetime import date
from typing import Any

from openpyxl import load_workbook

try:
    from gumiho.services.xlsx_patch import Workbook
except ImportError:  # GitHub(정적) 사이트 — 패키지 없이 파일만 올라간다
    from xlsx_patch import Workbook  # type: ignore[no-redef]

LETTER = {"미설계": "A", "미운영": "B", "일부미흡": "C", "비공개": "D"}
CLS_TEXT = {"미설계": "미설계", "미운영": "미운영", "일부미흡": "설계∙운영상 일부 미흡"}

# 조직 항목 키 → 이름표에서 찾을 말(공백·가운뎃점·괄호를 뺀 글에 들어 있으면)
ORG_ITEMS = {
    "a1": "조서관리담당자", "a2": "감사조서보존", "a3": "관리대장",
    "b1": "업무배정", "b2": "해결사항", "b3": "발행통제",
    "c1": "집계검증시스템", "c2": "감사시간모니터링",
    "d1": "사후심리관련정책", "d2": "사후심리결과",
}
ORG_GROUPS = {"a": "감사조서작성관리절차", "b": "업무품질관리검토사전심리절차", "c": "감사시간관리절차", "d": "모니터링사후심리"}
INDI_KEYS = [f"i{n}" for n in range(1, 18)]          # 개별 17항목(평가표·심의안과 같은 차례)


class WorkpaperError(RuntimeError):
    """서식이 예상과 다르다 — 조용히 빈 조서를 주지 않는다."""


def _key(v: Any) -> str:
    return re.sub(r"[\s∙·ㆍ()\[\]◦○※*:]", "", str(v or ""))


def _rows(ws: Any, col: str) -> list[tuple[int, str]]:
    return [(r, _key(ws[f"{col}{r}"].value)) for r in range(1, ws.max_row + 1) if ws[f"{col}{r}"].value not in (None, "")]


def _find(rows: list[tuple[int, str]], word: str, *, after: int = 0) -> int | None:
    return next((r for r, t in rows if r > after and word in t), None)


def _text(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v or "")).strip()


def _period_phrase(span: str) -> str | None:
    """「2025.4.1. ～ 2026.3.31.」 → 「2025년 4월 1일부터 2026년 3월 31일까지」"""
    d = re.findall(r"(\d{4})\s*[.\-/년]\s*(\d{1,2})\s*[.\-/월]\s*(\d{1,2})", span or "")
    if len(d) < 2:
        return None
    (y1, m1, d1), (y2, m2, d2) = d[0], d[-1]
    return f"{y1}년 {int(m1)}월 {int(d1)}일부터 {y2}년 {int(m2)}월 {int(d2)}일까지"


def _spaced(name: str) -> str:
    """서식의 서명란 꼴 — 「이 선 생」"""
    n = re.sub(r"\s+", "", name or "")
    return " ".join(n) if 2 <= len(n) <= 4 else n


def org_xlsx(raw: bytes, p: dict[str, Any]) -> tuple[bytes, list[str]]:
    """p = {firm, span, ceo, writer, today:[y,m,d], groups:{a:'B'…}, items:{a1:{cls,text}…}, indi:{i1:n…}, companies,
            viol:{gaap,gaas,other}, profile:{branches, cpa, directors, audited, listed}}"""
    wb = load_workbook(io.BytesIO(raw))
    patch = Workbook(raw)
    done: list[str] = []
    need = ("발견사항요약표", "checklist-조직", "확인서-조직")
    if not all(patch.has_sheet(s) for s in need):
        raise WorkpaperError(f"조직 조서 서식에 시트 {', '.join(need)} 가 있어야 합니다.")

    def put(sheet: str, ref: str, value: Any) -> None:
        patch.set(sheet, ref, value)
        done.append(f"{sheet}!{ref}")

    items = p.get("items") or {}
    groups = p.get("groups") or {}
    note = lambda it: _text(it.get("text")) or CLS_TEXT.get(it.get("cls") or "", it.get("cls") or "")  # noqa: E731

    # ── 발견사항요약표 ──
    S = "발견사항요약표"
    ws = wb[S]
    b = _rows(ws, "B")
    a = _rows(ws, "A")
    for r in range(1, ws.max_row + 1):                      # 서식의 보기값(A~D·건수)을 먼저 지운다 — 머리글·수식 칸은 둔다
        v = ws[f"C{r}"].value
        if v in ("A", "B", "C", "D") or (isinstance(v, (int, float)) and not isinstance(v, bool)):
            put(S, f"C{r}", None)
    for g, word in ORG_GROUPS.items():
        r = _find(b, word)
        if r and groups.get(g):
            put(S, f"C{r}", groups[g])
        for k, w in ORG_ITEMS.items():
            if not k.startswith(g) or not (items.get(k) or {}).get("cls"):
                continue
            rr = _find(b, w, after=r or 0)
            if rr:
                put(S, f"C{rr}", LETTER.get(items[k]["cls"], ""))
    cnt = _find(b, "개별감사업무점검회사수")
    if cnt:
        put(S, f"C{cnt}", int(p.get("companies") or 0))
    head = _find(a, "2.개별감사업무에관한사항")
    first = next((r for r, _ in a if head and r > head + 2), None)          # 「감사계획수립과 위험평가절차」 줄부터 17항목(B열 ◦ 줄)
    rows17 = [r for r, _ in b if first and r >= first][:17]
    if len(rows17) != 17:
        raise WorkpaperError("발견사항요약표에서 개별감사업무 17항목 줄을 찾지 못했습니다. 서식을 확인해 주세요.")
    for k, r in zip(INDI_KEYS, rows17, strict=True):
        put(S, f"C{r}", int((p.get("indi") or {}).get(k) or 0))
    law = _find(a, "법규등위반") or rows17[-1]
    viol = p.get("viol") or {}
    for word, k in (("회계처리기준위반", "gaap"), ("중요한감사절차위반", "gaas"), ("기타", "other")):
        r = _find(a, word, after=law)
        if r:
            put(S, f"C{r}", int(viol.get(k) or 0))

    # ── checklist-조직 C열 · 확인서-조직 B열 ──
    for sheet, col in (("checklist-조직", "C"), ("확인서-조직", "B")):
        rows = _rows(wb[sheet], "A")
        for k, w in ORG_ITEMS.items():
            it = items.get(k) or {}
            r = _find(rows, w)
            if r and it.get("cls"):
                put(sheet, f"{col}{r}", note(it))

    # ── 확인서-조직: 첫 문장·날짜·대표이사 ──
    ws = wb["확인서-조직"]
    phrase = _period_phrase(p.get("span") or "")
    firm = _text(p.get("firm"))
    for r in range(1, 9):
        v = ws[f"A{r}"].value
        if isinstance(v, str) and "까지의" in v and "에 대한" in v:
            t = v
            if phrase:
                t = re.sub(r"\d{4}년\s*\d+월\s*\d+일부터\s*\d{4}년\s*\d+월\s*\d+일까지", phrase, t)
            if firm:
                t = re.sub(r"까지의\s*.+?에 대한", f"까지의 {firm}에 대한", t)
            put("확인서-조직", f"A{r}", t)
            break
    y, m, d = (p.get("today") or [date.today().year, date.today().month, date.today().day])[:3]
    for r in range(1, ws.max_row + 1):
        v = ws[f"B{r}"].value
        if isinstance(v, str) and re.search(r"\d{4}\s*년\s*\d+\s*월\s*\S+\s*일", v):
            put("확인서-조직", f"B{r}", re.sub(r"\d{4}\s*년\s*\d+\s*월\s*\S+\s*일", f"{y} 년   {m} 월   {d} 일", v))
        elif isinstance(v, str) and "대표이사" in v and p.get("ceo"):
            put("확인서-조직", f"B{r}", re.sub(r"대표이사.*$", f"대표이사   {_spaced(str(p['ceo']).split(',')[0])}", v))

    # ── 조직·운영특성(보기값을 지우고 사업보고서로 알 수 있는 것만) ──
    if patch.has_sheet("조직·운영특성"):
        T = "조직·운영특성"
        ws = wb[T]
        a = _rows(ws, "A")
        # 보기값 자리(이름표 → 지울 열). 「품질관리실」은 두 줄 — 첫째(인원·전담인원)와 둘째(구성원 특성)
        sample = {"조직구조": "CEG", "조직형태": "B", "품질관리예산": "B", "인적구성": "CE", "감사업무": "B",
                  "외감현황": "CE", "기업특성": "B", "수임특성": "B", "수임에대한보상": "B"}
        seen_qc = 0
        for r, t in a:
            cols = sample.get(t, "")
            if t == "품질관리실":
                cols = "CF" if seen_qc == 0 else "B"
                seen_qc += 1
            for c in cols:
                if ws[f"{c}{r}"].value not in (None, ""):
                    put(T, f"{c}{r}", None)
        tail = _find(a, "기타특이점")
        if tail and ws[f"B{tail + 1}"].value not in (None, ""):
            put(T, f"B{tail + 1}", None)                       # 「기타 특이점」 아래 줄의 작성 예
        pr = p.get("profile") or {}
        for word, cells in (("조직구조", {"C": pr.get("branches")}),
                            ("인적구성", {"C": pr.get("cpa"), "E": pr.get("directors")}),
                            ("외감현황", {"C": pr.get("audited"), "E": pr.get("listed")})):
            r = _find(a, word)
            if not r:
                continue
            for c, v in cells.items():
                if v not in (None, ""):
                    put(T, f"{c}{r}", v)
            if word in ("인적구성", "외감현황"):
                patch.set_formula(T, f"G{r}", f'IF(N(C{r})=0,"",E{r}/C{r})')
        for r in range(1, 5):
            v = ws[f"G{r}"].value
            if isinstance(v, str) and v.startswith("작성자"):
                put(T, f"G{r}", f"작성자 : {_text(p.get('writer'))}")
    if patch.has_sheet("지정요건검토") and firm:
        ws = wb["지정요건검토"]
        r = _find(_rows(ws, "A"), "회계법인", after=5) or 7
        put("지정요건검토", f"A{r}", firm)                         # 조직·운영특성 A3 「회계법인 명 : 」이 이 칸을 본다
    return patch.to_bytes(), done


def _checklist_rows(wb: Any) -> list[int]:
    """2.checklist-개별 의 확인서 문구(D열) 줄 — 확인서-개별 B열 수식(='2.checklist-개별'!D4 …)이 가리키는 차례 그대로.
    17항목 + 법규 위반 혐의 = 18줄. 체크리스트 C열 「●」는 빠진 줄이 있어(지배기구 커뮤니케이션) 쓰지 않는다."""
    if "확인서-개별" not in wb.sheetnames:
        return []
    ws = wb["확인서-개별"]
    out = []
    for r in range(1, ws.max_row + 1):
        m = re.fullmatch(r"='?2\.checklist-개별'?!\$?D\$?(\d+)", str(ws[f"B{r}"].value or "").strip())
        if m:
            out.append(int(m.group(1)))
    return out


def indi_xlsx(raw: bytes, p: dict[str, Any], co: dict[str, Any], *, layout: Any = None) -> tuple[bytes, list[str]]:
    """co = {name, items:{i1:[지적 문구…]…}, viol:'…'} · p = {firm, lead, member}"""
    wb = layout or load_workbook(io.BytesIO(raw))
    S = "2.checklist-개별"
    if S not in wb.sheetnames:
        raise WorkpaperError("개별 조서 서식(인뎁스 상근용)에 「2.checklist-개별」 시트가 없습니다.")
    rows = _checklist_rows(wb)
    if len(rows) != 18:
        raise WorkpaperError(f"확인서-개별 B열이 가리키는 2.checklist-개별 항목이 18줄이 아니라 {len(rows)}줄입니다. 서식을 확인해 주세요.")
    patch = Workbook(raw)
    done: list[str] = []
    for k, r in zip([*INDI_KEYS, "viol"], rows, strict=True):
        texts = [t for t in ((co.get("items") or {}).get(k) or []) if _text(t)] if k != "viol" else ([co["viol"]] if _text(co.get("viol")) else [])
        if texts:
            patch.set(S, f"D{r}", "\n".join(_text(t) for t in texts))
            done.append(f"{S}!D{r}")
    ov = "회사개요(공통)"
    if ov in wb.sheetnames:
        ws = wb[ov]
        if _text(co.get("name")):
            patch.set(ov, "D4", _text(co.get("name")))            # 표지·입력문서의 회사명이 이 칸을 본다(ar_format.OVERVIEW_NAME)
            done.append(f"{ov}!D4")
        if p.get("firm") and "감사인" in _key(ws["B8"].value):
            patch.set(ov, "D8", _text(p["firm"]))
            done.append(f"{ov}!D8")
    try:
        from gumiho.services.qc_sample import fill_inputs
    except ImportError:  # 정적 사이트
        from qc_sample import fill_inputs  # type: ignore[no-redef]
    done += fill_inputs(patch, raw, {"lead": p.get("lead") or "", "member": p.get("member") or ""})
    return patch.to_bytes(), done


def safe(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]', "_", _text(name))[:40] or "회사"


def indi_zip(raw: bytes, p: dict[str, Any]) -> tuple[bytes, str, int]:
    """점검회사마다 한 파일 — 하나면 그 xlsx, 둘 이상이면 zip. `(바이트, 확장자, 파일 수)`"""
    cos = [c for c in (p.get("companies") or []) if _text(c.get("name"))]
    if not cos:
        raise WorkpaperError("점검회사 이름이 없습니다. 심의안 초안 작성 › 개별 탭에서 회사 이름을 넣어 주세요.")
    layout = load_workbook(io.BytesIO(raw))
    files = [(f"개별조서(초안)_{safe(p.get('firm') or '')}_{safe(c['name'])}.xlsx", indi_xlsx(raw, p, c, layout=layout)[0]) for c in cos]
    if len(files) == 1:
        return files[0][1], "xlsx", 1
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files:
            z.writestr(name, data)
    return buf.getvalue(), "zip", len(files)
