"""[품감] 통합(개발) 제출자료 대사 결과 → 엑셀 (2026-11-12, 사용자 지정).

화면이 보내 준 결과(자료는 서버에 남기지 않는다)를 표로 정리해 한 파일로 만든다.
  요약       대사 자료 목록(같은 자료는 위에 한 번 — 아래에서는 ①②… 번호로) · 결과 건수 · 항목별 건수
  회계법인   사업보고서 감사실적 ↔ 사전제출자료 회사 수 · 체크포인트          (회계법인을 골랐을 때만)
  자료 비교  항목마다 한 표 — 열 = 사전제출자료 2-3 · 각 첨부 자료 · 차이 · 위치 (services/qc_review_tables)
  일치       같은 값으로 확인된 것
  매출장 …   매출장 대사(독립성) 회사별 · 거래별                              (매출장을 올렸을 때만)
글자가 길면 칸을 합치고 줄 바꿈, 숫자는 숫자로(합계·정렬이 되게) 넣는다.
"""
from __future__ import annotations

import io
import re
from datetime import datetime, timedelta, timezone
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from gumiho.services import qc_review_tables as T

FONT = "맑은 고딕"
KST = timezone(timedelta(hours=9))     # 브라우저 파이썬·서버 어디서 돌아도 같은 날짜(한국 시각)
NAVY, BAND, SOFT = "1F3A5F", "E8EEF6", "F7F9FC"
RED, GREEN = "C62828", "2E7D32"
THIN = Side(style="thin", color="C9D3DF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
_NUM = re.compile(r"-?\d[\d,]*(\.\d+)?")
GRADE_FILL = {"상": "FDE7E7", "중": "FFF1DF", "하": "EEF1F4"}


def _f(bold=False, color="1B2430", size=10) -> Font:
    return Font(name=FONT, size=size, bold=bold, color=color)


def _num(v: Any) -> Any:
    """「1,234」→ 1234 (숫자로) — 그 밖의 글은 그대로. 0 으로 시작하는 번호(사업자번호 등)는 글로 둔다."""
    if isinstance(v, (int, float)):
        return v
    t = str(v if v is not None else "").strip()
    if _NUM.fullmatch(t) and not re.fullmatch(r"0\d+", t):
        try:
            x = float(t.replace(",", ""))
            return int(x) if x.is_integer() else x
        except ValueError:
            return t
    return t


def _put(ws, r: int, c: int, v: Any, *, bold=False, color="1B2430", fill: str | None = None, align="left", wrap=True, fmt: str | None = None,
         border=True, size=10) -> Any:
    cell = ws.cell(r, c, v)
    cell.font = _f(bold, color, size)
    cell.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    if fill:
        cell.fill = PatternFill("solid", fgColor=fill)
    if border:
        cell.border = BOX
    if fmt:
        cell.number_format = fmt
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        cell.number_format = "#,##0" if float(v).is_integer() else "#,##0.0"
    return cell


def _merge(ws, r: int, c1: int, c2: int, v: Any = None, **kw) -> None:
    for c in range(c1, c2 + 1):                       # 합친 칸 전체에 테두리·바탕을 먼저 깐다
        _put(ws, r, c, v if c == c1 else None, **kw)
    if c2 > c1:
        ws.merge_cells(start_row=r, start_column=c1, end_row=r, end_column=c2)


def _head(ws, r: int, c: int, labels: list[str], height: float | None = None) -> None:
    for k, lab in enumerate(labels):
        _put(ws, r + 0, c + k, lab, bold=True, color="FFFFFF", fill=NAVY, align="center")
    if height:
        ws.row_dimensions[r].height = height


def _title(ws, r: int, last_col: int, text: str, sub: str = "") -> int:
    _merge(ws, r, 1, last_col, text, bold=True, color=NAVY, size=14, border=False, wrap=False)
    ws.row_dimensions[r].height = 24
    if sub:
        _merge(ws, r + 1, 1, last_col, sub, color="5B6776", border=False, size=9, wrap=False)
        return r + 3
    return r + 2


def _section(ws, r: int, last_col: int, text: str) -> int:
    _merge(ws, r, 1, last_col, text, bold=True, color=NAVY, fill=BAND, size=11, wrap=False)
    ws.row_dimensions[r].height = 20
    return r + 1


def _widths(ws, widths: list[float]) -> None:
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _setup(ws, landscape=True) -> None:
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True


def _lines(text: str, width: float) -> int:
    """칸 너비(글자 수)에 따른 줄 수 — 줄 높이를 직접 정하기 위한 어림."""
    n = 0
    for part in str(text or "").split("\n"):
        n += max(1, -(-int(sum(2 if ord(ch) > 0x2E80 else 1 for ch in part) * 0.95) // max(int(width), 1)))
    return n


def _fit(ws, r: int, cells: list[tuple[Any, float]], base=15.0, cap=90.0) -> None:
    ws.row_dimensions[r].height = min(cap, max(base, max(_lines(v, w) for v, w in cells) * 13.5 + 3))


# ── 요약 ──────────────────────────────────────────────────────────────────

def _summary(wb: Workbook, d: dict[str, Any], tables: dict[str, Any], grade: dict[str, str]) -> None:
    ws = wb.active
    ws.title = "요약"
    _setup(ws, False)
    _widths(ws, [8, 44, 16, 14, 62])
    firm = d.get("firm") or {}
    sub = " · ".join(x for x in [str(firm.get("corp_name") or ""), f"당기 FY{d.get('fy')}" if d.get("fy") else "",
                                  f"만든 날 {datetime.now(KST):%Y-%m-%d %H:%M}"] if x)
    r = _title(ws, 1, 5, "제출자료 대사 결과", sub)

    r = _section(ws, r, 5, "대사 자료 (아래 표의 ①②… 번호는 이 목록의 번호입니다)")
    _head(ws, r, 1, ["번호", "파일", "올린 곳", "종류", "읽은 내용"])
    r += 1
    by_name = {}
    for f in d.get("files") or []:
        by_name.setdefault(str(f.get("name")), f)
    for src in tables["sources"]:
        f = by_name.get(src["name"], {})
        what = _read_what(f)
        _put(ws, r, 1, src["id"], align="center")
        _put(ws, r, 2, src["name"])
        _put(ws, r, 3, "회계법인 자료" if f.get("side") == "firm" else "대사할 자료", align="center")
        _put(ws, r, 4, f.get("role") or f.get("kind") or "", align="center")
        _put(ws, r, 5, what)
        _fit(ws, r, [(src["name"], 44), (what, 62)])
        r += 1
    if not tables["sources"]:
        _merge(ws, r, 1, 5, "올린 자료가 없습니다.", color="5B6776")
        r += 1

    r = _section(ws, r + 1, 5, "결과 건수")
    _head(ws, r, 1, ["등급", "구분", "건수"])
    r += 1
    items, ok = d.get("items") or [], d.get("ok") or []
    for g, label in (("상", "위반의심"), ("중", "중점확인·불일치"), ("하", "참고")):
        n = sum(1 for i in items if grade.get(str(i.get("level")), "하") == g)
        _put(ws, r, 1, g, bold=True, align="center", fill=GRADE_FILL[g])
        _put(ws, r, 2, label)
        _put(ws, r, 3, n)
        r += 1
    _put(ws, r, 1, "일치", bold=True, align="center", fill="E6F4EA")
    _put(ws, r, 2, "같은 값으로 확인")
    _put(ws, r, 3, len(ok))
    r += 2

    r = _section(ws, r, 5, "항목별 건수")
    _head(ws, r, 1, ["등급", "항목", "건수", "회사 수"])
    r += 1
    for g in tables["groups"]:
        cos = {str(x.get("company")) for x in (g["rows"] if g["kind"] != "list" else g["rows"])}
        _put(ws, r, 1, g["grade"], bold=True, align="center", fill=GRADE_FILL.get(g["grade"]))
        _put(ws, r, 2, _plain(g["title"]))
        _put(ws, r, 3, g["count"])
        _put(ws, r, 4, len(cos))
        r += 1
    for n in d.get("notes") or []:
        r += 1
        _merge(ws, r, 1, 5, str(n), color=RED, border=False)
        _fit(ws, r, [(n, 130)])


def _read_what(f: dict[str, Any]) -> str:
    if not f:
        return ""
    if f.get("error"):
        return str(f["error"])
    bits = []
    if f.get("found"):
        bits.append("읽은 시트: " + ", ".join(f["found"]))
    elif f.get("sheets") and f.get("role") != "매출장":
        bits.append("시트 " + ", ".join(f["sheets"]))
    if f.get("role") == "매출장":
        bits.append(f"거래 {int(f.get('rows') or 0):,}줄")
    elif f.get("rows"):
        bits.append(f"{int(f['rows']):,}줄")
    if f.get("chars"):
        bits.append(f"{int(f['chars']):,}자")
    x = f.get("facts") or {}
    if x.get("type") == "감사보고서":
        bits.append(f"감사보고서 · {f.get('company') or '회사 못 찾음'} · 보고서일 {x.get('report_date') or '-'} · 의견 {x.get('opinion') or '-'}")
    return " · ".join(bits)


def _plain(t: Any) -> str:
    s = _plain0(t)
    return re.sub(r"(\d+-\d+\.\s)([^\s]+)\s+\2", r"\1\2", s)          # 「2-8 자체조서점검」에 시트 이름을 또 붙이지 않게


def _plain0(t: Any) -> str:
    return re.sub(r"(^|[^\d.\-])(2-10|2-3|2-8|4-10|8-3)(?![\d.\-])", lambda m: m.group(1) + m.group(2) + "." + {
        "2-3": " 외감회사", "2-8": " 자체조서점검", "2-10": " 이사교체현황", "4-10": " 비감사서비스", "8-3": " 사후심리"}[m.group(2)], str(t or ""))


# ── 회계법인 ───────────────────────────────────────────────────────────────

def _firm(wb: Workbook, d: dict[str, Any]) -> None:
    firm = d.get("firm")
    if not firm:
        return
    ws = wb.create_sheet("회계법인")
    _setup(ws, False)
    _widths(ws, [34, 18, 18, 12, 40])
    p = firm.get("profile") or {}
    r = _title(ws, 1, 5, f"회계법인 — {p.get('corp_name') or firm.get('corp_name') or ''}",
               f"{firm.get('report') or ''}" + (f" · 당기 {p.get('period')} / 전기 {p.get('prev_period') or ''}" if p.get("period") else ""))
    r = _section(ws, r, 5, "외감실적 대사 — 사업보고서 Ⅱ.2.가 감사실적 ↔ 사전제출자료 2-3 회사 수")
    _head(ws, r, 1, ["구분", "사업보고서 감사실적", "사전제출자료(회사 수)", "차이"])
    r += 1
    ac, cn = p.get("audit_counts") or {}, d.get("counts") or {}
    pts: list[tuple[str, str]] = []
    for label, rep, mine in (("개별(별도) 외감 — 당기", ((ac.get("indi") or {}).get("total") or [None, None])[0], cn.get("당기")),
                             ("개별(별도) 외감 — 전기", ((ac.get("indi") or {}).get("total") or [None, None])[1], cn.get("전기")),
                             ("연결 — 당기", ((ac.get("con") or {}).get("total") or [None, None])[0], cn.get("당기연결")),
                             ("연결 — 전기", ((ac.get("con") or {}).get("total") or [None, None])[1], cn.get("전기연결"))):
        diff = None if rep is None or mine is None else mine - rep
        _put(ws, r, 1, label)
        _put(ws, r, 2, rep if rep is not None else "-", align="right")
        _put(ws, r, 3, mine if mine is not None else "-", align="right")
        _put(ws, r, 4, "-" if diff is None else ("일치" if diff == 0 else diff), align="right", bold=bool(diff),
             color=RED if diff else (GREEN if diff == 0 else "1B2430"), fmt="+#,##0;-#,##0")
        if diff:
            pts.append(("중", f"{label}: 사업보고서 {rep}사 ↔ 사전제출자료 {mine}사({diff:+d}) — 누락·중복 회사 확인"))
        r += 1
    for c in p.get("checks") or []:
        pts.append(("중", str(c)))
    for w in p.get("warnings") or []:
        pts.append(("하", f"사업보고서에서 읽지 못한 값 — {w}"))
    if not cn:
        pts.append(("하", "사전제출자료(2-3)를 올리지 않아 외감실적 회사 수는 맞춰 보지 못했습니다."))
    r = _section(ws, r + 1, 5, "주요 체크포인트")
    _head(ws, r, 1, ["등급", "내용"])
    ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=5)
    r += 1
    for g, t in pts or [("하", "사업보고서에서 따로 확인할 것은 찾지 못했습니다.")]:
        _put(ws, r, 1, g, bold=True, align="center", fill=GRADE_FILL[g])
        _merge(ws, r, 2, 5, t)
        _fit(ws, r, [(t, 90)])
        r += 1


# ── 자료 비교(항목마다 한 표) ────────────────────────────────────────────────

def _compare(wb: Workbook, tables: dict[str, Any]) -> None:
    groups = tables["groups"]
    if not groups:
        return
    ws = wb.create_sheet("자료 비교")
    _setup(ws)
    k = max([len(g.get("cols") or []) for g in groups if g["kind"] == "pivot"] + [2])   # 첨부 자료 열 수(가장 많은 항목 기준)
    last = 3 + k + 2                                                                   # 회사 · 연도 · 2-3(값 A) · 자료×k · 차이 · 위치
    DIFF, REF = 4 + k, 5 + k
    _widths(ws, [28, 9, 17] + [17] * k + [13, 34])
    r = _title(ws, 1, last, "자료 비교 — 항목별 표", "같은 항목을 사전제출자료(2-3)와 대사 자료 값으로 나란히 놓았습니다. 붉은 칸이 다른 값, 초록 칸은 같은 값. 자료 번호는 「요약」 시트의 목록.")
    for g in groups:
        r = _section(ws, r, last, f"[{g['grade']}] {_plain(g['title'])} — {g['count']}건")
        ws.cell(r - 1, 1).fill = PatternFill("solid", fgColor=GRADE_FILL.get(g["grade"], BAND))
        if g.get("basis"):
            _merge(ws, r, 1, last, g["basis"], color="5B6776", size=9, fill=SOFT)
            _fit(ws, r, [(g["basis"], 150)], base=14)
            r += 1
        if g["kind"] == "pivot":
            heads = ["회사", "사업연도", g.get("mine_label", T.MINE)] + [
                f"{c['id']} {c['file']}" + (f"\n{c['sheet']}" if c.get("sheet") else "") for c in g["cols"]]
            heads += [""] * (k - len(g["cols"]))
            _head(ws, r, 1, heads + ["차이", "위치"])
            hh = max(_lines(h, 17) for h in heads[3:] if h) if any(heads[3:]) else 1
            ws.row_dimensions[r].height = min(80, max(20, hh * 13.5 + 4))
            r += 1
            for row in g["rows"]:
                _put(ws, r, 1, _co(row["company"]), bold=True)
                _put(ws, r, 2, row["year"], align="center")
                _put(ws, r, 3, _num(row["mine"]), align="right")
                for j in range(k):
                    cells = row["cells"][j] if j < len(row["cells"]) else []
                    if cells:
                        bad = any(c["bad"] for c in cells)
                        _put(ws, r, 4 + j, _num(" / ".join(str(c["v"]) for c in cells)) if len(cells) == 1 else " / ".join(str(c["v"]) for c in cells),
                             align="right", bold=bad, color=RED if bad else GREEN, fill="FDECEC" if bad else None)
                    else:
                        _put(ws, r, 4 + j, None)
                _put(ws, r, DIFF, _num(row["diff"]) if re.fullmatch(r"[+-][\d,]+(\.\d+)?", row["diff"] or "") else row["diff"], align="right", bold=True, color=RED, fmt="+#,##0;-#,##0")
                _put(ws, r, REF, row["ref"], color="5B6776", size=9)
                _fit(ws, r, [(row["company"], 28), (row["ref"], 34)])
                r += 1
        elif g["kind"] == "pair":
            _head(ws, r, 1, ["회사", "사업연도", _plain(g["left_label"])])
            _merge(ws, r, 4, 3 + k, _plain(g["right_label"]), bold=True, color="FFFFFF", fill=NAVY, align="center")
            _head(ws, r, DIFF, ["차이", "위치"])
            ws.row_dimensions[r].height = 22
            r += 1
            for row in g["rows"]:
                _put(ws, r, 1, _co(row["company"]), bold=True)
                _put(ws, r, 2, row["year"], align="center")
                _put(ws, r, 3, _num(_plain(row["left"])), align="right")
                _merge(ws, r, 4, 3 + k, _num(_plain(row["right"])), align="right")
                _put(ws, r, DIFF, row["diff"], align="right", bold=True, color=RED)
                _put(ws, r, REF, row["ref"], color="5B6776", size=9)
                _fit(ws, r, [(row["company"], 28), (row["ref"], 34), (row["right"], 17 * k)])
                r += 1
        else:
            _head(ws, r, 1, ["회사", "사업연도"])
            _merge(ws, r, 3, 3 + k, "내용", bold=True, color="FFFFFF", fill=NAVY, align="center")
            _head(ws, r, DIFF, ["", "위치"])
            r += 1
            for row in g["rows"]:
                _put(ws, r, 1, _co(row.get("company")), bold=True)
                _put(ws, r, 2, row.get("year") or "", align="center")
                _merge(ws, r, 3, 3 + k, _plain(row.get("detail")))
                _put(ws, r, DIFF, None)
                _put(ws, r, REF, row["ref"], color="5B6776", size=9)
                _fit(ws, r, [(row.get("company"), 28), (_plain(row.get("detail")), 17 * (k + 1)), (row["ref"], 34)])
                r += 1
        r += 1
    ws.freeze_panes = "A4"


def _co(v: Any) -> str:
    return str(v or "").replace(" ↔ ", "\n↔ ")


# ── 일치 · 매출장 ───────────────────────────────────────────────────────────

def _same(wb: Workbook, d: dict[str, Any], tables: dict[str, Any]) -> None:
    ok = d.get("ok") or []
    if not ok:
        return
    alias = T.alias_map(d.get("files") or [])
    ws = wb.create_sheet("일치")
    _setup(ws)
    _widths(ws, [30, 28, 10, 54, 30])
    r = _title(ws, 1, 5, "일치 — 같은 값으로 확인된 것", f"{len(ok):,}건")
    _head(ws, r, 1, ["항목", "회사", "사업연도", "내용", "위치"])
    r += 1
    first = r
    for o in ok:
        _put(ws, r, 1, _plain(o.get("title")))
        _put(ws, r, 2, _co(o.get("company")))
        _put(ws, r, 3, o.get("year") or "", align="center")
        _put(ws, r, 4, _plain(o.get("detail")))
        ref = ", ".join(T.short_ref(x, alias) for x in o.get("refs") or [])
        _put(ws, r, 5, ref, color="5B6776", size=9)
        r += 1
    ws.auto_filter.ref = f"A{first - 1}:E{max(r - 1, first)}"
    ws.freeze_panes = ws.cell(first, 1)


def _sales(wb: Workbook, d: dict[str, Any]) -> None:
    s = d.get("sales")
    if not s:
        return
    alias = T.alias_map(d.get("files") or [])
    m = s.get("summary") or {}
    ws = wb.create_sheet("매출장-회사별")
    _setup(ws)
    _widths(ws, [7, 30, 12, 34, 14, 7, 16, 54])
    r = _title(ws, 1, 8, "매출장 대사(독립성) — 회사별",
               f"거래 {m.get('transactions', 0):,}건 · 감사대상 {m.get('audit_clients', 0)}곳 · 맞춘 거래 {m.get('matched', 0)}건 · 상 {m.get('high', 0)} · 회사 {m.get('companies', 0)}곳")
    _head(ws, r, 1, ["등급", "회사", "대상", "용역", "연도", "건", "합계(원)", "확인할 것"])
    r += 1
    first = r
    for g in s.get("companies") or []:
        _put(ws, r, 1, g.get("risk"), bold=True, align="center", fill=GRADE_FILL.get(str(g.get("risk"))))
        _put(ws, r, 2, g.get("company"), bold=True)
        _put(ws, r, 3, "·".join(g.get("kinds") or []), align="center")
        _put(ws, r, 4, ", ".join(g.get("services") or []))
        _put(ws, r, 5, ", ".join(str(y) for y in g.get("years") or []), align="center")
        _put(ws, r, 6, g.get("rows"), align="right")
        _put(ws, r, 7, round(float(g.get("total") or 0)), align="right")
        t = " / ".join(g.get("issues") or [])
        _put(ws, r, 8, t)
        _fit(ws, r, [(g.get("company"), 30), (", ".join(g.get("services") or []), 34), (t, 54)])
        r += 1
    ws.auto_filter.ref = f"A{first - 1}:H{max(r - 1, first)}"
    ws.freeze_panes = ws.cell(first, 1)

    ws2 = wb.create_sheet("매출장-거래")
    _setup(ws2)
    _widths(ws2, [7, 26, 12, 26, 34, 15, 8, 20, 40, 40, 26])
    r = _title(ws2, 1, 11, "매출장 대사(독립성) — 거래별", f"{len(s.get('candidates') or []):,}건")
    _head(ws2, r, 1, ["등급", "대상 회사", "거래일", "거래처", "적요", "합계(원)", "분류", "용역", "확인할 것", "맞춘 근거", "원본 위치"])
    r += 1
    first = r
    for c in s.get("candidates") or []:
        _put(ws2, r, 1, c.get("risk"), bold=True, align="center", fill=GRADE_FILL.get(str(c.get("risk"))))
        _put(ws2, r, 2, c.get("company"), bold=True)
        _put(ws2, r, 3, c.get("date"), align="center")
        _put(ws2, r, 4, c.get("client"))
        _put(ws2, r, 5, c.get("memo"))
        _put(ws2, r, 6, round(float(c.get("total") or 0)), align="right")
        _put(ws2, r, 7, c.get("target_kind"), align="center")
        _put(ws2, r, 8, c.get("service"))
        issue = f"{c.get('issue') or ''}" + (f"\n{c.get('note')}" if c.get("note") else "")
        basis = f"{c.get('basis') or ''}" + (f"\n{c.get('evidence')}" if c.get("evidence") else "")
        _put(ws2, r, 9, issue)
        _put(ws2, r, 10, basis, size=9)
        src = T.short_ref(str(c.get("source") or ""), alias)
        _put(ws2, r, 11, src, color="5B6776", size=9)
        _fit(ws2, r, [(c.get("client"), 26), (c.get("memo"), 34), (issue, 40), (basis, 40), (src, 26)])
        r += 1
    ws2.auto_filter.ref = f"A{first - 1}:K{max(r - 1, first)}"
    ws2.freeze_panes = ws2.cell(first, 1)


# ── 입구 ────────────────────────────────────────────────────────────────────

def filename(d: dict[str, Any]) -> str:
    firm = re.sub(r'[\\/:*?"<>|]', "_", str((d.get("firm") or {}).get("corp_name") or "")).strip()[:30]
    return "_".join(x for x in ["제출자료대사", firm, f"FY{d['fy']}" if d.get("fy") else "", f"{datetime.now(KST):%y%m%d}"] if x) + ".xlsx"


def build(d: dict[str, Any], grade: dict[str, str]) -> bytes:
    items, ok = d.get("items") or [], d.get("ok") or []
    tables = T.build(items, ok, d.get("files") or [], grade)
    wb = Workbook()
    _summary(wb, d, tables, grade)
    _firm(wb, d)
    _compare(wb, tables)
    _same(wb, d, tables)
    _sales(wb, d)
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()
