"""[품감] 통합 제출자료 대사 — 점검 결과 「중요도 순 요약표」 (2026-11-13, 사용자 지정).

회사마다 한 줄 나열하지 않고, 항목마다 한 줄 — 「체크 항목 | 대상 회사·건수 | 자료 위치」. 화면·복사·엑셀이 이 한 가지 모양(rows)을 그대로 그린다.
  · 조서 취합 60일 초과: 총 건수(개별·연결) + 경과일수 구간(60~70 · 70~90 · 90~120 · 120일 초과)별 회사 — 많으면 건수와 최소·최대만
  · 「적시취합」 표시 불일치 : 건수 + 최소·최대 일수(회사)
  · 담당이사 교차심리 : 결론부터 「A(1개사) ↔ B(1개사)」, 상세 회사는 표 아래 별도 표
  · 그 밖의 대사 차이 : 항목별로 묶고 회사를 쉼표로(많으면 일부 + 「등 총 N개사」, 눌러 전부)
  · 오류·위반이 아닌 「정보가 비어 있음」(비감사보수 미기재 등)은 표에 넣지 않고 맨 아래 ※ 참고 문구로만
배치 순서(중요도 높은 순): 외부감사법 위반 가능 → 그 밖의 법규·기준 위반 가능 → 주요 회계처리 오류 관련 → 독립성 위반 가능 →
담당이사 기재 오류 → 담당이사 과다수임 → (구분선) 사실관계 확인이 필요한 자료 간 대사 차이. 대표이사·품질관리실장·손해배상준비금은 화면·엑셀 맨 위에 늘 먼저(회계법인 정보).
서버(api/v1/qc_sample.py)와 브라우저(GitHub 사이트 Pyodide)가 같은 코드를 쓴다. 저장하지 않는다.
"""
from __future__ import annotations

import re
from typing import Any

SHEETS = {"2-3": "외감회사", "2-8": "자체조서점검", "2-10": "이사교체현황", "4-10": "비감사서비스", "8-3": "사후심리"}
# 중요도 순서 — 위에서부터. codes 에 없는 항목은 등급으로 갈린다(위반의심 → 법규, 중점확인·불일치 → 자료 간 차이, 참고 → ※ 참고 문구).
TIERS: list[tuple[str, str, set[str]]] = [
    ("audit_act", "외부감사법 위반일 수 있는 항목", {"consolidated"}),
    ("law", "그 밖의 법규·기준 위반일 수 있는 항목", {"archive_60", "cross_review", "self_review", "review_order", "post_review_same", "selfcheck"}),
    ("acct", "주요 회계처리 오류와 관련될 수 있는 항목", {"other_opinion"}),
    ("indep", "독립성 위반일 수 있는 항목", {"nas_banned", "nas_client", "nas_related", "nonaudit", "sales"}),
    ("partner", "담당이사 기재 오류", {"partner_name", "partner_years_diff", "years_step", "firm_years_step", "partner_alias", "other_partner", "other_partner_years"}),
    ("overload", "담당이사 과다수임", {"overload"}),
    ("diff", "자료 간 대사 차이", set()),
]
TITLES = {  # 항목 이름을 짧고 읽기 쉽게
    "review_order": "감사보고서일 이후 심리·종결", "cross_review": "담당이사 상호 교차심리", "self_review": "담당이사가 자기 회사를 심리",
    "archive_60": "조서 취합 60일 초과", "timely_mark": "자체점검 「적시취합」 표시와 실제 취합일 불일치", "reviewer": "심리·검토 담당자 대사 불일치",
    "partner_name": "담당이사 이름 불일치", "partner_years_diff": "담당이사 계속감사년수 대사 불일치", "firm_years_step": "수임 후 계속감사년수 대사 불일치",
    "overload": "담당이사 과다수임(15개 이상)",
}
NOTE_CODES = {"nas_missing", "missing_210", "unmatched", "other_unmatched", "same_hours", "qc_staff", "period_extra"}
NOTE_TITLES = ("4-10 에 비감사용역이 있는데 2-3 비감사보수가 없음",)
RANK = {c: n for n, c in enumerate(["review_order", "cross_review", "self_review", "post_review_same", "archive_60", "selfcheck",
                                     "consolidated", "other_opinion", "nas_banned", "nas_client", "nas_related", "nonaudit", "sales",
                                     "partner_name", "partner_years_diff", "firm_years_step", "years_step", "partner_alias"])}      # 같은 단계 안의 순서(법규 무게 순)
BANDS = [(60, 70, "60~70일"), (70, 90, "70~90일"), (90, 120, "90~120일"), (120, None, "120일 초과")]
SHOW = 12        # 한 칸에 이름을 다 적는 회사 수 — 넘으면 일부만 적고 「등 총 N개사」(눌러서 전부)
HEAD = 8


def plain(t: Any) -> str:
    """「2-3」 같은 시트 번호에 이름을 붙인다(2-3. 외감회사)."""
    s = re.sub(r"(^|[^\d.\-])(2-10|2-3|2-8|4-10|8-3)(?![\d.\-])", lambda m: f"{m.group(1)}{m.group(2)}. {SHEETS[m.group(2)]}", str(t or ""))
    return re.sub(r"(\d+-\d+\.\s)([^\s]+)\s+\2", r"\1\2", s)


def cname(v: Any) -> str:
    return re.sub(r"\(주\)", "㈜", str(v or "")).strip()


def _uniq(xs: list[str]) -> list[str]:
    return list(dict.fromkeys(x for x in xs if x))


def _band(days: int) -> str:
    for lo, hi, label in BANDS:
        if days > lo and (hi is None or days <= hi):
            return label
    return BANDS[-1][2]


def _tier_of(code: str, level: str) -> str:
    for key, _t, codes in TIERS:
        if code in codes:
            return key
    return {"위반의심": "law", "중점확인": "diff", "불일치": "diff"}.get(level, "note")


def _is_note(i: dict[str, Any]) -> bool:
    return i.get("code") in NOTE_CODES or i.get("title") in NOTE_TITLES or (i.get("level") == "참고" and i.get("code") != "overload")


def _co(i: dict[str, Any]) -> str:
    return cname(re.sub(r"\(연결\)$", "", str(i.get("company") or "")))


def _names(names: list[str]) -> tuple[str, str]:
    """(화면 글, 전부 글) — 많으면 일부만 + 「등」."""
    full = ", ".join(names)
    return (full, full) if len(names) <= SHOW else (", ".join(names[:HEAD]) + " 등", full)


def _sheets(items: list[dict[str, Any]]) -> str:
    out: list[str] = []
    for i in items:
        for ref in i.get("refs") or []:
            m = re.match(r"^(2-10|2-3|2-8|4-10|8-3)\b", str(ref))
            if m:
                out.append(f"{m.group(1)}. {SHEETS[m.group(1)]}")
            elif " › " in str(ref):
                f = str(ref).split(" › ")[0]
                f = re.sub(r"\.[A-Za-z0-9]+$", "", f)
                out.append(f if len(f) <= 22 else f[:12] + "…" + f[-8:])
    return ", ".join(_uniq(out))


def _group_row(rows: list[dict[str, Any]], title: str) -> dict[str, Any]:
    cos = _uniq([cname(r.get("company")) for r in rows if " ↔ " not in str(r.get("company") or "")])       # 「(연결)」 표시는 남긴다
    n = len(rows)
    text, full = _names(cos)
    lead = f"{len(cos)}개사" + (f"·{n}건" if n != len(cos) else "")
    return {"lead": lead + ":", "text": text, "full": full if full != text else "", "total": len(cos), "count": n}


def _days_row(rows: list[dict[str, Any]]) -> dict[str, Any]:
    dated = [r for r in rows if isinstance(r.get("days"), int)]
    parts = {"개별": [r for r in dated if (r.get("part") or "개별") == "개별"], "연결": [r for r in dated if r.get("part") == "연결"]}
    lead = f"총 {len(dated)}건"
    lines = ["개별 {0}건, 연결 {1}건".format(len(parts["개별"]), len(parts["연결"]))] if parts["연결"] else []
    sub = []
    for lo, hi, label in BANDS:
        g = [r for r in dated if _band(r["days"]) == label]
        if not g:
            sub.append({"label": label, "lead": "해당 없음", "text": "", "lines": []})
            continue
        g = sorted(g, key=lambda r: -r["days"])
        names = _uniq([_co(r) + ("(연결)" if r.get("part") == "연결" else "") for r in g])
        if len(names) <= SHOW:
            sub.append({"label": label, "lead": f"{len(names)}개사:", "text": ", ".join(names), "lines": []})
        else:
            a = sum(1 for r in g if (r.get("part") or "개별") == "개별")
            b = len(g) - a
            lo_r, hi_r = g[-1], g[0]
            lead_s = f"개별 {a}개사" + (f", 연결 {b}개사" if b else "")
            sub.append({"label": label, "lead": lead_s, "text": "", "lines": [
                f"최소 {lo_r['days']}일: {_co(lo_r)}{'(연결)' if lo_r.get('part') == '연결' else ''}",
                f"최대 {hi_r['days']}일: {_co(hi_r)}{'(연결)' if hi_r.get('part') == '연결' else ''}"],
                "full": ", ".join(names)})
    detail = [{"company": _co(r), "part": r.get("part") or "개별", "base": r.get("base_date") or "", "collect": r.get("collect_date") or "", "days": r["days"]}
              for r in sorted(dated, key=lambda r: -r["days"])]
    return {"lead": lead, "text": "", "lines": lines, "sub": sub, "days_detail": detail, "total": len(dated), "count": len(dated)}


def build(items: list[dict[str, Any]], groups: list[dict[str, Any]], sales: dict[str, Any] | None, grade: dict[str, str]) -> dict[str, Any]:
    """items = 점검 항목 전체, groups = qc_review_tables 의 표 묶음(idx = items 의 자리). 반환 = 요약표 rows + 아래 상세·※ 문구."""
    buckets: dict[tuple[str, str, str], list[int]] = {}
    notes_map: dict[tuple[str, str], list[int]] = {}
    for idx, i in enumerate(items):
        if _is_note(i):
            notes_map.setdefault((str(i.get("level")), str(i.get("title"))), []).append(idx)
        else:
            buckets.setdefault((_tier_of(str(i.get("code")), str(i.get("level"))), str(i.get("level")), str(i.get("title"))), []).append(idx)

    rows_by_tier: dict[str, list[dict[str, Any]]] = {key: [] for key, _t, _c in TIERS}
    details: list[dict[str, Any]] = []
    gi_of = {k: n for n, g in enumerate(groups) for k in g.get("idx") or []}
    for (tier, level, title), idxs in buckets.items():
        rs = [items[k] for k in idxs]
        code = str(rs[0].get("code"))
        row: dict[str, Any] = {"title": TITLES.get(code) or plain(title), "grade": grade.get(level, "하"), "code": code, "sheets": _sheets(rs),
                               "basis": next((r.get("basis") for r in rs if r.get("basis")), ""), "gi": sorted({gi_of[k] for k in idxs if k in gi_of})}
        if code == "archive_60":
            row.update(_days_row(rs))
        elif code == "timely_mark":
            dated = sorted([r for r in rs if isinstance(r.get("days"), int)], key=lambda r: -r["days"])
            row.update({"lead": f"{len(rs)}건", "text": "", "count": len(rs), "total": len(_uniq([_co(r) for r in rs])), "lines": (
                [f"최소 {dated[-1]['days']}일: {_co(dated[-1])}", f"최대 {dated[0]['days']}일: {_co(dated[0])}"] if dated else [])})
        elif code == "cross_review":
            pairs = [p for p in (r.get("pair") for r in rs) if isinstance(p, list) and len(p) == 2]
            row.update({"lead": f"{len(rs)}개 그룹", "text": "", "count": len(rs), "total": len(rs),
                        "lines": [f"{cname(a['partner'])}({len(a['companies'])}개사) ↔ {cname(b['partner'])}({len(b['companies'])}개사)" for a, b in pairs]})
            if pairs:
                details.append({"title": "교차심리 상세 회사", "head": ["교차심리 담당자", "상세 회사"],
                                "rows": [[f"{cname(a['partner'])} ↔ {cname(b['partner'])}", ", ".join(_uniq([cname(c) for c in a["companies"] + b["companies"]]))] for a, b in pairs]})
        elif code == "overload":
            ppl = [(re.sub(r"^담당이사\s*", "", str(r.get("company") or "")), r.get("n")) for r in rs]
            row.update({"lead": f"{len(ppl)}명:", "text": ", ".join(f"{cname(p)} {n}개사" if n else cname(p) for p, n in ppl), "count": len(ppl), "total": len(ppl)})
        else:
            row.update(_group_row(rs, title))
        row["lines"] = row.get("lines") or []
        rows_by_tier[tier].append(row)

    if sales and sales.get("companies"):               # 매출장 대사(독립성)
        m = sales.get("summary") or {}
        hi = _uniq([cname(g["company"]) for g in sales["companies"] if g.get("risk") == "상"])
        lo = _uniq([cname(g["company"]) for g in sales["companies"] if g.get("risk") != "상"])
        names = hi + [x for x in lo if x not in hi]
        text, full = _names(names)
        rows_by_tier["indep"].append({"title": "매출장 대사(독립성) — 감사대상회사에 대한 비감사용역 후보", "grade": "상" if hi else "중", "code": "sales", "sheets": "매출장",
                                      "lead": f"상 {len(hi)}·중 {len(names) - len(hi)}개사:", "text": text, "full": full if full != text else "", "lines": [], "gi": [],
                                      "count": int(m.get("candidates") or len(names)), "total": len(names), "basis": "상세는 아래 「매출장 대사(독립성)」"})

    order = {"상": 0, "중": 1, "하": 2}
    table: list[dict[str, Any]] = []
    n = 0
    divider_done = False
    for key, tier_title, _codes in TIERS:
        rs = sorted(rows_by_tier[key], key=lambda r: (RANK.get(r.get("code"), 99), order.get(r["grade"], 3), -int(r.get("count") or 0)))
        if key == "diff" and rs and not divider_done:
            table.append({"divider": "사실관계 확인이 필요한 자료 간 대사 차이 — 그 자체로 법규위반을 의미하지 않을 수 있음"})
            divider_done = True
        for r in rs:
            n += 1
            r["no"], r["tier"] = n, key
            table.append(r)

    notes: list[str] = []
    short = {"timely_mark": "「적시취합」 표시 불일치", "reviewer": "심리담당자 대사 차이", "same_hours": "감사시간 동일"}
    diff_titles = _uniq([short.get(r.get("code"), r["title"]) for r in rows_by_tier["diff"]])
    if diff_titles:
        notes.append("※ " + ", ".join(diff_titles[:4]) + " 등은 그 자체로 법규위반을 의미하지 않을 수 있으므로 사실관계 확인이 필요한 대사·참고사항으로 구분함.")
    for (level, title), idxs in sorted(notes_map.items(), key=lambda kv: -len(kv[1])):
        cos = _uniq([_co(items[k]) for k in idxs if " ↔ " not in str(items[k].get("company") or "")])
        text, _full = _names(cos)
        if title in NOTE_TITLES:
            notes.append(f"※ 참고: 4-10. 비감사서비스에 비감사용역이 있으나 2-3. 외감회사에 비감사보수가 없는 회사는 {text}"
                         f"{'' if text.endswith('등') else ' 등'} 총 {len(cos)}개사임.")
        else:
            notes.append(f"※ 참고: {plain(title)} — {text}{'' if text.endswith('등') else ' 등'} 총 {len(cos)}개사·{len(idxs)}건.")
    return {"table": table, "details": details, "notes": notes, "total": n}
