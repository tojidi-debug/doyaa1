"""[품감] 제출자료 대사(개발) — 회계법인 사전제출자료 시트끼리 맞춰 보고 중요 체크포인트를 고른다
(2026-10-14, 개발서버 전용).

    2-3. 외부감사 수행회사 현황   ← 기준(회사·사업연도마다 한 줄)
    2-8. 감사조서 자체점검 결과   ← 감사보고서일·조서 취합완료일·실사담당자
    2-10. 담당이사 교체현황       ← 회사마다 FY별 담당이사

세 시트가 한 파일에 오든 따로 오든 `qc_sample._parse_sheet` 가 만든 같은 모양(`roles`·`rows`)을 받는다.

## 단계 (`LEVELS`)

    위반의심   법규·기준을 어긴 것으로 보이는 것 — 연속감사 한도 초과, 조서 제출 60일 초과,
              사전심리가 감사보고서일 뒤에 끝남, 자기심리
    중점확인   그 자체로 위반은 아니지만 들여다봐야 하는 것 — 이름을 달리 적어 연속감사가 끊겨 보임,
              교차심리, 자체기장 회사의 큰 비감사보수, 연결 미작성 의심
    불일치     시트끼리 값이 다름 — 감사보고서일·심리담당자·담당이사 표기
    참고       알아 두면 되는 것 — 한쪽 시트에만 있는 회사, 과다수임, 감사시간 반복
    일치       맞춰 본 결과 같았던 것(화면에서 접어 둔다)

## 회사는 이름 열쇠로 묶는다 (`company_key`)

2-8·2-10 에는 등록번호가 없다. `(주)`·`주식회사`·`㈜`·`유한회사`·`(유)`·빈칸·영문 법인격(Co., Ltd.)을
걷고, 영문 글자는 한글 이름으로 읽는다(LG → 엘지, SK → 에스케이, & → 앤). 그래서
「LG테크 유한회사」와 「엘지테크(유)」가 한 회사가 된다. 묶인 표기들은 `aliases` 로 돌려준다.

규정 근거 문구는 담당부서가 준 참고자료(2026-10-14)의 표현을 따른다.
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from typing import Any

from gumiho.services import company_name

LEVELS = ("위반의심", "중점확인", "불일치", "참고", "일치")
SUBMIT_DAYS = 60

BASIS = {
    "rotation": "외부감사법 제9조제5항 — 동일 이사의 연속 감사업무 제한(비상장 6개 · 금융회사 4개 사업연도). "
                "주권상장·대형비상장(직전 자산총액 5천억원 이상)은 연속 3개 사업연도를 감사한 이사를 그 다음 연속 3개 사업연도에 투입 금지",
    "archive": "감사기준서 230 — 최종 감사파일 취합은 감사보고서일로부터 60일 이내",
    "review": "업무품질관리검토(사전심리)는 감사보고서일 이전에 완료 — 감사보고서일은 심리 종결 후의 날짜",
    "cross": "업무품질관리검토 — 담당이사 상호 간 교차심리 금지(검토자의 객관성)",
    "nas_banned": "공인회계사법 제21조제2항·시행령 제14조 — 감사대상회사에 회계기록·재무제표 작성, 내부감사 대행, 재무정보체제 구축·운영, "
                  "자산 등 평가, 보험계리, 투자권유 등 금지",
    "post_review": "품질관리기준서 1 — 사후심리(모니터링)는 그 업무에 관여하지 않은 사람이 수행(사전 심리자와 분리)",
    "nonaudit": "외부감사법 제6조제6항·시행령 제8조제6항(재무제표 대리작성·회계처리 자문 금지), 공인회계사법 제21조제2항(회계기록·재무제표 작성 등 직무제한)",
    "consolidated": "연결재무제표 작성의무 확인 — 연결감사 미계약이어도 연결감사보고서 발행(미계약 시 의견거절)",
    "hours": "감사시간 모니터링 — 과다수임(15개 이상) 감사팀의 충분한 시간 투입, 규모·업종이 달라도 집계시간이 같은 경우 검토",
    "qc_staff": "감사인 등의 조직 및 운영 등에 관한 규정 제17조제6항 — 직전연도 외감 대상 100개 이상이면 품질관리전담자 지정",
}

# ── 이름 열쇠 ────────────────────────────────────────────────────────────

_LATIN = {
    "a": "에이", "b": "비", "c": "시", "d": "디", "e": "이", "f": "에프", "g": "지", "h": "에치",
    "i": "아이", "j": "제이", "k": "케이", "l": "엘", "m": "엠", "n": "엔", "o": "오", "p": "피",
    "q": "큐", "r": "알", "s": "에스", "t": "티", "u": "유", "v": "브이", "w": "더블유", "x": "엑스",
    "y": "와이", "z": "지",
}
# 한글로 적을 때 흔히 갈리는 표기를 한쪽으로 모은다(「에이치」/「에치」, 「씨」/「시」, 「제트」/「지」).
_HANGUL_SAME = (("에이치", "에치"), ("씨", "시"), ("제트", "지"))
_EN_FORMS = re.compile(
    r"(?<![a-z])(co\.?\s*,?\s*ltd\.?|company\s+limited|corporation|corp\.?|inc\.?|limited|ltd\.?|l\.?l\.?c\.?)(?![a-z])",
    re.I)
_EXTRA_FORMS = ("(유한)", "(합)", "(합자)")


def company_key(name: Any) -> str:
    s = unicodedata.normalize("NFKC", str(name or ""))
    for form in _EXTRA_FORMS:
        s = s.replace(form, "")
    s = _EN_FORMS.sub(" ", s)
    s = company_name.name_key(s).replace("&", "앤")
    s = "".join(_LATIN.get(ch, ch) for ch in s)
    for a, b in _HANGUL_SAME:
        s = s.replace(a, b)
    return re.sub(r"[^0-9가-힣]", "", s)


_TITLES = re.compile(r"(이사|상무|전무|부대표|대표|파트너|회계사|cpa|님)$", re.I)


def person_key(name: Any) -> str:
    s = re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(name or ""))).lower()
    return _TITLES.sub("", s) if len(s) > 2 else s


def same_person(a: Any, b: Any) -> bool:
    # 「-」·「○」·「해당없음」 같은 빈칸 표시는 사람이 아니다 — 서로 같아도 같은 사람으로 보지 않는다(2026-10-15)
    if not (_is_name(a) and _is_name(b)):
        return False
    ka, kb = person_key(a), person_key(b)
    return bool(ka) and ka == kb


def _lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def similar_person(a: Any, b: Any) -> bool:
    """같은 사람을 달리 적은 것으로 볼 만한가 — 같으면 False(그건 `same_person`).
    세 글자 이상에서 한 글자 차이, 또는 한쪽이 다른 쪽을 품고 한 글자만 더 붙은 경우."""
    if not (_is_name(a) and _is_name(b)):
        return False
    ka, kb = person_key(a), person_key(b)
    if not ka or not kb or ka == kb:
        return False
    # 한글 이름은 성(첫 글자)이 다르면 다른 사람이다(「최심리」·「윤심리」).
    if re.match(r"[가-힣]", ka) and re.match(r"[가-힣]", kb) and ka[0] != kb[0]:
        return False
    if min(len(ka), len(kb)) >= 3 and _lev(ka, kb) <= 1:
        return True
    short, long_ = sorted((ka, kb), key=len)
    return len(short) >= 3 and short in long_ and len(long_) - len(short) <= 1


def _close(a: Any, b: Any) -> bool:
    return same_person(a, b) or similar_person(a, b)


# ── 값 읽기 ──────────────────────────────────────────────────────────────

_DATE = re.compile(r"(\d{4}|\d{2})\s*[.\-/년]\s*(\d{1,2})\s*[.\-/월]\s*(\d{1,2})")


def parse_date(v: Any) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 <= v <= 80000:                    # 엑셀 일련번호
            return date(1899, 12, 30) + timedelta(days=int(v))
        return None
    m = _DATE.search(str(v))
    if not m:
        return None
    y = int(m.group(1))
    y = y + 2000 if y < 100 else y
    try:
        return date(y, int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def _num(v: Any) -> float | None:
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


# 「있음」 표시와 「없음」 표시 — 회계법인마다 적는 모양이 달라도 같은 뜻으로 본다(사용자 지정 2026-10-15).
# 화면 쪽 qc_sample_data.js 의 YES·NO 와 같은 목록.
_YES = {"y", "yes", "o", "여", "예", "유", "있음", "연결", "해당", "해당함", "해당있음", "작성", "○", "◯", "●", "v",
        "✔", "✓", "☑", "체크", "대상", "true"}
_NO = {"n", "no", "x", "×", "✗", "부", "무", "없음", "아니오", "아니요", "해당없음", "해당사항없음", "해당무", "비해당",
       "비대상", "미작성", "미해당", "-", "--", "―", "—", "n/a", "na", "#n/a", "공란", "false", "미흡", "별도", "개별"}


def _yes(v: Any) -> bool | None:
    s = re.sub(r"\s+", "", str(v or "")).lower()
    if not s:
        return None
    if s in _YES:
        return True
    if s in _NO:
        return False
    return None


def _fmt(d: date | None) -> str:
    return d.isoformat() if d else "-"


def year_of(v: Any, fy: int | None) -> int | None:
    s = re.sub(r"\s+", "", str(v or ""))
    if not s:
        return None
    if s.startswith("전전기"):
        return fy - 2 if fy else None
    if s.startswith("전기"):
        return fy - 1 if fy else None
    if s.startswith("당기"):
        return fy
    m = re.search(r"(19|20)\d{2}", s)
    return int(m.group(0)) if m else None


# ── 시트 → 레코드 ─────────────────────────────────────────────────────────

def _records(sheet: dict[str, Any] | None, kind: str) -> list[dict[str, Any]]:
    if not sheet:
        return []
    roles = sheet.get("roles") or {}
    out = []
    for r in sheet.get("rows") or []:
        v = r.get("values") or {}
        rec: dict[str, Any] = {"row": r.get("row"), "kind": kind}
        for role, letter in roles.items():
            rec[role] = v.get(letter)
        rec["name"] = str(rec.get("company") or "").strip()
        rec["ckey"] = company_key(rec["name"])
        if rec["ckey"]:
            out.append(rec)
    return out


def guess_fy(s23: list[dict[str, Any]], s210: list[dict[str, Any]]) -> int:
    """당기 사업연도 — 2-3 의 당기 감사보고서일에서 석 달을 뺀 해의 최빈값. 없으면 2-10 의 마지막 FY."""
    votes: Counter[int] = Counter()
    for rec in s23:
        y = str(rec.get("year") or "").strip()
        if y and not y.startswith("당기"):
            continue
        d = parse_date(rec.get("report_date"))
        if d:
            votes[(d - timedelta(days=90)).year] += 1
    if votes:
        return votes.most_common(1)[0][0]
    years = [int(k[3:]) for rec in s210 for k in rec if k.startswith("fy:") and rec[k]]
    return max(years) if years else date.today().year - 1


def _where(rec: dict[str, Any]) -> str:
    return {"s23": "2-3", "s28": "2-8", "s210": "2-10", "s410": "4-10", "s83": "8-3"}[rec["kind"]] + f" {rec['row']}행"


class _Out:
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []
        self.ok: list[dict[str, Any]] = []

    def add(self, level: str, code: str, title: str, company: str, year: Any, detail: str,
            basis: str = "", refs: tuple[dict[str, Any], ...] = ()) -> None:
        self.items.append({"level": level, "code": code, "title": title, "company": company,
                           "year": year, "detail": detail, "basis": basis,
                           "refs": [_where(r) for r in refs if r]})

    def good(self, code: str, title: str, company: str, year: Any, detail: str,
             refs: tuple[dict[str, Any], ...] = ()) -> None:
        self.ok.append({"level": "일치", "code": code, "title": title, "company": company, "year": year,
                        "detail": detail, "refs": [_where(r) for r in refs if r]})


# ── 회사 구분(연속감사 한도) ───────────────────────────────────────────────

_FINANCE = ("은행", "보험", "증권", "금융투자", "저축은행", "여신전문", "캐피탈", "카드사", "신탁")


BIG_ASSETS = 500_000          # 대형비상장 — 직전 사업연도 말 자산총액 5천억원(사전제출자료 단위 백만원)
COOLING = 3                   # 상장·대형비상장: 연속 3개 사업연도 뒤 다음 연속 3개 사업연도는 투입 금지(사용자 지정 2026-10-15)


def _big_assets(v: Any) -> bool:
    """직전 자산총액이 5천억원 이상인가 — 백만원 단위로 보되, 10억이 넘는 수는 원 단위로 적은 것으로 본다."""
    n = _num(v)
    if n is None:
        return False
    return n >= (BIG_ASSETS * 1_000_000 if n >= 1_000_000_000 else BIG_ASSETS)


def _limit(m23: dict[str, Any] | None, r210: dict[str, Any] | None,
           prev_assets: Any = None) -> tuple[int, int | None, str]:
    """(한도, 셈 시작 연도, 사유). 상장·대형비상장은 연속 3개 사업연도(뒤 3개 사업연도 투입 금지 — `_cooling`).
    대형비상장은 직전 자산총액 5천억원 이상(또는 대형비상장 표시)이고 2018.11.1. 이후 시작 사업연도(=2019)부터 센다."""
    ctype = str((m23 or {}).get("company_type") or "")
    if re.search(r"유가증권|코스닥|코넥스|kospi|kosdaq", ctype, re.I) or ("상장" in ctype and "비상장" not in ctype):
        return COOLING, None, "주권상장"
    by_assets = _big_assets(prev_assets) or _big_assets((r210 or {}).get("assets_prev"))
    big = _yes((r210 or {}).get("large_unlisted")) or _yes((m23 or {}).get("large_unlisted")) or "대형" in ctype or by_assets
    if big:
        return COOLING, 2019, "대형비상장(직전 자산총액 5천억원 이상, 2019 사업연도부터 셈)"
    ind = str((m23 or {}).get("industry") or "")
    if any(w in ind for w in _FINANCE):
        return 4, None, "금융회사로 보임(업종 확인)"
    return 6, None, "비상장"


def _cooling(why: str) -> int:
    """다음 연속 몇 개 사업연도에 같은 이사를 쓸 수 없나 — 상장·대형비상장만(사용자 지정 2026-10-15)"""
    return COOLING if why.startswith(("주권상장", "대형비상장")) else 0


def per_year(fiscal: Any) -> int:
    """한 해에 사업연도(기수)가 몇 번인가 — 결산기가 「6월, 12월」·「반기」면 2, 「분기」·「3개월」이면 4.
    연속하는 사업연도는 해가 아니라 기수로 센다(사용자 지정 2026-10-14): 반기 결산 회사는 3년이면 6개 사업연도다."""
    s = str(fiscal or "")
    months = {int(m) for m in re.findall(r"(\d{1,2})\s*월", s) if 1 <= int(m) <= 12}
    if len(months) >= 2:
        return len(months)
    if re.search(r"분기|3\s*개월", s):
        return 4
    if re.search(r"반기|6\s*개월", s):
        return 2
    return 1


def _periods(years: int, k: int) -> str:
    return f"{years}년" if k == 1 else f"{years}년 × 연 {k}회 결산 = {years * k}개 사업연도"


def _runs(seq: dict[int, str], match) -> list[tuple[int, int, list[str]]]:
    """연속 구간들 — (시작, 끝, 그 사이 이름들). `match(a, b)` 가 참이면 이어 붙인다."""
    out: list[tuple[int, int, list[str]]] = []
    for y in sorted(seq):
        name = seq[y]
        if out and out[-1][1] == y - 1 and match(out[-1][2][-1], name):
            s, _, names = out[-1]
            out[-1] = (s, y, names + [name])
        else:
            out.append((y, y, [name]))
    return out


def _back(seq: dict[int, str], fy: int, who: str, match) -> int:
    n, y = 0, fy
    while y in seq and match(seq[y], who):
        n += 1
        y -= 1
    return n


# ── 대사 ────────────────────────────────────────────────────────────────

def run(parsed: dict[str, dict[str, Any]], *, fy: int | None = None,
        docs: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """`docs` 는 `qc_sample_docs` 가 뽑은 문서별 값({name, company, facts})이다."""
    s23, s28, s210 = (_records(parsed.get(k), k) for k in ("s23", "s28", "s210"))
    s410, s83 = (_records(parsed.get(k), k) for k in ("s410", "s83"))
    fy = fy or guess_fy(s23, s210)
    for rec in s23 + s28 + s410 + s83:
        rec["y"] = year_of(rec.get("year"), fy) if rec.get("year") not in (None, "") else fy

    out = _Out()
    by23: dict[tuple[str, int | None], dict[str, Any]] = {}
    any23: dict[str, dict[str, Any]] = {}
    for rec in s23:
        by23.setdefault((rec["ckey"], rec["y"]), rec)
        if rec["y"] == fy or rec["ckey"] not in any23:
            any23[rec["ckey"]] = rec if rec["y"] == fy else any23.get(rec["ckey"], rec)
    name_of = {k: r["name"] for k, r in any23.items()}

    def label(rec: dict[str, Any]) -> str:
        return name_of.get(rec["ckey"], rec["name"])

    cur23 = [r for r in s23 if r["y"] == fy]
    pinfo = period_info(s23, fy)
    _check_23(out, s23, fy, bool(s210), pinfo)
    _check_prev_step(out, s23, fy)
    _check_people(out, cur23)
    if s28:
        _check_28(out, s28, by23, any23, label, fy)
    if s210:
        _check_210(out, s210, by23, any23, cur23, fy, label, pinfo)
    if parsed.get("s410"):
        _check_410(out, s410, cur23, fy, label, parsed.get("s410"))
    if s83:
        _check_83(out, s83, by23, fy, label)

    if docs:
        _check_docs(out, docs, s23, fy)

    aliases = defaultdict(set)
    for rec in s23 + s28 + s210:
        aliases[rec["ckey"]].add(rec["name"])
    out.items.sort(key=lambda i: (LEVELS.index(i["level"]), str(i["company"]), i["code"]))
    summary = {lv: 0 for lv in LEVELS}
    for i in out.items:
        summary[i["level"]] += 1
    summary["일치"] = len(out.ok)
    return {
        "fy": fy, "items": out.items, "ok": out.ok, "summary": summary,
        "sheets": {k: bool(parsed.get(k)) for k in ("s23", "s28", "s210", "s410", "s83")},
        "aliases": [{"key": k, "names": sorted(v)} for k, v in aliases.items() if len(v) > 1],
    }


def collect_done(rec: dict[str, Any], arc: str, wh: str) -> date | None:
    """조서 취합완료일 — 전산조서 archive일·서면조서 창고입고일 중 적힌 것의 빠른 날"""
    got = [d for d in (parse_date(rec.get(arc)), parse_date(rec.get(wh))) if d]
    return min(got) if got else None


def _which(rec: dict[str, Any], arc: str, wh: str, cd: date) -> str:
    a, w = parse_date(rec.get(arc)), parse_date(rec.get(wh))
    if a and w:
        return "archive일" if a == cd else "창고입고일"
    return "archive일" if a else "창고입고일"


def period_months(dates: list[date]) -> int:
    """같은 회사 당기 줄들의 감사보고서일 간격으로 결산 단위(3·6개월)를 짐작 — 모르면 0"""
    ds = sorted(set(dates))
    if len(ds) < 2:
        return 0
    gaps = sorted((b - a).days for a, b in zip(ds, ds[1:]))
    m = round(gaps[len(gaps) // 2] / 30.4)
    return m if m in (1, 2, 3, 4, 6) else 0


def period_info(s23: list[dict[str, Any]], fy: int) -> dict[str, dict[str, Any]]:
    """회사별 결산 단위 — {ckey: {k: 한 해 기수, multi: 당기 줄이 기수별로 여럿, last: 계속감사년수가 가장 큰 당기 줄}}.
    k 는 결산기 글(「6월, 12월」·반기·분기)로, 없으면 당기 줄들의 감사보고서일 간격으로 짐작(사용자 지정 2026-10-15 —
    결산기 칸을 비운 회계법인도 같게). 기수별로 줄을 나눠 적은 회사의 계속감사년수는 해가 아니라 기수다."""
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in s23:
        if r["y"] == fy:
            groups[r["ckey"]].append(r)
    out: dict[str, dict[str, Any]] = {}
    for key, rows in groups.items():
        k = per_year(rows[0].get("fiscal"))
        if k == 1 and len(rows) >= 2:
            m = period_months([d for d in (parse_date(r.get("report_date")) for r in rows) if d])
            k = 12 // m if m else 1
        last = max(rows, key=lambda r: (_num(r.get("partner_years")) or 0, str(r.get("report_date") or "")))
        out[key] = {"k": k, "multi": len(rows) >= 2 and k > 1, "last": last, "rows": rows}
    return out


def _check_periods(out: _Out, s23: list[dict[str, Any]], fy: int) -> None:
    """당기 줄이 한 해 사업연도 수보다 많으면 — 전기 사업연도분이 당기에 섞였는지(사용자 확인 2026-10-15:
    3개월 결산 회사가 당기에 5줄, 맨 앞 1줄은 전년도 사업연도)."""
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in s23:
        if r["y"] == fy:
            groups[r["ckey"]].append(r)
    for rows in groups.values():
        if len(rows) < 2:
            continue
        k = per_year(rows[0].get("fiscal"))
        dates = [d for d in (parse_date(r.get("report_date")) for r in rows) if d]
        m = 12 // k if k > 1 else period_months(dates)
        if not m or len(rows) <= 12 // m:
            continue
        first = min(dates) if dates else None
        out.add("불일치", "period_extra", "당기에 한 해 사업연도 수보다 많은 줄", rows[0]["name"], fy,
                f"{m}개월 단위 결산이면 한 해 {12 // m}개인데 당기 {len(rows)}줄"
                + (f" — 가장 이른 감사보고서일 {_fmt(first)} 줄이 전년도 사업연도분인지 확인" if first else ""), "", tuple(rows))


def _check_23(out: _Out, s23: list[dict[str, Any]], fy: int, has210: bool,
              pinfo: dict[str, dict[str, Any]] | None = None) -> None:
    pinfo = pinfo if pinfo is not None else period_info(s23, fy)
    _check_periods(out, s23, fy)
    prev_assets = {r["ckey"]: r.get("assets") for r in s23 if r["y"] == fy - 1}     # 직전 자산총액 = 전기 줄의 자산총계
    for r in s23:                                       # 2-3 「직전연도 자산총계」 칸이 있으면 그것을 먼저
        if r["y"] == fy and _num(r.get("assets_prev")) is not None:
            prev_assets[r["ckey"]] = r.get("assets_prev")
    for rec in s23:
        name, y = rec["name"], rec["y"]
        if y != fy:
            continue        # 주요 비교 대상은 당기분(사용자 지정 2026-10-15) — 전기 줄은 2-10 연속감사 계산에만 쓴다
        rd = parse_date(rec.get("report_date"))
        crd = parse_date(rec.get("con_report_date"))

        # 사전심리·종결 서명이 감사보고서일 뒤에 있으면 안 된다.
        late, seen = [], False
        for role, what, base, base_name in (
            ("review_done", "심리 완료일", rd, "감사보고서일"),
            ("reviewer_close", "심리담당자 종결 서명일", rd, "감사보고서일"),
            ("partner_close", "담당이사 종결 서명일", rd, "감사보고서일"),
            ("reviewer_con_close", "심리담당자 연결종결 서명일", crd or rd, "연결감사보고서일"),
            ("partner_con_close", "담당이사 연결종결 서명일", crd or rd, "연결감사보고서일"),
        ):
            d = parse_date(rec.get(role))
            if d and base:
                seen = True
                if d > base:
                    late.append(f"{what} {_fmt(d)} > {base_name} {_fmt(base)}")
        if late:
            out.add("위반의심", "review_order", "감사보고서일이 심리·종결보다 앞섬", name, y,
                    " · ".join(late), BASIS["review"], (rec,))
        elif seen:
            out.good("review_order", "심리·종결 → 감사보고서일 순서", name, y, f"감사보고서일 {_fmt(rd)}", (rec,))

        # 조서 취합완료 60일 — 취합완료일 = 전산조서 archive일·서면조서 창고입고일 중 빠른 날(사용자 지정 2026-10-15).
        # 개별은 감사보고서일, 연결은 연결감사보고서일부터 따로 센다. 연결만 넘으면 「회사(연결)」.
        for part, (arc, wh), base, base_name, label in (
                ("개별", ("archive", "warehouse"), rd, "감사보고서일", name),
                ("연결", ("con_archive", "con_warehouse"), crd or rd, "연결감사보고서일", f"{name}(연결)")):
            cd = collect_done(rec, arc, wh)
            if not (cd and base):
                continue
            days = (cd - base).days
            if days > SUBMIT_DAYS:
                out.add("위반의심", "archive_60", "조서 취합완료 60일 초과", label, y,
                        f"{part} 조서 취합완료일 {_fmt(cd)}({_which(rec, arc, wh, cd)}) · {base_name} {_fmt(base)} 후 {days}일",
                        BASIS["archive"], (rec,))
            else:
                out.good("archive_60", "조서 취합완료 60일 이내", label, y, f"{days}일", (rec,))

        sub = parse_date(rec.get("submit_date"))
        if sub and rd and sub < rd:
            out.add("불일치", "submit_order", "감사보고서 제출일이 감사보고서일보다 앞섬", name, y,
                    f"제출일 {_fmt(sub)} < 감사보고서일 {_fmt(rd)}", "", (rec,))

        if y != fy:
            continue
        # 연결
        # 연결 = 연결로 체크 + 연결대상 종속회사(종속회사수 ≥ 1)
        cons, subs = _yes(rec.get("consolidated")), _num(rec.get("subsidiaries"))
        has_subs_col = "subsidiaries" in rec
        if cons and has_subs_col and not (subs and subs > 0):
            out.add("불일치", "consolidated", "연결로 체크했는데 종속회사수가 0·빈 칸", name, y,
                    f"연결 여부 「{rec.get('consolidated')}」 · 종속회사수 「{rec.get('subsidiaries') if rec.get('subsidiaries') is not None else ''}」",
                    BASIS["consolidated"], (rec,))
        elif cons and "con_report_date" in rec and not crd:
            out.add("중점확인", "consolidated", "연결 대상인데 연결감사보고서일이 비어 있음", name, y,
                    "연결 여부 「예」 · 연결감사보고서일 없음", BASIS["consolidated"], (rec,))
        if cons is False and crd:
            out.add("불일치", "consolidated", "연결 여부 「별도」인데 연결감사보고서일이 적혀 있음", name, y,
                    f"연결 여부 「{rec.get('consolidated')}」 · 연결감사보고서일 {_fmt(crd)}", "", (rec,))
        if cons is False and subs and subs > 0:
            out.add("중점확인", "consolidated", "종속회사가 있는데 연결 「아니오」", name, y,
                    f"종속회사수 {int(subs)} · 연결 여부 「{rec.get('consolidated')}」", BASIS["consolidated"], (rec,))

        stated = _num(rec.get("partner_years"))
        pi = pinfo.get(rec["ckey"]) or {}
        if pi.get("multi") and pi.get("last") is not rec:
            stated = None                   # 기수별로 여러 줄이면 계속감사년수가 가장 큰(마지막) 줄 하나로만 본다
        if stated is not None and rec.get("partner"):
            limit, _, why = _limit(rec, None, prev_assets.get(rec["ckey"]))
            # 기수별 줄의 계속감사년수는 이미 기수 — 곱하지 않는다. 한 줄로 적은 반기·분기 회사만 해 × 연 결산 횟수
            k = 1 if pi.get("multi") else per_year(rec.get("fiscal"))
            if stated * k > limit:
                out.add("위반의심", "partner_years", f"담당이사 계속감사년수가 한도({limit}개 사업연도) 초과", name, y,
                        f"{rec.get('partner')} {_periods(int(stated), k)} · {why}", BASIS["rotation"], (rec,))
            elif stated * k == limit and not has210:
                after = f"다음 연속 {_cooling(why)}개 사업연도에는 이 이사 투입 불가" if _cooling(why) else "다음 사업연도에는 교체 필요"
                out.add("참고", "partner_6", f"당기로 연속감사 한도({limit}개 사업연도)에 닿음", name, y,
                        f"{rec.get('partner')} {_periods(int(stated), k)} — {after} · {why}", BASIS["rotation"], (rec,))

        _check_nonaudit(out, rec, fy)


def _check_prev_step(out: _Out, s23: list[dict[str, Any]], fy: int) -> None:
    """전기는 당기 자료가 맞는지 대사하는 데만 쓴다(사용자 지정 2026-10-15) — 같은 회사의 전기·당기 줄에서
    계속감사년수가 한 해씩 늘었는지. 같은 이사인데 전기 3년 → 당기 3년이면 오류."""
    # 기수별로 여러 줄인 회사(분기·반기 결산) — 전기 마지막 기 → 당기 첫 기를 맞춘다(사용자 지정 2026-10-15)
    yrs = lambda r: _num(r.get("partner_years")) or 0  # noqa: E731
    prev: dict[str, dict[str, Any]] = {}
    for r in s23:
        if r["y"] == fy - 1 and (r["ckey"] not in prev or yrs(r) > yrs(prev[r["ckey"]])):
            prev[r["ckey"]] = r
    first: dict[str, dict[str, Any]] = {}
    for r in s23:
        if r["y"] == fy and (r["ckey"] not in first or yrs(r) < yrs(first[r["ckey"]])):
            first[r["ckey"]] = r
    for cur in first.values():
        p = prev.get(cur["ckey"])
        if not p:
            continue
        name = cur["name"]
        cy, py = _num(cur.get("partner_years")), _num(p.get("partner_years"))
        if cy is not None and py is not None and cur.get("partner") and p.get("partner"):
            if same_person(cur["partner"], p["partner"]):
                if cy != py + 1:
                    out.add("불일치", "years_step", "담당이사 계속감사년수가 전기에서 한 해 늘지 않음", name, fy,
                            f"{cur['partner']} 전기 {int(py)}년 → 당기 {int(cy)}년(같은 이사면 {int(py) + 1}년)", "", (p, cur))
                else:
                    out.good("years_step", "담당이사 계속감사년수(전기→당기)", name, fy, f"{int(py)} → {int(cy)}년", (p, cur))
            elif cy != 1:
                note = " — 비슷한 이름(같은 이사를 달리 적었는지 확인)" if similar_person(cur["partner"], p["partner"]) else ""
                out.add("불일치", "years_step", "담당이사가 바뀌었는데 계속감사년수가 1년이 아님", name, fy,
                        f"전기 {p['partner']} {int(py)}년 → 당기 {cur['partner']} {int(cy)}년{note}", "", (p, cur))
        cf, pf = _num(cur.get("firm_years")), _num(p.get("firm_years"))
        if cf is not None and pf is not None:
            if cf != pf + 1:
                out.add("불일치", "firm_years_step", "수임후 계속감사년수가 전기에서 한 해 늘지 않음", name, fy,
                        f"전기 {int(pf)}년 → 당기 {int(cf)}년({int(pf) + 1}년이어야)", "", (p, cur))
            else:
                out.good("firm_years_step", "수임후 계속감사년수(전기→당기)", name, fy, f"{int(pf)} → {int(cf)}년", (p, cur))


def _check_nonaudit(out: _Out, rec: dict[str, Any], fy: int) -> None:
    name = rec["name"]
    book = str(rec.get("bookkeeping") or "")
    fee, nas = _num(rec.get("audit_fee")), _num(rec.get("nonaudit_fee"))
    outside = bool(re.search(r"회계법인|세무|위탁|외부|대행|기장대리", book))
    first = "신규" in str(rec.get("new_audit") or "") or "최초" in str(rec.get("predecessor") or "")
    if nas and nas > 0:
        ratio = nas / fee if fee else None
        big = (ratio is not None and ratio >= 0.5) or nas >= 50
        pct = f"(감사보수의 {ratio * 100:.0f}%)" if ratio is not None else ""
        what = f"비감사보수 {nas:,.0f}백만원{pct}"
        if outside or big:
            if outside:
                how = f"기장 「{book}」 — 기장·전표처리 주체가 감사인(또는 소속 공인회계사)인지"
            elif "자체" in book:
                how = "자체기장 회사에 큰 비감사용역"
            else:
                how = f"기장 「{book}」 — 큰 비감사용역" if book else "큰 비감사용역(기장 방식 확인 필요)"
            out.add("중점확인", "nonaudit", "비감사용역 성격 확인(기장·회계처리 자문 금지)", name, fy,
                    f"{what} · {how} · 용역 계약서·감사의 동의·협의 문서 확인", BASIS["nonaudit"], (rec,))
        else:
            out.add("참고", "nonaudit", "비감사보수 있음", name, fy, what, BASIS["nonaudit"], (rec,))
    elif outside:
        level = "중점확인" if ("회계법인" in book or first) else "참고"
        note = " · 초도감사 회사 — 감사대상 회계기간에 감사인이 기장했다면 독립성 위반" if first else ""
        out.add(level, "bookkeeping", "외부 기장 — 기장 주체 확인", name, fy, f"기장 「{book}」{note}",
                BASIS["nonaudit"], (rec,))


# 감사대상회사에 해서는 안 되는 비감사용역 — 공인회계사법 제21조제2항·시행령 제14조(사용자 지정 2026-10-15)
_NAS_BANNED = re.compile(r"기장|회계\s*기록|장부|전표|결산\s*(대행|업무)|재무제표\s*(의\s*)?(작성|대리)|회계처리\s*대행|내부\s*감사\s*(업무)?\s*(대행|위탁|아웃소싱)"
                         r"|재무\s*정보\s*(체제|시스템)|회계\s*시스템\s*(구축|운영)|ERP\s*(구축|운영)|가치\s*평가|자산\s*평가|주식\s*평가|감정\s*평가"
                         r"|보험\s*계리|계리|투자\s*권유|중개|채용\s*대행|인사\s*관리", re.I)
_RELATED = re.compile(r"지배|종속|관계|계열|모회사|자회사|특수관계|연결")


# 비감사용역 묶음(사용자 지정 2026-10-15) — 회계법인마다 적는 말이 달라 묶어서 보인다. 위에서부터 처음 맞는 것.
_NAS_GROUPS = (
    ("기장", re.compile(r"기장|회계\s*기록|장부|전표|결산\s*(대행|지원|업무)|재무제표\s*(의\s*)?(작성|대리)|회계처리\s*대행|급여\s*대행")),
    ("세무조정", re.compile(r"세무\s*조정|세무\s*신고|법인세|부가세|부가가치세|소득세|원천세|지방세|세무\s*대리|조세|세무")),
    ("평가", re.compile(r"가치\s*평가|자산\s*평가|주식\s*평가|감정|평가\s*(업무|용역)|PPA|손상\s*검사", re.I)),
    ("검토·인증", re.compile(r"검토|인증|합의된\s*절차|AUP|확인\s*업무|내부회계|보증", re.I)),
    ("자문(컨설팅)", re.compile(r"자문|컨설팅|consult|실사|M\s*&\s*A|인수|합병|구조조정|경영|재무\s*진단|IPO|상장\s*준비|IFRS|교육", re.I)),
)


def nas_group(service: Any) -> str:
    t = str(service or "")
    for name, pat in _NAS_GROUPS:
        if pat.search(t):
            return name
    return "기타"


_UNIT_M = {"억원": 100.0, "백만원": 1.0, "천원": 0.001, "원": 0.000001}


def _fee_unit(meta: dict[str, Any] | None) -> str | None:
    """4-10 보수 단위 — 보수 열 머리의 「(원)」·「(천원)」 …, 없으면 시트의 「(단위: …)」"""
    meta = meta or {}
    roles = meta.get("roles") or {}
    letter = roles.get("fee") or roles.get("fee_any")
    label = next((c.get("label") or "" for c in meta.get("columns") or [] if c.get("letter") == letter), "")
    m = re.search(r"(억원|백만원|천원|원)", label)
    return m.group(1) if m else meta.get("unit")


def _nas_fee(v: Any, unit: str | None = None) -> float | None:
    """4-10 보수 → 백만원. 단위를 모르면 크기로 짐작(1천만 넘으면 원, 10만 넘으면 천원, 그 밖 백만원)."""
    n = _num(v)
    if n is None:
        return None
    if unit in _UNIT_M:
        return n * _UNIT_M[unit]
    if n >= 10_000_000:
        return n / 1_000_000
    if n >= 100_000:
        return n / 1_000
    return n


def _won(m: float) -> str:
    """백만원 금액 글 — 늘 「x.x백만원」(사용자 지정 2026-10-15). 0.05백만원 미만은 「0.1백만원 미만」."""
    if 0 < m < 0.05:
        return "0.1백만원 미만"
    return f"{m:,.1f}백만원"


def _check_410(out: _Out, s410: list[dict[str, Any]], cur23: list[dict[str, Any]], fy: int, label,
               meta: dict[str, Any] | None = None) -> None:
    """4-10 비감사서비스 수행내역 ↔ 2-3 당기 외감회사(사용자 지정 2026-10-15). 회계법인 제출분이라 완전하지 않을 수 있어
    매출장 대사 전에 이 파일 안에서 볼 수 있는 것만 — 감사대상회사에 비감사용역(금지 용역은 위반의심), 2-3 비감사보수와 다름,
    2-3 에 비감사보수가 있는데 4-10 에 없음. 한 회사의 여러 용역 줄은 한 건으로 묶는다."""
    unit = _fee_unit(meta)
    clients = {r["ckey"]: r for r in cur23}
    by_biz = {re.sub(r"\D", "", str(r.get("biz_no") or "")): r for r in cur23 if re.sub(r"\D", "", str(r.get("biz_no") or ""))}
    mine: dict[str, list[dict[str, Any]]] = defaultdict(list)          # 감사대상회사 → 4-10 줄들
    related: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)   # (용역 받은 회사, 관련 감사대상) → 줄들
    for rec in s410:
        if rec.get("year") not in (None, "") and rec["y"] != fy:
            continue                                   # 당기분만
        biz = re.sub(r"\D", "", str(rec.get("biz_no") or ""))
        m = clients.get(rec["ckey"]) or (by_biz.get(biz) if biz else None)
        if not m and rec.get("audit_client"):
            m = clients.get(company_key(rec["audit_client"]))
        if not m:
            if rec.get("relation") and _RELATED.search(str(rec["relation"])):
                related[(rec["name"], "")].append(rec)
            continue
        same_co = m["ckey"] == rec["ckey"] or (biz and biz == re.sub(r"\D", "", str(m.get("biz_no") or "")))
        if same_co:
            mine[m["ckey"]].append(rec)
        else:
            related[(rec["name"], m["name"])].append(rec)

    def fee_of(rec: dict[str, Any]) -> float | None:
        return _nas_fee(rec.get("fee") if rec.get("fee") not in (None, "") else rec.get("fee_any"), unit)

    def summary(rows: list[dict[str, Any]]) -> tuple[str, float]:
        services = list(dict.fromkeys(str(r.get("service") or "").strip() for r in rows if str(r.get("service") or "").strip()))
        fees = [f for f in (fee_of(r) for r in rows) if f is not None]
        total = sum(fees)
        parts = []
        if services:
            parts.append(f"용역 {len(rows)}건: " + ", ".join(f"「{x}」" for x in services[:5]) + (" 등" if len(services) > 5 else ""))
        if fees:
            parts.append(f"보수 {'합계 ' if len(fees) > 1 else ''}{_won(total)}" + (f"(4-10 단위 {unit})" if unit else ""))
        rel = list(dict.fromkeys(str(r.get("relation") or "") for r in rows if r.get("relation")))
        if rel:
            parts.append("관계 " + ", ".join(f"「{x}」" for x in rel))
        return " · ".join(parts) or "용역 내용 없음", total

    # 세무조정(법인세·세무상담 …)도 싣되 화면은 대표 3개사·「외 N개사」로만(사용자 지정 2026-10-15)
    for key, rows_all in mine.items():
        m = clients[key]
        rows = rows_all
        what, total = summary(rows)
        banned = [str(r.get("service")) for r in rows if r.get("service") and _NAS_BANNED.search(str(r["service"]))]
        # 화면이 용역 내용별로 묶어 「세무조정 : A(1.2백만원), B(총 4.5백만원)」으로 보이게(사용자 지정 2026-10-15)
        by_service: dict[str, list[tuple[str, float | None]]] = defaultdict(list)
        for r in rows:
            sv = str(r.get("service") or "").strip()
            by_service[nas_group(sv)].append((sv, fee_of(r)))
        nas_list = [{"group": k, "services": list(dict.fromkeys(x for x, _ in v if x)), "rows": len(v),
                     "fee": round(sum(f for _, f in v if f is not None), 4) if any(f is not None for _, f in v) else None}
                    for k, v in by_service.items()]
        if banned:
            out.add("위반의심", "nas_banned", "감사대상회사에 금지 비감사용역", m["name"], fy,
                    f"{what} — 「{banned[0]}」 은(는) 감사대상회사에 할 수 없는 용역인지 확인", BASIS["nas_banned"], (m, *rows[:5]))
        else:
            out.add("중점확인", "nas_client", "감사대상회사에 비감사용역", m["name"], fy,
                    f"{what} — 용역 성격·독립성 검토·감사위원회 사전 승인 확인", BASIS["nonaudit"], (m, *rows[:5]))
        out.items[-1]["nas"] = nas_list
        if not any(fee_of(r) is not None for r in rows):
            continue
        nas = _num(m.get("nonaudit_fee"))
        if nas is None or nas == 0:
            out.add("불일치", "nas_fee", "4-10 에 비감사용역이 있는데 2-3 비감사보수가 없음", m["name"], fy,
                    f"4-10 보수 합계 {_won(total)} ↔ 2-3 비감사보수 「{m.get('nonaudit_fee') or ''}」", "", (m,))
        elif abs(nas - total) > max(1, nas * 0.05):
            out.add("불일치", "nas_fee", "비감사보수 다름(2-3 ↔ 4-10)", m["name"], fy,
                    f"2-3 {_won(nas)} ↔ 4-10 합계 {_won(total)}", "", (m,))
        else:
            out.good("nas_fee", "비감사보수(2-3 ↔ 4-10)", m["name"], fy, _won(nas), (m,))
    for (name, client), rows in related.items():
        what, _ = summary(rows)
        out.add("중점확인", "nas_related", "감사대상회사의 지배·종속(관계)회사에 비감사용역", f"{name} ↔ {client}" if client else name, fy,
                f"{what}" + (f" — 관련 감사대상회사 {client}" if client else " — 감사대상회사와의 관계·독립성 검토 확인"),
                BASIS["nas_banned"], tuple(rows[:5]))
    for m in cur23:
        nas = _num(m.get("nonaudit_fee"))
        if nas and nas > 0 and m["ckey"] not in mine:
            out.add("불일치", "nas_missing", "2-3 에 비감사보수가 있는데 4-10 에 없음", m["name"], fy,
                    f"2-3 비감사보수 {_won(nas)} — 4-10 누락인지 확인", BASIS["nonaudit"], (m,))


def _check_83(out: _Out, s83: list[dict[str, Any]], by23: dict, fy: int, label) -> None:
    """8-3 사후심리 실시내역 — 사후심리자가 2-3 의 (사전) 심리자와 같으면 개선 필요(사용자 지정 2026-10-15).
    8-3 에 사업연도가 있으면 그 해의 2-3 줄과, 없으면 당기 → 전기 순으로 맞춘다."""
    for rec in s83:
        who = rec.get("post_reviewer")
        if not _is_name(who):
            continue
        years = [rec["y"]] if rec.get("year") not in (None, "") else [fy, fy - 1]
        for y in years:
            m = by23.get((rec["ckey"], y))
            if not m:
                continue
            pre = [v for v in (m.get("reviewer"), m.get("con_reviewer")) if _is_name(v)]
            if any(same_person(who, v) for v in pre):
                out.add("중점확인", "post_review_same", "사전 심리자가 사후심리도 함", label(rec), y,
                        f"2-3 심리 {', '.join(map(str, pre))} ↔ 8-3 사후심리 {who} — 같은 사람(사후심리는 다른 사람이 해야 함)",
                        BASIS["post_review"], (m, rec))
            elif pre:
                out.good("post_review_same", "사전·사후 심리자 다름", label(rec), y, f"사전 {pre[0]} · 사후 {who}", (m, rec))
            break


def _check_people(out: _Out, cur23: list[dict[str, Any]]) -> None:
    # 교차심리: A 회사를 B 가 심리하는데, B 가 담당하는 회사를 A 가 심리 — 한 건이라도 안 된다.
    # 사이에 다른 사람이 낀 고리(A→B→C→A)는 보지 않는다(사용자 지정 2026-10-14). 연결 심리도 센다.
    reviewed: dict[str, list[tuple[dict[str, Any], str]]] = defaultdict(list)   # 담당이사 → (회사, 심리자)
    for rec in cur23:
        p = rec.get("partner")
        # 연결 심리담당자 칸은 연결 회사(연결 체크 + 종속회사 ≥1, 종속회사 열이 없으면 연결 체크만)일 때만 본다 —
        # 연결을 안 하는 회사에 담당이사 이름을 적어 둔 파일이 있어 「자기심리」로 잘못 잡혔다(사용자 질문 2026-10-15).
        subs = _num(rec.get("subsidiaries"))
        is_con = _yes(rec.get("consolidated")) is True and (subs is None or subs > 0)
        for role in ("reviewer", "con_reviewer"):
            r = rec.get(role)
            if not (p and r) or (role == "con_reviewer" and not is_con):
                continue
            if same_person(p, r):
                out.add("위반의심", "self_review", "담당이사가 자기 회사를 심리", rec["name"], rec["y"],
                        f"담당이사·{'연결 ' if role == 'con_reviewer' else ''}심리담당자 모두 「{p}」", BASIS["cross"], (rec,))
            else:
                reviewed[person_key(p)].append((rec, str(r)))
    done = set()
    for a_key, rows in reviewed.items():
        for rec_a, b_name in rows:                      # A 회사 → 심리자 B
            b_key = person_key(b_name)
            for rec_b, back in reviewed.get(b_key, []):  # B 회사 → 심리자 A ?
                if person_key(back) != a_key:
                    continue
                pair = frozenset((a_key, b_key))
                if pair in done:
                    continue
                done.add(pair)
                a_name = rec_a.get("partner")
                mine = [x["name"] for x, r in rows if person_key(r) == b_key]
                theirs = [x["name"] for x, r in reviewed[b_key] if person_key(r) == a_key]
                out.add("위반의심", "cross_review", "담당이사 상호 교차심리(1건이라도 금지)",
                        f"{a_name} ↔ {b_name}", rec_a["y"],
                        f"「{a_name}」 담당 {', '.join(mine)} 을(를) 「{b_name}」 가 심리 · "
                        f"「{b_name}」 담당 {', '.join(theirs)} 을(를) 「{a_name}」 가 심리", BASIS["cross"], (rec_a, rec_b))
                # 화면이 「김승용(A, B) ↔ 신용직(갑)」으로 회사까지 보이게(사용자 지정 2026-10-15)
                out.items[-1]["pair"] = [{"partner": str(a_name), "companies": list(dict.fromkeys(mine))},
                                         {"partner": str(b_name), "companies": list(dict.fromkeys(theirs))}]

    per = Counter(person_key(r.get("partner")) for r in cur23 if r.get("partner"))
    shown = {person_key(r.get("partner")): r.get("partner") for r in cur23 if r.get("partner")}
    for k, n in per.items():
        if n >= 15:
            out.add("참고", "overload", "담당이사 과다수임(15개 이상)", f"담당이사 {shown[k]}", None,
                    f"당기 {n}개사", BASIS["hours"])
    hours = defaultdict(list)
    for rec in cur23:
        h = _num(rec.get("total_hours"))
        if h and h > 0:
            hours[h].append(rec["name"])
    for h, names in hours.items():
        if len(names) >= 3:
            out.add("참고", "same_hours", "감사시간이 같은 회사가 여럿", f"{len(names)}개사", None,
                    f"총시간 {h:,.0f}시간 — " + ", ".join(names[:8]) + (" …" if len(names) > 8 else ""), BASIS["hours"])
    if len({r["ckey"] for r in cur23}) >= 100:
        out.add("참고", "qc_staff", "외감 대상 100개 이상 — 품질관리전담자 지정 대상", "회계법인", None,
                f"당기 {len({r['ckey'] for r in cur23})}개사", BASIS["qc_staff"])


_NEG = {"x", "×", "✗", "미흡", "n", "no", "아니오", "아니요", "부", "미실시", "미이행"}


def _check_28(out: _Out, s28, by23, any23, label, fy: int) -> None:
    for rec in s28:
        name, y = label(rec), rec["y"]
        if y != fy:
            continue        # 주요 비교 대상은 당기분(사용자 지정 2026-10-15)
        m = by23.get((rec["ckey"], y))
        if not m:
            if rec["ckey"] not in any23:
                out.add("참고", "unmatched", "2-8 에만 있는 회사(2-3 현황에 없음)", rec["name"], y,
                        "회사명 표기·사업연도 확인", "", (rec,))
            else:
                out.add("참고", "unmatched", "2-3 에 같은 사업연도 줄이 없음", name, y, "사업연도 확인", "", (rec,))
        rd28, rd23 = parse_date(rec.get("report_date")), parse_date((m or {}).get("report_date"))
        if rd28 and rd23:
            if rd28 != rd23:
                out.add("불일치", "report_date", "감사보고서일 다름", name, y,
                        f"2-3 {_fmt(rd23)} ↔ 2-8 {_fmt(rd28)}", "", (m, rec))
            else:
                out.good("report_date", "감사보고서일", name, y, _fmt(rd28), (m, rec))
        base = rd28 or rd23
        cd28 = parse_date(rec.get("collect_date"))
        cd23 = collect_done(m, "archive", "warehouse") if m else None
        # 60일 판정은 2-3 의 조서 취합완료일로 한 번만(_check_23). 2-3 에 archive·입고일이 없을 때만 2-8 취합완료일로 본다.
        cd, cbase = (cd23, rd23 or base) if cd23 else (cd28, base)
        if cd and cbase:
            days = (cd - cbase).days
            if days > SUBMIT_DAYS:
                if not cd23:
                    out.add("위반의심", "archive_60", "조서 취합완료 60일 초과", name, y,
                            f"조서 취합완료일 {_fmt(cd)}(2-3 에 archive·입고일이 없어 2-8 취합완료일) · 감사보고서일 {_fmt(cbase)} 후 {days}일",
                            BASIS["archive"], (rec,))
                if _yes(rec.get("timely")) is True or str(rec.get("timely") or "").strip() in ("✔", "✓", "V", "v", "O", "○"):
                    out.add("불일치", "timely_mark", "자체점검 「적시취합」 표시와 맞지 않음", name, y,
                            f"「적시취합」 {rec.get('timely')} 인데 {days}일", BASIS["archive"], (rec,))
            elif not cd23:
                out.good("archive_60", "조서 취합완료 60일 이내 — 2-8", name, y, f"{days}일", (rec,))
        if cd28 and cd23:
            if cd28 == cd23:
                out.good("collect_date", "조서 취합완료일", name, y, _fmt(cd28), (m, rec))
            else:
                out.add("불일치", "collect_date", "조서 취합완료일 다름", name, y,
                        f"2-8 {_fmt(cd28)} ↔ 2-3 {_fmt(cd23)}(archive·입고일 중 빠른 날)", "", (m, rec))
        rv28 = rec.get("reviewer")
        rv23 = [v for v in ((m or {}).get("reviewer"), (m or {}).get("con_reviewer")) if v]
        if rv28 and rv23:
            if any(same_person(rv28, v) for v in rv23):
                out.good("reviewer", "심리(검토)담당자", name, y, str(rv28), (m, rec))
            else:
                near = " — 비슷한 이름(표기 차이인지 확인)" if any(similar_person(rv28, v) for v in rv23) else ""
                out.add("불일치", "reviewer", "심리(검토)담당자 다름", name, y,
                        f"2-3 {' / '.join(map(str, rv23))} ↔ 2-8 {rv28}{near}", "", (m, rec))
        bad = []
        for role, what in (("timely", "적시취합"), ("existence", "실재성"), ("completeness", "완전성"),
                           ("physical", "물리적통제"), ("access", "접근기록유지")):
            v = re.sub(r"\s+", "", str(rec.get(role) or "")).lower()
            if v in _NEG:
                bad.append(f"{what} 「{rec.get(role)}」")
        if bad:
            out.add("중점확인", "selfcheck", "감사조서 자체점검 미흡 표시", name, y, " · ".join(bad), "", (rec,))


_NOT_NAME = re.compile(r"^(-+|○|◯|●|o|x|×|n/?a|#n/?a|해당\s*없음|없음|미수임|미선임|공란|\.|/|―|—)$", re.I)


def _is_name(v: Any) -> bool:
    """2-10 연도 칸의 값이 사람 이름인가 — 「-」·「○」·「N/A」·「미수임」 같은 표시를 이름으로 세면
    같은 「사람」이 여러 해 이어진 것으로 잡혔다(사용자 지적 2026-10-15: 연속감사 한도 초과가 너무 많음)."""
    t = str(v or "").strip()
    return bool(t) and not _NOT_NAME.match(t) and bool(re.search(r"[가-힣A-Za-z]{2,}", t))


def _check_210(out: _Out, s210, by23, any23, cur23, fy, label, pinfo=None) -> None:
    pinfo = pinfo or {}
    seen210 = set()
    for rec in s210:
        seen210.add(rec["ckey"])
        name = label(rec)
        seq: dict[int, str] = {}
        raw: dict[int, str] = {}
        for k, v in rec.items():
            if k.startswith("fy:") and _is_name(v):
                seq[int(k[3:])] = str(v).strip()
                raw[int(k[3:])] = str(v).strip()
        m_cur, m_prev = by23.get((rec["ckey"], fy)), by23.get((rec["ckey"], fy - 1))
        if rec["ckey"] not in any23:
            out.add("참고", "unmatched", "2-10 에만 있는 회사(2-3 현황에 없음)", rec["name"], None,
                    "회사명 표기 확인", "", (rec,))

        # 2-3 의 당기·전기 담당이사와 같은가
        for m, y in ((m_cur, fy), (m_prev, fy - 1)):
            p23 = (m or {}).get("partner")
            if not p23:
                continue
            p210 = seq.get(y)
            if not p210:
                seq[y] = str(p23).strip()
                continue
            if same_person(p23, p210):
                out.good("partner_name", "담당이사", name, y, str(p23), (m, rec))
            else:
                near = " — 비슷한 이름(같은 사람을 달리 적었는지 확인)" if similar_person(p23, p210) else ""
                out.add("불일치", "partner_name", "담당이사 이름 다름", name, y,
                        f"2-3 {p23} ↔ 2-10 FY{y} {p210}{near}", "", (m, rec))

        limit, since, why = _limit(m_cur or any23.get(rec["ckey"]), rec, (m_prev or {}).get("assets"))
        pi = pinfo.get(rec["ckey"]) or {}
        k = pi.get("k") or per_year((m_cur or any23.get(rec["ckey"]) or {}).get("fiscal"))
        last = pi.get("last") if pi.get("multi") else None          # 기수별 여러 줄 — 계속감사년수가 기수
        last_n = _num((last or {}).get("partner_years"))
        counted = {y: n for y, n in seq.items() if since is None or y >= since}
        strict = _runs(counted, same_person)
        fuzzy = _runs(counted, _close)
        worst = max(strict, key=lambda r: r[1] - r[0], default=None)
        flagged = False

        def periods_of(run: tuple[int, int, list[str]]) -> tuple[int, bool]:
            """그 연속 구간의 사업연도(기수) 수와 정확한지. 당기를 품은 구간이고 2-3 에 기수로 적힌 계속감사년수가 있으면 그것
            (+ 당기 뒤에 적어 둔 해 × 연 결산 횟수), 아니면 해 × 연 결산 횟수 — 첫·끝 해가 일부 기간이면 많게 셀 수 있다."""
            s0, e0, names = run
            if last_n and s0 <= fy <= e0 and same_person(names[-1], (last or {}).get("partner")):
                return int(last_n) + max(0, e0 - fy) * k, True
            return (e0 - s0 + 1) * k, k == 1

        if worst and periods_of(worst)[0] > limit:
            n = worst[1] - worst[0] + 1
            per, exact_n = periods_of(worst)
            spell = sorted({raw.get(y, seq[y]) for y in range(worst[0], worst[1] + 1)})
            note = f" · 표기를 달리 적은 해가 있음({', '.join(spell)}) — 회피 의도 여부 확인" if len(spell) > 1 else ""
            how = (_periods(n, k) if k == 1 else f"{per}개 사업연도") + (
                "" if exact_n else f"(연 {k}회 결산 × {n}년으로 셈 — 첫·끝 해가 일부 기간이면 적을 수 있어 기수로 확인)")
            out.add("위반의심" if exact_n else "중점확인", "partner_rotation", f"동일 이사 연속감사 한도({limit}개 사업연도) 초과", name, fy,
                    f"{worst[2][0]} FY{worst[0]}~FY{worst[1]} {how} 연속 · {why}{note}", BASIS["rotation"], (rec,))
            flagged = True
        # 상장·대형비상장: 한도까지 연속 감사한 이사는 그 다음 연속 3개 사업연도에 다시 맡을 수 없다 — 당기에 돌아왔으면 위반의심
        cool = _cooling(why)
        if cool and not flagged:
            gap = -(-cool // k)                       # 3개 사업연도를 해로(반기 결산이면 2년)
            for s0, e0, names in strict:
                if (e0 - s0 + 1) * k < limit or not (e0 < fy <= e0 + gap):
                    continue
                if fy in counted and same_person(counted[fy], names[0]):
                    out.add("위반의심", "partner_cooling", f"연속 {limit}개 사업연도 감사 뒤 {cool}개 사업연도 안에 같은 이사 재투입",
                            name, fy, f"{names[0]} FY{s0}~FY{e0} {_periods(e0 - s0 + 1, k)} 연속 → FY{fy} 다시 담당 "
                            f"(FY{e0 + 1}~FY{e0 + gap} 투입 금지) · {why}", BASIS["rotation"], (rec,))
                    flagged = True
        for s, e, names in fuzzy:
            n = e - s + 1
            if flagged or len({person_key(x) for x in names}) < 2 or n * k <= limit:
                continue
            out.add("중점확인", "partner_alias", "이름을 달리 적어 연속감사가 끊겨 보임", name, fy,
                    f"{' → '.join(dict.fromkeys(names))} FY{s}~FY{e} — 같은 이사로 보면 {_periods(n, k)} 연속(한도 {limit}, {why})",
                    BASIS["rotation"], (rec,))
            flagged = True

        # 2-3 의 「담당이사 계속감사년수」와 2-10 이 맞는가
        m_last = last or m_cur
        p23 = (m_last or {}).get("partner")
        stated = _num((m_last or {}).get("partner_years"))
        if p23 and stated is not None and last:
            # 기수로 적은 계속감사년수 — 2-10 의 해 수로는 범위만 맞춘다((해-1)×k+1 ~ 해×k)
            exact = _back(counted, fy, p23, same_person)
            if exact and not ((exact - 1) * k + 1 <= stated <= exact * k):
                out.add("불일치", "partner_years_diff", "담당이사 계속감사년수 다름", name, fy,
                        f"2-3 {int(stated)}개 사업연도(연 {k}회 결산) ↔ 2-10 {exact}년 연속이면 {(exact - 1) * k + 1}~{exact * k}개", "", (m_last, rec))
            elif exact:
                out.good("partner_years_diff", "담당이사 계속감사년수", name, fy, f"{int(stated)}개 사업연도 · 2-10 {exact}년", (m_last, rec))
            if not flagged and stated == limit:
                after = f"다음 연속 {cool}개 사업연도에는 이 이사 투입 불가" if cool else "다음 사업연도에는 교체 필요"
                out.add("참고", "partner_6", f"당기로 연속감사 한도({limit}개 사업연도)에 닿음", name, fy,
                        f"{p23} {int(stated)}개 사업연도 — {after} · {why}", BASIS["rotation"], (rec,))
            elif not flagged:
                out.good("partner_rotation", "연속감사 한도", name, fy, f"{p23} {int(stated)}/{limit}개 사업연도", (rec,))
        elif p23 and stated is not None:
            exact, near = _back(counted, fy, p23, same_person), _back(counted, fy, p23, _close)
            if not flagged and near > stated and near != exact:
                out.add("중점확인", "partner_alias", "비슷한 이름까지 치면 계속감사년수가 더 김", name, fy,
                        f"2-3 계속감사년수 {int(stated)}년 ↔ 2-10 같은·비슷한 이름 {near}년 연속(같은 이름만 {exact}년)",
                        BASIS["rotation"], (m_cur, rec))
            elif exact and near == exact and exact != stated:
                out.add("불일치", "partner_years_diff", "담당이사 계속감사년수 다름", name, fy,
                        f"2-3 {int(stated)}년 ↔ 2-10 {exact}년 연속", "", (m_cur, rec))
            elif exact == stated:
                out.good("partner_years_diff", "담당이사 계속감사년수", name, fy, f"{exact}년", (m_cur, rec))
            run_now = _back(counted, fy, p23, same_person)
            if not flagged and run_now * k == limit:
                after = f"다음 연속 {cool}개 사업연도에는 이 이사 투입 불가" if cool else "다음 사업연도에는 교체 필요"
                out.add("참고", "partner_6", f"당기로 연속감사 한도({limit}개 사업연도)에 닿음", name, fy,
                        f"{p23} {_periods(run_now, k)} — {after} · {why}", BASIS["rotation"], (rec,))
            elif not flagged and run_now:
                out.good("partner_rotation", "연속감사 한도", name, fy, f"{p23} {run_now * k}/{limit}개 사업연도", (rec,))

    for rec in cur23:
        if rec["ckey"] not in seen210:
            out.add("참고", "missing_210", "2-10 담당이사 교체현황에 없는 회사", rec["name"], fy,
                    "교체현황 누락 여부 확인", "", (rec,))


def _opinion(v: Any) -> str | None:
    s = re.sub(r"\s+", "", str(v or ""))
    if not s:
        return None
    for word, norm in (("거절", "의견거절"), ("부적정", "부적정"), ("한정", "한정"), ("적정", "적정")):
        if word in s:
            return norm
    return s


def _check_docs(out: _Out, docs: list[dict[str, Any]], s23: list[dict[str, Any]], fy: int) -> None:
    for doc in docs:
        f = doc.get("facts") or {}
        fname = doc.get("name") or "문서"
        if f.get("type") != "감사보고서":
            continue
        if not doc.get("company"):
            out.items.append({"level": "참고", "code": "doc_unmatched", "title": "감사보고서 — 2-3 현황 회사와 이어지지 않음",
                              "company": fname, "year": None, "detail": "본문에서 2-3 의 회사명을 찾지 못함", "basis": "",
                              "refs": [fname]})
            continue
        key = company_key(doc["company"])
        recs = [r for r in s23 if r["ckey"] == key]
        rd = parse_date(f.get("report_date"))
        m = next((r for r in recs if rd and parse_date(r.get("report_date")) and
                  parse_date(r.get("report_date")).year == rd.year), None) or next((r for r in recs if r["y"] == fy), None)
        if not m:
            continue
        name, y, refs = m["name"], m["y"], [_where(m), fname]

        def put(code: str, title: str, mine: Any, theirs: Any, same: bool, note: str = "") -> None:
            if same:
                out.ok.append({"level": "일치", "code": code, "title": title, "company": name, "year": y,
                               "detail": str(theirs), "refs": refs})
            else:
                out.items.append({"level": "불일치", "code": code, "title": title, "company": name, "year": y,
                                  "detail": f"2-3 {mine or '-'} ↔ 감사보고서 {theirs}{note}", "basis": "", "refs": refs})

        rd23 = parse_date(m.get("report_date"))
        if rd and rd23:
            put("doc_report_date", "감사보고서일(감사보고서 원문)", _fmt(rd23), _fmt(rd), rd == rd23)
        op_doc, op23 = f.get("opinion"), _opinion(m.get("opinion"))
        if op_doc and op23:
            put("doc_opinion", "감사의견(감사보고서 원문)", op23, op_doc, op_doc == op23)
        p_doc, p23 = f.get("partner"), m.get("partner")
        if p_doc and p23:
            near = " — 비슷한 이름" if similar_person(p_doc, p23) else ""
            put("doc_partner", "업무수행이사(감사보고서 원문)", p23, p_doc, same_person(p_doc, p23), near)
