"""GitHub(정적) 사이트 전용 — 옛 한글(.hwp) 변환기(rhwp CLI)는 서버에만 있다."""
from contextlib import contextmanager
from pathlib import Path


class RhwpError(RuntimeError):
    pass


@contextmanager
def workspace():
    p = Path("/tmp/rhwp"); p.mkdir(parents=True, exist_ok=True)
    yield p


async def export_text(doc):
    raise RhwpError("옛 한글(.hwp)은 이 사이트에서 읽지 못합니다 — 한글에서 hwpx 로 저장해 올리거나 개발서버 화면을 쓰세요.")
