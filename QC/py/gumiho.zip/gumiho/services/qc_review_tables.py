"""[품감] 통합(개발) 제출자료 대사 — 점검 항목을 「표」로 묶는다 (2026-11-12, 사용자 지정).

`/qc-sample/review` 의 항목(`items` 불일치·중점확인·위반의심, `ok` 일치)을 항목(구분·이름)별 표로 만든다.
화면(js/qc_sample.js)과 엑셀(services/qc_review_xlsx.py)이 **같은 표**를 그린다.

  pivot  — 첨부 자료와 2-3 을 견준 값(`qc_sample_other`): 열 = 사전제출자료 2-3 · 각 첨부 자료(감사시간집계표·감사보고서 …) · 차이
  pair   — 「A ↔ B」 한 줄 꼴(자체조서점검·감사보고서일 등): 열 = A · B · 차이
  list   — 그 밖의 것: 회사 · 사업연도 · 내용 · 위치

여러 줄에 되풀이되던 긴 파일 이름은 번호(①②…)로 줄이고, 번호 ↔ 파일은 `sources` 에 한 번만 둔다(같은 자료는 위에 한 번).
자료를 서버에 남기지 않는다 — 넘겨 받은 항목을 가공해 돌려줄 뿐이다.
"""
from __future__ import annotations

import re
from typing import Any

_CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳㉑㉒㉓㉔㉕㉖㉗㉘㉙㉚㉛㉜㉝㉞㉟㊱㊲㊳㊴㊵"
MINE = "사전제출자료 2-3"


def _circled(i: int) -> str:
    return _CIRCLED[i] if i < len(_CIRCLED) else f"({i + 1})"


def alias_map(files: list[dict[str, Any]]) -> dict[str, str]:
    """파일 이름 → 번호(올린 순서, 같은 이름은 한 번)."""
    out: dict[str, str] = {}
    for f in files or []:
        n = str(f.get("name") or "")
        if n and n not in out:
            out[n] = _circled(len(out))
    return out


def short_ref(text: str, alias: dict[str, str]) -> str:
    """위치 글 줄이기 — 파일 이름은 번호로, 「2-3. 외감회사 8행」은 「2-3 8행」으로."""
    s = str(text or "")
    for name, a in sorted(alias.items(), key=lambda kv: -len(kv[0])):
        s = s.replace(name, a)
    s = s.replace(" › ", "·")
    return re.sub(r"^(\d+-\d+)\.?\s*\S+?\s+(\d+행)$", r"\1 \2", s.strip())


def _split_src(src: str) -> tuple[str, str]:
    f, _, sheet = str(src or "").partition(" › ")
    return f, sheet


_DATE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_NUM = re.compile(r"^\s*(-?[\d,]+(?:\.\d+)?)")


def _pair_diff(a: str, b: str) -> str:
    """「2026-03-29」↔「2026-03-27」 → 「-2일」, 「14.0백만원」↔「15.5백만원」 → 「+1.5」. 못 견주면 빈 글."""
    import datetime as dt
    da, db = _DATE.fullmatch(a.strip()), _DATE.fullmatch(b.strip())
    if da and db:
        try:
            d = (dt.date(*map(int, db.groups())) - dt.date(*map(int, da.groups()))).days
        except ValueError:
            return ""
        return f"{d:+d}일" if d else ""
    na, nb = _NUM.match(a), _NUM.match(b)
    if na and nb:
        try:
            x, y = float(na.group(1).replace(",", "")), float(nb.group(1).replace(",", ""))
        except ValueError:
            return ""
        d = y - x
        return (f"{d:+,.0f}" if float(d).is_integer() else f"{d:+,.1f}") if d else ""
    return ""


def _label_value(side: str) -> tuple[str, str]:
    """「2-8 자체조서점검 2026-03-27」 → (「2-8 자체조서점검」, 「2026-03-27」) — 마지막 낱말을 값으로."""
    t = side.strip()
    if " " not in t:
        return "", t
    head, _, last = t.rpartition(" ")
    return head, last


def build(items: list[dict[str, Any]], ok: list[dict[str, Any]], files: list[dict[str, Any]], grade: dict[str, str]) -> dict[str, Any]:
    alias = alias_map(files)
    sources = [{"id": a, "name": n, **{k: f.get(k) for k in ("side", "role", "kind") if f.get(k)}}
               for n, a in alias.items() for f in [next((x for x in files if x.get("name") == n), {})]]

    def kind_of(i: dict[str, Any]) -> str:
        if i.get("field") and i.get("src") and "theirs" in i:
            return "pivot"
        if len(re.split(r"\s↔\s", str(i.get("detail") or ""))) == 2 and not i.get("pair"):
            return "pair"
        return "list"

    order: list[tuple[str, str, str]] = []                  # 같은 이름이어도 표 꼴이 다르면 따로(자료 대사 값 / 2-3 안의 시트끼리 값)
    by: dict[tuple[str, str, str], list[int]] = {}
    for idx, i in enumerate(items):
        k = (str(i.get("level") or ""), str(i.get("title") or ""), kind_of(i))
        if k not in by:
            by[k] = []
            order.append(k)
        by[k].append(idx)

    ok_by: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for o in ok:
        if o.get("src"):
            ok_by.setdefault((str(o.get("code")), str(o.get("company")), str(o.get("year"))), []).append(o)

    groups: list[dict[str, Any]] = []
    for level, title, kind in order:
        idxs = by[(level, title, kind)]
        rows = [items[k] for k in idxs]
        g: dict[str, Any] = {"level": level, "grade": grade.get(level, "하"), "title": title, "count": len(rows), "idx": idxs,
                             "basis": next((r.get("basis") for r in rows if r.get("basis")), "")}
        if kind == "pivot":
            g["kind"] = "pivot"
            cols: list[str] = []
            table: dict[tuple[str, str], dict[str, Any]] = {}
            for r in rows:
                key = (str(r.get("company")), str(r.get("year") or ""))
                row = table.setdefault(key, {"company": key[0], "year": key[1], "mine": r.get("mine"), "cells": {}, "diffs": [], "refs": []})
                if r["src"] not in cols:
                    cols.append(r["src"])
                row["cells"].setdefault(r["src"], []).append({"v": r.get("theirs"), "bad": True})
                row["diffs"].append(r.get("diff") or "다름")
                row["refs"] += [short_ref(x, alias) for x in r.get("refs") or [] if x not in row["refs"]]
            for key, row in table.items():             # 같은 항목에서 일치한 다른 자료 값도 함께(어느 자료는 맞고 어느 자료는 다른지)
                for o in ok_by.get((str(rows[0].get("code")), key[0], key[1]), []):
                    if o["src"] not in cols:
                        cols.append(o["src"])
                    row["cells"].setdefault(o["src"], []).append({"v": o.get("theirs"), "bad": False})
                    for x in o.get("refs") or []:
                        sx = short_ref(x, alias)
                        if sx not in row["refs"]:
                            row["refs"].append(sx)
            g["cols"] = [{"src": c, "id": alias.get(_split_src(c)[0], ""), "file": _split_src(c)[0], "sheet": _split_src(c)[1]} for c in cols]
            g["mine_label"] = MINE
            g["rows"] = [{"company": r["company"], "year": r["year"], "mine": r["mine"],
                          "cells": [r["cells"].get(c) or [] for c in cols],
                          "diff": " · ".join(dict.fromkeys(r["diffs"])), "ref": ", ".join(r["refs"])}
                         for r in table.values()]
        elif kind == "pair":
            g["kind"] = "pair"
            split = [[x.strip() for x in re.split(r"\s↔\s", str(r.get("detail")))] for r in rows]
            lv = [_label_value(a) for a, _ in split]
            rv = [_label_value(b) for _, b in split]
            lab_l = {x[0] for x in lv}
            lab_r = {x[0] for x in rv}
            same_l, same_r = len(lab_l) == 1 and "" not in lab_l, len(lab_r) == 1 and "" not in lab_r
            g["left_label"] = next(iter(lab_l)) if same_l else "자료 A"
            g["right_label"] = next(iter(lab_r)) if same_r else "자료 B"
            g["rows"] = []
            for r, (a, b), (la, va), (lb, vb) in zip(rows, split, lv, rv):
                va_, vb_ = (va if same_l else a), (vb if same_r else b)
                g["rows"].append({"company": r.get("company"), "year": r.get("year") or "", "left": va_, "right": vb_,
                                  "diff": _pair_diff(va, vb) or "다름",
                                  "ref": ", ".join(short_ref(x, alias) for x in r.get("refs") or [])})
        else:
            g["kind"] = "list"
            g["rows"] = [{**r, "ref": ", ".join(short_ref(x, alias) for x in r.get("refs") or [])} for r in rows]
        groups.append(g)
    return {"sources": sources, "groups": groups}
