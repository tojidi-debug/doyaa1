"""게시판 첨부(PDF·HWPX·옛 HWP) → 지적사례 본문 절.

심사·감리지적사례는 **첨부가 본문이다.** KICPA 게시판의 「내용」 칸은 전 건이
「첨부파일 참조 바랍니다」 한 줄이고(실측), FSS 게시판에는 본문 칸 자체가 없다.
그래서 이 파일이 없으면 `review_board` 는 제목과 메타만 긁어 온다.

## 갈래는 확장자가 아니라 매직바이트로 정한다

게시판 링크(`fileDown.do`·`fileMngr`)는 확장자를 주지 않고, `Content-Type` 은
둘 다 `application/octet-stream` 이다. 파일 이름도 못 믿는다 — `.hwp` 라고
적혀 있는데 실제로는 HWPX(zip)인 것이 섞여 있다.

    %PDF            → pdftotext
    PK\x03\x04      → HWPX (zip)
    \xd0\xcf\x11\xe0 → 옛 HWP (OLE/CFBF)

형식은 연도를 탄다(2026-09-14 실측, 36건 표본):
FSS 는 2021년까지 옛 HWP · 2022년부터 PDF, KICPA 는 2023년까지 옛 HWP ·
2024년부터 HWPX. **옛 HWP 가 전체의 4할이 넘는다** — 예전 수집이 이것을 못 열어
FSS 2019~2021년 105건의 본문이 통째로 비어 있다.

## 세 갈래가 서로 다른 도구인 이유 (실측으로 고른 것)

| 형식 | 도구 | 왜 |
|---|---|---|
| PDF | `pdftotext -layout` | `pypdf` 는 공백·줄바꿈을 뭉개 절 경계가 사라진다 |
| HWPX | `Contents/section0.xml` | 문단 단위라 **지금 DB 와 글자까지 같다**(217=217) |
| 옛 HWP | `rhwp export-text` | zip 이 아니라 푸는 길이 이것뿐이다 |

HWPX 를 `rhwp` 로 열 수도 있지만 그러지 않는다. `rhwp` 는 **눈에 보이는 줄**을
그대로 준다(문단 가운데서 줄이 끊긴다). 문단 단위인 `section0.xml` 쪽이 지금
DB 에 들어 있는 KICPA 본문과 **글자까지 일치**했다(실측: rhwp 221자 vs
section0.xml 217자 = DB 217자).

옛 HWP 는 `rhwp` 말고 길이 없으므로 줄이 끊긴 채로 온다. 그래서 아래
`_unwrap()` 이 **문단 안의 줄바꿈만** 되붙인다 — 빈 줄(문단 경계)은 남긴다.
화면(`css/review_case.css:803` `white-space: pre-wrap`)이 줄바꿈을 그대로
그리므로, 되붙이지 않으면 좁은 화면에서 줄이 들쭉날쭉해진다.

## 절 이름으로 끊는다 — 번호로 끊으면 안 된다

원문의 절 번호는 **고정이 아니다.** 실측한 것만으로도 `1,2,3,4` · `1,2,4` ·
`1,2,4,5` 가 섞여 있다(빠진 절은 번호도 같이 건너뛴다). 띄어쓰기도 흔들린다 —
「지적 근거」·「지적 근거 및 판단 내용」·「지적근거 및 판단 내용」이 다 있다.

그래서 후보 줄에서 **공백을 모두 지운 뒤** 이름을 맞춘다. 절 이름과 우리 칸의
짝은 `frontend/js/review_case.js:271-287` 의 `documentType` 별 라벨과 같은
집합이다 — 그쪽을 고치면 여기도 같이 고쳐야 한다.
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import re
import zipfile

from gumiho.services import rhwp

logger = logging.getLogger(__name__)

# 첨부 한 건에서 읽을 상한. 지적사례는 길어야 대여섯 쪽이다 — 이보다 크면
# 우리가 아는 그 문서가 아니므로 자른다(deflate bomb 방어도 겸한다).
MAX_CHARS = 500_000
PDFTOTEXT_TIMEOUT = 30.0

_PDF_MAGIC = b"%PDF"
_ZIP_MAGIC = b"PK\x03\x04"
_OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"

_NBSP = " "
_WS = re.compile(r"[ \t　]+")
_NL = re.compile(r"\n{3,}")

# 절 표시 줄: 「3. 지적 근거 및 판단 내용」. 이름은 아래에서 따로 맞춘다.
_HEADING = re.compile(r"^[ \t　]*(\d{1,2})[ \t　]*[.．][ \t　]*(\S.*?)[ \t　]*$")

# 공백을 지운 절 이름 → metadata 칸. 위쪽 주석 참고.
_SECTION_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("companyAccounting", re.compile(r"^회사의회계처리$")),
    ("violation", re.compile(r"^(?:회계기준|감사기준|법규)?위반지적내용$|^감사인지적내용$")),
    ("rationale", re.compile(r"^지적근거(?:및판단내용)?$|^중요감사절차해당근거(?:및판단내용)?$")),
    ("auditDeficiency", re.compile(r"^감사절차미흡사항$|^위반발생경위$")),
    ("implication", re.compile(r"^시사점$")),
]

#: `review_case` metadata 에서 본문을 담는 칸. 순서는 화면에 찍히는 차례다.
SECTION_KEYS: tuple[str, ...] = tuple(key for key, _ in _SECTION_PATTERNS)


class AttachmentTextError(RuntimeError):
    """첨부에서 글자를 뽑지 못했다."""


def sniff(data: bytes) -> str:
    """`pdf` · `hwpx` · `hwp` · `unknown`. 확장자는 보지 않는다(위 주석)."""
    if data.startswith(_PDF_MAGIC):
        return "pdf"
    if data.startswith(_ZIP_MAGIC):
        return "hwpx"
    if data.startswith(_OLE_MAGIC):
        return "hwp"
    return "unknown"


def normalize(text: str) -> str:
    """대조용. 공백을 모두 지운다.

    같은 문서라도 도구에 따라 줄바꿈 자리가 달라진다(옛 HWP 는 눈에 보이는
    줄에서 끊긴다). 줄 나눔은 내용이 아니므로 맞대 볼 때는 지우고 본다 —
    실측에서 이 잣대로 보면 rhwp 결과와 지금 DB 본문이 정확히 같았다.
    """
    return re.sub(r"\s+", "", text or "")


def _clean(text: str) -> str:
    """줄 구조는 남기고 군더더기 공백만 지운다(`prior_board._clean` 과 같은 규칙)."""
    text = text.replace(_NBSP, " ").replace("\r\n", "\n").replace("\r", "\n")
    text = _WS.sub(" ", text)
    text = "\n".join(line.strip() for line in text.split("\n"))
    return _NL.sub("\n\n", text).strip()


def _unwrap(text: str) -> str:
    """문단 안의 줄바꿈을 되붙인다. 빈 줄(문단 경계)은 남긴다.

    PDF·옛 HWP 는 **눈에 보이는 줄**을 그대로 준다. 화면이 `pre-wrap` 이라
    그대로 두면 좁은 폭에서 줄이 들쭉날쭉해진다. 문단 단위로 되붙이면
    브라우저가 알아서 흘린다 — 지금 DB 의 KICPA 본문이 그 모양이다.

    ⚠️ 번호 매김(`①`·`1)`·`가.`)으로 시작하는 줄은 붙이지 않는다. 지적 근거
       절이 대개 `①`·`②` 로 갈라져 있는데, 붙이면 한 덩어리가 되어 읽을 수 없다.
    """
    out: list[str] = []
    for para in text.split("\n\n"):
        lines = [line for line in para.split("\n") if line]
        if not lines:
            continue
        merged: list[str] = []
        for line in lines:
            if merged and not _starts_new_line(line):
                merged[-1] = f"{merged[-1]} {line}"
            else:
                merged.append(line)
        out.append("\n".join(merged))
    return "\n\n".join(out)


# 줄 첫머리의 번호 매김. 「가.」·「나)」 같은 한글 번호는 **그 다섯 자만** 본다 —
# `[가-힣]` 으로 열어 두면 앞 줄에서 잘려 넘어온 「다. 그러나…」 같은 줄까지
# 새 줄로 잡아 문단이 쪼개진다.
_BULLET = re.compile(r"^(?:[①-⑳]|[▣▪·※□■○●◦\-]|\(?\d{1,2}[).]|[가나다라마][.)])\s*")


def _starts_new_line(line: str) -> bool:
    """이 줄이 앞 줄에 이어지는 것이 아니라 새로 시작하는 것인가."""
    return bool(_BULLET.match(line))


async def _pdf_text(data: bytes) -> str:
    """`pdftotext -layout`. 왜 pypdf 가 아닌지는 맨 위 표에 적어 두었다."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "pdftotext", "-layout", "-", "-",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:      # 이미지에 poppler-utils 가 없다
        raise AttachmentTextError(
            "pdftotext 를 찾지 못했습니다 — backend/Dockerfile 의 poppler-utils 를 확인해 주세요."
        ) from exc
    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(data), timeout=PDFTOTEXT_TIMEOUT
        )
    except asyncio.TimeoutError as exc:
        proc.kill()
        await proc.wait()
        raise AttachmentTextError("PDF 읽기가 시간 안에 끝나지 않았습니다.") from exc
    if proc.returncode != 0:
        message = stderr.decode("utf-8", "replace").strip()
        raise AttachmentTextError(f"PDF 를 읽지 못했습니다: {message[:200]}")
    return stdout.decode("utf-8", "replace")


def _hwpx_text(data: bytes) -> str:
    """HWPX 의 `Contents/section0.xml` 을 문단 단위로 읽는다.

    `<hp:t>` 조각은 **붙여서** 읽는다 — 한 문단이 낱말마다 갈라져 있어서
    조각 사이에 무엇을 끼우면 「기준서 제 / 1115 / 호」 처럼 부서진다
    (`prior_board._text` 의 같은 주석 참고).
    """
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
        names = [n for n in archive.namelist() if re.fullmatch(r"Contents/section\d+\.xml", n)]
        if not names:
            raise AttachmentTextError("HWPX 안에 본문(Contents/section*.xml)이 없습니다.")
        lines: list[str] = []
        for name in sorted(names):
            xml = archive.read(name).decode("utf-8", "replace")
            for para in re.split(r"(?i)<hp:p[ >]", xml):
                runs = re.findall(r"(?is)<hp:t[^>]*>(.*?)</hp:t>", para)
                line = "".join(
                    html.unescape(re.sub(r"(?is)<[^>]+>", "", run)) for run in runs
                )
                if line.strip():
                    lines.append(line.rstrip())
    except zipfile.BadZipFile as exc:
        raise AttachmentTextError("HWPX 를 열지 못했습니다(zip 이 깨졌습니다).") from exc
    return "\n".join(lines)


async def _hwp_text(data: bytes) -> str:
    """옛 HWP(OLE). `services/rhwp.py` 가 한글 파일을 푸는 유일한 자리다."""
    with rhwp.workspace() as tmp:
        doc = tmp / "attachment.hwp"
        doc.write_bytes(data)
        try:
            result = await rhwp.export_text(doc)
        except rhwp.RhwpError as exc:
            raise AttachmentTextError(f"한글 문서를 읽지 못했습니다: {exc}") from exc
    pages = result.get("pages") or []
    return "\n".join(page.get("text") or "" for page in pages)


async def extract_text(data: bytes, *, label: str = "") -> str:
    """첨부 바이트 → 글자. 형식을 가려 알맞은 도구로 보낸다."""
    kind = sniff(data)
    if kind == "pdf":
        text = await _pdf_text(data)
    elif kind == "hwpx":
        text = _hwpx_text(data)
    elif kind == "hwp":
        text = await _hwp_text(data)
    else:
        raise AttachmentTextError(
            f"알 수 없는 첨부 형식입니다({data[:8]!r}) — {label or '이름 없음'}"
        )
    if len(text) > MAX_CHARS:
        logger.warning("첨부가 %s자를 넘어 잘랐습니다 — %s", MAX_CHARS, label or "이름 없음")
        text = text[:MAX_CHARS]
    return _clean(text)


def _scan_headings(lines: list[str]) -> list[tuple[int, str, str]]:
    """절 표시 줄을 훑어 `(줄 번호, 우리 칸, 공백 지운 원문 이름)` 을 돌려준다."""
    marks: list[tuple[int, str, str]] = []
    for index, line in enumerate(lines):
        heading = _HEADING.match(line)
        if heading is None:
            continue
        name = re.sub(r"\s+", "", heading.group(2))
        for key, pattern in _SECTION_PATTERNS:
            if pattern.match(name):
                marks.append((index, key, name))
                break
    return marks


def split_sections(text: str) -> dict[str, str]:
    """절 이름으로 본문을 가른다. 열쇠는 `SECTION_KEYS` 다.

    절 표시 앞(공개번호·쟁점 분야 같은 머리말)은 버린다 — 그 값들은 게시판
    목록·항목표에서 이미 더 깔끔하게 얻는다.
    """
    lines = text.split("\n")
    marks = _scan_headings(lines)
    sections: dict[str, str] = {}
    for order, (start, key, _) in enumerate(marks):
        end = marks[order + 1][0] if order + 1 < len(marks) else len(lines)
        body = _unwrap(_clean("\n".join(lines[start + 1:end])))
        if body and key not in sections:
            sections[key] = body
    return sections


def heading_labels(text: str) -> dict[str, str]:
    """우리 칸 → 원문이 쓴 절 이름(공백 지움).

    `documentType` 을 여기서 고른다. 원문은 사례 갈래에 따라 2번 절 이름을
    바꿔 단다 — 「회계기준 위반 지적 내용」·「감사기준 위반 지적내용」·
    「감사인 지적내용」·「법규 위반 지적내용」. 짐작하지 않고 **원문이 쓴
    이름을 그대로** 읽으면 갈래가 정해진다(`review_board.document_type_of`).
    """
    labels: dict[str, str] = {}
    for _, key, name in _scan_headings(text.split("\n")):
        labels.setdefault(key, name)
    return labels


async def extract_sections(data: bytes, *, label: str = "") -> dict[str, str]:
    """첨부 바이트 → `{companyAccounting: …, violation: …, …}`.

    절을 하나도 못 찾으면 빈 표를 돌려준다. 부르는 쪽이 경고를 남긴다 —
    글자는 나왔는데 절이 없다는 것은 우리가 아는 서식이 아니라는 뜻이다.
    """
    return split_sections(await extract_text(data, label=label))
