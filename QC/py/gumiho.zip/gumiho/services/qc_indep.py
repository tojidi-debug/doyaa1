"""[품감] 통합(개발) — 매출장 대사(독립성) 엔진(2026-11-11, 개발서버 전용).

[품감] 독립성 대사 화면(`frontend/independence_check.html`, 원본 소스 없이 묶음 파일만 있음)이 브라우저에서
하던 일을 **같은 규칙으로** 옮겼다. 통합 화면의 「제출자료 대사」가 사전제출자료·감사보고서 대사와 한 번에 돌린다.

    매출장(엑셀) ─▶ 거래 줄(일자·거래처·사업자번호·적요·금액)
    사전제출자료 2-3(외부감사 수행회사) + 기업진단 회사 목록 ─▶ 감사·인증 대상 회사
    거래처 ↔ 대상 회사  (사업자번호 → 법인등록번호 → 정규화 회사명 → 이름 포함)
    적요 → 용역 분류(기장·재무제표 작성·가치평가·자문·인적용역·구축 …) → 「상」·「중」 후보

* 허용되는 세무조정·세금신고, 감사보수 자체, 별도 인증(기업진단), 분류 없음은 **후보에서 뺀다**(원본과 같음).
  기업진단 거래는 「같은 회사에 기장」을 찾는 데만 쓴다.
* 내부통제·회계시스템 **구축**은 그 뒤 3년 안의 외부감사 회사와도 맞춘다(자기검토 위협 냉각기간).
* 원본의 「담당 회계사 이름 시트」 전용 열 배치는 옮기지 않았다(사람 이름이 코드에 박힌다). 머리줄로 못 읽는
  시트는 열 모양(날짜·금액·글 열)으로 짐작한다(원본의 같은 짐작 규칙).
* 파일은 저장하지 않는다. AI 모델은 쓰지 않는다(규칙만).
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime, timedelta
from typing import Any

# ── 용역 분류(원본 규칙 그대로, 위에서부터 처음 맞는 것) ─────────────────────────

_RULES: list[tuple[re.Pattern[str], dict[str, Any]]] = [
    (re.compile(r"내부\s*통제.*(?:구축|설계|도입)|회계\s*시스템.*(?:구축|설계|도입)|erp.*(?:구축|설계|도입)|결산\s*시스템.*(?:구축|설계|도입)", re.I),
     {"service": "내부통제·회계시스템 구축", "risk": "상", "review": True, "reason": "구축한 내부통제·회계시스템에 대한 자기검토 위협 가능성"}),
    (re.compile(r"기장|장부|전표\s*처리|회계처리\s*대행|세무기장", re.I),
     {"service": "기장·전표처리", "risk": "상", "review": True, "reason": "기장 또는 전표처리 업무 가능성"}),
    (re.compile(r"재무제표.*(작성|대리|지원)|결산서.*(작성|대리|지원)|법인결산|결산분개|수정분개|현금흐름표.*작성|지분법.*계산|연결분개|"
                r"이연법인세.*계산|파생상품.*평가|금융비용\s*자본화|채권채무\s*재조정|스탁옵션|전환사채.*회계처리", re.I),
     {"service": "재무제표 작성·회계처리 지원", "risk": "상", "review": True, "reason": "재무제표 대리작성·작성지원 또는 수정분개 제시 가능성"}),
    (re.compile(r"가치평가|valuation|밸류에이션|주식가치|기업가치|자산\s*양수도|영업권|무형자산|공정가치|합병비율|평가수수료", re.I),
     {"service": "가치평가·자산양수도", "risk": "상", "review": True, "reason": "가치평가 또는 주요 자산 양수도 자문 가능성"}),
    (re.compile(r"경영진?\s*(?:역할|의사결정|판단)|임원\s*(?:역할|의사결정)|거래\s*승인|업무\s*집행|회계\s*자문|회계처리\s*자문|재무\s*자문|컨설팅|"
                r"재무\s*실사|due\s*diligence|m&a|인수\s*자문|매각\s*자문|양수도\s*자문", re.I),
     {"service": "회계자문·컨설팅", "risk": "상", "review": True, "reason": "경영진 의사결정 또는 재무정보에 영향을 미치는 자문·컨설팅 가능성"}),
    (re.compile(r"급여\s*대행|4대보험|파견|인력\s*지원|인적\s*용역", re.I),
     {"service": "인적용역·업무대행", "risk": "상", "review": True, "reason": "회계기록 또는 재무정보 작성 관여 가능성"}),
    (re.compile(r"세무\s*조정|법인세\s*조정|소득세\s*조정|조정\s*수수료|조정료|세무\s*신고|신고\s*수수료|신고\s*대행|신고\s*대리|원천징수|원천세\s*신고|"
                r"부가\s*가치세|부가세|종합소득세|법인세\s*신고|양도세|상속세|증여세|연말정산", re.I),
     {"service": "허용 세무조정·세금신고", "risk": "낮음", "review": False, "reason": "허용되는 세무조정·세금신고 업무"}),
    (re.compile(r"감사\s*수수료|회계\s*감사|외부\s*감사|외감|감사\s*보수|감사", re.I),
     {"service": "외부감사", "risk": "낮음", "review": False, "reason": "감사업무 자체 보수"}),
    (re.compile(r"기업\s*진단|진단\s*수수료|진단\s*검토|재무\s*진단|검증\s*용역|검증\s*수수료|검증\s*보고서|정산\s*보고서|확인서|인증\s*업무|합의된\s*절차", re.I),
     {"service": "기업진단·인증", "risk": "중", "review": True, "reason": "독립성 검토가 필요한 별도 인증업무"}),
    (re.compile(r"검토|검증|확인|보고서|용역|보수료|수수료|대행|자문|세무\s*컨설팅|세무\s*자문", re.I),
     {"service": "업무성격 확인 필요", "risk": "중", "review": True, "reason": "적요만으로 업무 성격을 확정하기 어려움"}),
]
_NONE = {"service": "기타", "risk": "낮음", "review": False, "reason": "독립성 검토 키워드가 확인되지 않음"}
SKIP = {"허용 세무조정·세금신고", "외부감사", "기업진단·인증", "기타"}

_ISSUES = {
    "내부통제·회계시스템 구축": ("외부감사 전 3년 이내 내부통제·회계시스템 구축 여부 확인",
                        "감사인이 구축한 내부통제 또는 회계시스템을 스스로 감사하는 자기검토 위협이 있을 수 있습니다. 구축 완료일, 최초 감사대상연도와 3년 냉각기간 경과 여부를 확인하세요."),
    "기장·전표처리": ("감사대상회사 기장·전표처리 여부 확인",
                "외부감사대상회사에 대한 기장 또는 전표처리 업무인지 확인해야 합니다. 계약서, 세금계산서 품목, 장부·전표 산출물과 수행기간을 대조하세요."),
    "재무제표 작성·회계처리 지원": ("재무제표 대리작성·작성지원 또는 수정분개 제시 여부 확인",
                          "결산·재무제표 관련 업무가 대리작성, 작성지원 또는 수정분개 제시에 해당할 수 있습니다. 계약서, 현금흐름표·연결분개 등 산출물과 회사 작성 증빙을 확인하세요."),
    "가치평가·자산양수도": ("가치평가·주요 자산 양수도 자문 여부 확인",
                    "감사기간 중 가치평가 또는 주요 자산의 매수·매도 관련 자문·용역인지 확인해야 합니다. 계약서, 평가보고서, 거래 대상 자산과 수행기간을 확인하세요."),
    "회계자문·컨설팅": ("회계처리자문·재무정보 영향이 큰 컨설팅 여부 확인",
                 "재무정보에 직접 영향을 미치는 회계처리자문 또는 컨설팅인지 확인해야 합니다. 계약서, 세금계산서 품목, 업무범위와 최종 산출물을 대조하세요."),
    "인적용역·업무대행": ("인적용역·업무대행의 재무정보 관여 여부 확인",
                  "인력지원·급여대행 등으로 회사의 회계기록 또는 재무정보 작성에 관여했는지 확인해야 합니다. 파견인력 역할, 계약서와 산출물을 확인하세요."),
    "기업진단·인증": ("감사대상회사에 대한 별도 인증업무 수행 여부 확인",
                "외부감사와 기업진단 등 별도 인증업무가 동일 회사에 제공되었는지 확인해야 합니다. 각 계약서, 수행기간과 문서화된 독립성 검토 내역을 확인하세요."),
    "업무성격 확인 필요": ("업무 성격이 불명확하여 증빙 확인 필요",
                   "적요만으로 비감사용역의 성격을 판단하기 어렵습니다. 계약서, 세금계산서 품목, 업무 산출물을 확인하여 기장·회계자문·재무제표 작성지원 여부를 판단하세요."),
}


def classify(*parts: Any) -> dict[str, Any]:
    text = re.sub(r"\s+", " ", " ".join(str(p or "") for p in parts)).strip()
    for pat, res in _RULES:
        if pat.search(text):
            return dict(res)
    return dict(_NONE)


def issue_of(service: str, target_kind: str) -> tuple[str, str]:
    if target_kind == "기업진단" and service == "기장·전표처리":
        return ("기업진단과 기장업무 동시수행 여부 확인",
                "기업진단 회사에 대한 기장업무 병행 가능성이 있어 공인회계사법 제21조상 독립성 위반 여부를 확인해야 합니다. "
                "기업진단 계약서, 기장계약서, 세금계산서와 수행기간을 대조하세요.")
    return _ISSUES.get(service, ("독립성 관련 업무 여부 확인", "계약서, 세금계산서 품목과 업무 산출물을 확인하세요."))


# ── 값 다듬기 ────────────────────────────────────────────────────────────────

_LEGAL = re.compile(r"농업회사법인|농업법인|영농조합법인|유한책임회사|사회복지법인|주식회사|유한회사|합자회사|합명회사|사단법인|재단법인|"
                    r"의료법인|학교법인|\(\s*주\s*\)|\(\s*유\s*\)|\(\s*사\s*\)|㈜|㈲|㈔|법인", re.I)


def norm_name(v: Any) -> str:
    if v is None:
        return ""
    s = unicodedata.normalize("NFKC", str(v)).lower()
    s = _LEGAL.sub("", s)
    return re.sub(r"[^0-9a-z가-힣]", "", s)


def biz_no(v: Any) -> str:
    m = re.search(r"(?:^|\D)(\d{3})-?(\d{2})-?(\d{5})(?:\D|$)", str(v or "").strip())
    return "".join(m.groups()) if m else ""


def corp_no(v: Any) -> str:
    m = re.search(r"(?:^|\D)(\d{6})-?(\d{7})(?:\D|$)", str(v or "").strip())
    return "".join(m.groups()) if m else ""


def _ymd(y: int, m: int, d: int) -> str:
    try:
        return date(y, m, d).isoformat() if 1900 <= y <= 2100 else ""
    except ValueError:
        return ""


def to_date(v: Any, year: int | None = None) -> str:
    if isinstance(v, datetime):
        return _ymd(v.year, v.month, v.day)
    if isinstance(v, date):
        return _ymd(v.year, v.month, v.day)
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 < v < 80000:                                   # 엑셀 날짜 일련번호
            d = date(1899, 12, 30) + timedelta(days=int(v))
            return d.isoformat()
        return ""
    s = str(v or "").strip()
    m = re.match(r"^(20\d{2})[-./년]\s*(\d{1,2})[-./월]\s*(\d{1,2})(?:일)?$", s)
    if m:
        return _ymd(int(m[1]), int(m[2]), int(m[3]))
    m = re.match(r"^(\d{1,2})[-./월]\s*(\d{1,2})(?:일)?$", s)
    if m and year:
        return _ymd(year, int(m[1]), int(m[2]))
    return ""


def to_amount(v: Any) -> float:
    if isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = re.sub(r"[,\s₩원]", "", str(v or ""))
    s = re.sub(r"^\((.+)\)$", r"-\1", s)
    try:
        return float(s)
    except ValueError:
        return 0.0


def _t(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v if v is not None else "")).strip()


def _has_amount(v: Any) -> bool:
    if v is None or _t(v) == "":
        return False
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return True
    return bool(re.fullmatch(r"\(?-?[\d,]+(\.\d+)?\)?원?", re.sub(r"[\s₩]", "", str(v))))


# ── 매출장 읽기 ──────────────────────────────────────────────────────────────

_HEAD = {
    "date": ["전표일자", "일자", "날짜", "거래일자", "발행일자", "작성일자"],
    "voucher": ["번호", "전표번호"],
    "client": ["거래처", "거래처명", "회사명", "상호"],
    "biz": ["사업자주민번호", "사업자등록번호", "사업자번호"],
    "corp": ["법인등록번호", "법인번호"],
    "memo": ["품명", "품목", "적요", "적요란", "내용", "거래내용", "매출상세"],
    "account": ["계정과목", "계정명"],
    "section": ["구분"],
    "amount": ["공급가액", "대변", "금액"],
    "vat": ["부가세", "부가가치세", "세액"],
    "total": ["합계", "총액"],
}
_SERVICE = re.compile(r"(?:\d{2,4}년)?(?:\d{1,2}월)?(?:장부대|기장료|기장수수료|세무조정(?:료|수수료)?|부가(?:가치)?세신고수수료|법인세신고수수료|"
                      r"종합소득세신고수수료|신고대리|세무신고(?:대리)?|결산료|감사보수|기업진단수수료|컨설팅수수료|용역수수료)", re.I)
_COMPANY_WORD = re.compile(r"농업회사법인|농업법인|유한책임회사|주식회사|유한회사|\(\s*주\s*\)|\(\s*유\s*\)|㈜|㈲|회사|법인|산업|공업|기업|건설|전자|테크|"
                           r"금속|개발|병원|조합|주유소|센터|상사|문화|에너지|기술|엔지니어링|모터", re.I)
_LEDGER_NAME = re.compile(r"매출|장부|원장|세금계산서|전표|수입|수수료|ledger|sales", re.I)
MAX_ROWS = 20000
MAX_TX = 50000


def _hkey(v: Any) -> str:
    return re.sub(r"[\s()\[\]·_\-]", "", _t(v))


def _grid(ws: Any) -> list[list[Any]]:
    rows = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i >= MAX_ROWS:
            break
        rows.append(list(row))
    return rows


def _header(grid: list[list[Any]]) -> tuple[int, dict[str, int]] | None:
    for r, row in enumerate(grid[:50]):
        keys = [_hkey(c) for c in row]
        idx: dict[str, int] = {}
        for role, names in _HEAD.items():
            for c, k in enumerate(keys):
                if k in names and c not in idx.values():
                    idx[role] = c
                    break
        if {"date", "client", "memo", "amount"} <= idx.keys():
            return r, idx
    return None


def _guess(grid: list[list[Any]], year: int | None) -> dict[str, int] | None:
    """머리줄로 못 읽는 시트 — 날짜가 가장 많은 열, 금액 열, 글 열(적요·거래처)을 짐작한다(원본의 규칙)."""
    width = max((len(r) for r in grid), default=0)
    if not width:
        return None
    counts = [(c, sum(1 for r in grid if c < len(r) and isinstance(r[c], (datetime, date, str)) and to_date(r[c], year)))
              for c in range(width)]
    dcol, n = max(counts, key=lambda x: x[1])
    if n < 3:
        return None
    rows = [r for r in grid if dcol < len(r) and to_date(r[dcol], year)]
    need = max(1, -(-len(rows) * 6 // 10))
    nums = [c for c in range(width) if c != dcol and sum(1 for r in rows if c < len(r) and _has_amount(r[c])) >= need]
    if not nums:
        return None
    mag = []
    for c in nums:
        vals = sorted(abs(to_amount(r[c])) for r in rows if c < len(r) and _has_amount(r[c]))
        mag.append((c, vals[len(vals) // 2] if vals else 0))
    mag.sort(key=lambda x: -x[1])
    amount = mag[0][0]
    texts = []
    for c in range(width):
        if c == dcol or c in nums:
            continue
        vals = [_t(r[c]) for r in rows if c < len(r) and re.search(r"[A-Za-z가-힣]", _t(r[c]))]
        if len(vals) / max(1, len(rows)) < 0.5:
            continue
        texts.append({"c": c, "svc": sum(1 for v in vals if _SERVICE.search(v)),
                      "co": sum(1 for v in vals if _COMPANY_WORD.search(v)), "near": 1 / (1 + abs(amount - c))})
    if not texts:
        return None
    memo = sorted(texts, key=lambda x: (-x["svc"], -x["near"]))[0]["c"]
    others = [t for t in texts if t["c"] != memo]
    client = sorted(others, key=lambda x: (-x["co"], -x["near"]))[0]["c"] if others else memo
    out = {"date": dcol, "memo": memo, "client": client, "amount": amount}
    if len(mag) > 1:
        out["vat"] = mag[1][0]
    return out


def _split(text: str) -> tuple[str, str]:
    """적요와 거래처가 한 칸에 있을 때(「기장료 ○○산업」) — (적요, 거래처)."""
    m = re.match(rf"^\s*({_SERVICE.pattern})\s+(.+?)\s*$", text, re.I)
    if m:
        return m.group(1), m.groups()[-1]
    m = re.match(rf"^\s*(.+?)\s+({_SERVICE.pattern})\s*$", text, re.I)
    if m:
        return m.group(2), m.group(1)
    return text, text


def _year_of(*texts: Any) -> int | None:
    for t in texts:
        m = re.search(r"20\d{2}", str(t or ""))
        if m:
            return int(m.group(0))
        m = re.search(r"(?:^|\D)(\d{2})(?:년|\D|$)", str(t or ""))
        if m and 15 <= int(m.group(1)) <= 40:
            return 2000 + int(m.group(1))
    return None


def _year_from_cells(grid: list[list[Any]]) -> int | None:
    seen: dict[int, int] = {}
    for row in grid[:400]:
        for v in row:
            d = to_date(v) if isinstance(v, (datetime, date, str)) else ""
            if d:
                seen[int(d[:4])] = seen.get(int(d[:4]), 0) + 1
    return max(seen, key=lambda k: seen[k]) if seen else None


def ledger_rows(wb: Any, name: str, *, fy: int | None = None) -> tuple[list[dict[str, Any]], list[str]]:
    """매출장 한 통합문서 → 거래 줄. (거래, 읽은 시트 이름)."""
    out: list[dict[str, Any]] = []
    sheets: list[str] = []
    for ws in wb.worksheets:
        grid = _grid(ws)
        if not grid:
            continue
        year = _year_of(ws.title, name) or fy or _year_from_cells(grid)
        head = _header(grid)
        start, idx = (head[0] + 1, head[1]) if head else (0, None)
        if idx is None:
            if not (_LEDGER_NAME.search(name) or _LEDGER_NAME.search(ws.title)):
                continue                     # 이름에 매출·장부 기색도 없고 머리줄도 없으면 매출장으로 보지 않는다
            idx = _guess(grid, year)
            if idx is None:
                continue
        got = 0
        for i in range(start, len(grid)):
            row = grid[i]
            g = lambda role: row[idx[role]] if role in idx and idx[role] < len(row) else None  # noqa: E731
            d = to_date(g("date"), year)
            if not d:
                continue
            memo, client = _t(g("memo")), _t(g("client"))
            if idx.get("memo") == idx.get("client"):
                memo, client = _split(memo)
            if not client or not re.search(r"[A-Za-z가-힣]", client):
                continue
            amt = to_amount(g("amount"))
            vat = to_amount(g("vat")) if "vat" in idx else 0.0
            if not memo and amt == 0 and vat == 0:
                continue
            tot = g("total")
            out.append({"year": int(d[:4]), "date": d, "voucher": _t(g("voucher")), "client": client,
                        "biz": biz_no(g("biz")), "corp": corp_no(g("corp")), "memo": memo, "account": _t(g("account")),
                        "section": _t(g("section")) or "매출", "amount": amt, "vat": vat,
                        "total": amt + vat if tot is None or _t(tot) == "" else to_amount(tot),
                        "source": f"{name} / {ws.title}!{i + 1}"})
            got += 1
            if len(out) >= MAX_TX:
                break
        if got:
            sheets.append(ws.title)
    return out, sheets


# ── 대상 회사 ────────────────────────────────────────────────────────────────

_NOT_EXT = re.compile(r"아파트|공동\s*주택|주택법|비외감|비\s*외감|임의\s*감사|자율\s*감사", re.I)


def clients_from_presubmit(parsed: dict[str, Any], fy: int) -> list[dict[str, Any]]:
    """사전제출자료 2-3(외부감사 수행회사) → 외부감사 대상 회사. 사업연도 「당기/전기」·숫자를 해(年)로 바꾼다."""
    roles = parsed.get("roles") or {}
    co = roles.get("company")
    if not co:
        return []
    out = []
    for r in parsed.get("rows") or []:
        v = r.get("values") or {}
        name = _t(v.get(co))
        key = norm_name(name)
        kind_text = " ".join(_t(v.get(roles[k])) for k in ("company_type",) if roles.get(k))
        if len(key) < 2 or _NOT_EXT.search(f"{name} {kind_text}"):
            continue
        y = _t(v.get(roles.get("year"))) if roles.get("year") else ""
        year: int | None = fy if y.startswith("당기") else fy - 1 if y.startswith("전기") else _year_of(y)
        out.append({"name": name, "key": key, "biz": biz_no(v.get(roles.get("biz_no"))) if roles.get("biz_no") else "",
                    "corp": corp_no(v.get(roles.get("corp_no"))) if roles.get("corp_no") else "", "kind": "외부감사",
                    "year": year, "source": f"{parsed.get('sheet', '2-3')}!{r.get('row', '')}"})
    return out


_REF_HEAD = ("회사명", "계약회사명", "감사대상회사")


def clients_from_reference(wb: Any, name: str) -> list[dict[str, Any]]:
    """기업진단·외부감사 회사 목록 엑셀(머리에 회사명·사업자등록번호·법인등록번호·사업연도)."""
    out = []
    for ws in wb.worksheets:
        grid = _grid(ws)
        hit = None
        for r, row in enumerate(grid[:50]):
            keys = [_hkey(c) for c in row]
            if any(k in _REF_HEAD for k in keys):
                pos = lambda names: next((i for i, k in enumerate(keys) if k in names), -1)  # noqa: E731,B023
                hit = (r, {"co": pos(_REF_HEAD), "biz": pos(("사업자등록번호", "사업자번호")), "corp": pos(("법인등록번호", "법인번호")),
                           "rel": pos(("관계", "구분", "연결관계")), "year": pos(("사업연도", "연도", "회계연도", "감사연도"))})
                break
        if not hit:
            continue
        kind = "기업진단" if re.search(r"기업\s*진단|인증", f"{name} {ws.title}") else "외부감사"
        start, ix = hit
        for i in range(start + 1, len(grid)):
            row = grid[i]
            cell = lambda k: row[ix[k]] if ix[k] >= 0 and ix[k] < len(row) else None  # noqa: E731,B023
            cname = _t(cell("co"))
            key = norm_name(cname)
            if len(key) < 2 or re.search(r"회사명|해당사항없음", cname) or _NOT_EXT.search(f"{name} {ws.title} {cname} {_t(cell('rel'))}"):
                continue
            out.append({"name": cname, "key": key, "biz": biz_no(cell("biz")), "corp": corp_no(cell("corp")), "kind": kind,
                        "year": _year_of(cell("year")) or _year_of(f"{name} {ws.title}"), "source": f"{name} / {ws.title}!{i + 1}"})
    return out


# ── 대사 ────────────────────────────────────────────────────────────────────

def _conflict(tx: dict[str, Any], c: dict[str, Any]) -> bool:
    return bool((tx["biz"] and c["biz"] and tx["biz"] != c["biz"]) or (tx["corp"] and c["corp"] and tx["corp"] != c["corp"]))


def match(tx: dict[str, Any], clients: list[dict[str, Any]]) -> dict[str, Any] | None:
    if tx["biz"]:
        c = next((c for c in clients if c["biz"] == tx["biz"]), None)
        if c:
            return {"client": c, "basis": "사업자번호 일치", "confidence": "high"}
    if tx["corp"]:
        c = next((c for c in clients if c["corp"] == tx["corp"]), None)
        if c:
            return {"client": c, "basis": "법인등록번호 일치", "confidence": "high"}
    key = norm_name(tx["client"])
    if not key:
        return None
    c = next((c for c in clients if c["key"] == key and not _conflict(tx, c)), None)
    if c:
        short = len(key) < 3
        return {"client": c, "basis": "짧은 회사명 일치" if short else "정규화 회사명 일치", "confidence": "review" if short else "medium"}
    if tx["biz"] or tx["corp"]:
        return None
    cands = [c for c in clients if len(c["key"]) >= 5 and len(key) >= 4 and (key in c["key"] or c["key"] in key)]
    if not cands:
        return None
    c = max(cands, key=lambda c: len(c["key"]))
    return {"client": c, "basis": "정규화 회사명 포함 일치", "confidence": "review"}


def _won(v: float) -> str:
    return f"{v:,.0f}원"


def analyze(txs: list[dict[str, Any]], clients: list[dict[str, Any]]) -> dict[str, Any]:
    seen: set[str] = set()
    tx_list = []
    for t in txs:
        k = "|".join(str(x) for x in (t["year"], t["date"], t["voucher"], norm_name(t["client"]), t["biz"],
                                       re.sub(r"\s+", "", t["memo"]), re.sub(r"\s+", "", t["account"]), t["amount"], t["vat"], t["total"]))
        if k not in seen:
            seen.add(k)
            tx_list.append(t)
    seen = set()
    cl = []
    for c in clients:
        k = f"{c['kind']}|{c.get('year') or ''}|{c['biz'] or c['corp'] or c['key']}"
        if k not in seen:
            seen.add(k)
            cl.append(c)

    pkey = lambda t: t["biz"] or norm_name(t["client"])  # noqa: E731
    diag: dict[str, dict[str, Any]] = {}
    for t in tx_list:
        if classify(t["memo"], t["account"], t["section"])["service"] != "기업진단·인증":
            continue
        k = f"{t['year']}:{pkey(t)}"
        if k.endswith(":"):
            continue
        ev = f"{t['date']} / {t['memo']} / {_won(t['amount'])} / {t['source']}"
        if k in diag:
            diag[k]["evidence"].append(ev)
        else:
            diag[k] = {"name": t["client"], "evidence": [ev]}

    cands = []
    matched = 0
    for t in tx_list:
        cls = classify(t["memo"], t["account"], t["section"])
        same_year = [c for c in cl if c.get("year") is None or c.get("year") == t["year"]]
        later = ([c for c in cl if c["kind"] == "외부감사" and c.get("year") and c["year"] > t["year"] and c["year"] - t["year"] <= 3]
                 if cls["service"] == "내부통제·회계시스템 구축" else [])
        m = match(t, same_year) or (match(t, later) if later else None)
        d = diag.get(f"{t['year']}:{pkey(t)}")
        if not m and not d:
            continue
        matched += 1
        if cls["service"] in SKIP:
            continue
        mc = m["client"] if m else None
        kind = "감사·기업진단" if mc and mc["kind"] == "외부감사" and d else (mc["kind"] if mc else "기업진단")
        company = mc["name"] if mc else d["name"] if d else t["client"]
        cool = (f"{mc['year']}년 외부감사 전 {mc['year'] - t['year']}년 이내 구축업무"
                if cls["service"] == "내부통제·회계시스템 구축" and mc and mc.get("year") and mc["year"] != t["year"] else "")
        basis = " / ".join(x for x in (m["basis"] if m else "", cool,
                                         ("기업진단 거래 사업자번호 일치" if t["biz"] else "기업진단 거래 회사명 일치") if d else "") if x)
        issue, note = issue_of(cls["service"], kind)
        cands.append({**t, "risk": "상" if cls["risk"] == "상" else "중", "service": cls["service"], "reason": cls["reason"],
                      "target_kind": kind, "company": company, "basis": basis, "confidence": m["confidence"] if m else "review",
                      "issue": issue, "note": note, "target_source": (mc or {}).get("source") or "매출장 내 기업진단 거래",
                      "evidence": "; ".join(d["evidence"][:3]) if d else ""})
    cands.sort(key=lambda c: (c["year"], 0 if c["risk"] == "상" else 1, norm_name(c["company"]), c["date"]))

    by: dict[str, dict[str, Any]] = {}
    for c in cands:
        k = norm_name(c["company"]) or c["company"]
        g = by.setdefault(k, {"company": c["company"], "risk": "중", "rows": 0, "amount": 0.0, "total": 0.0,
                              "services": [], "issues": [], "years": [], "kinds": [], "basis": [], "sources": []})
        g["rows"] += 1
        g["amount"] += c["amount"]
        g["total"] += c["total"]
        if c["risk"] == "상":
            g["risk"] = "상"
        for f, v in (("services", c["service"]), ("issues", c["issue"]), ("years", c["year"]), ("kinds", c["target_kind"]),
                     ("basis", c["basis"]), ("sources", c["source"])):
            if v and v not in g[f]:
                g[f].append(v)
    companies = sorted(by.values(), key=lambda g: (0 if g["risk"] == "상" else 1, -g["total"], g["company"]))
    return {"candidates": cands, "companies": companies,
            "summary": {"transactions": len(tx_list), "audit_clients": sum(1 for c in cl if c["kind"] == "외부감사"),
                        "diag_clients": len(diag), "matched": matched, "candidates": len(cands),
                        "high": sum(1 for c in cands if c["risk"] == "상"), "companies": len(companies)}}
