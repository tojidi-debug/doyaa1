"""[품감] 심사·조서 검토 — 감사보고서 ↔ 회사 제출자료 ↔ 기존 심사조서 대사 (GitHub 사이트 전용, 2026-11-27 사용자 지정).

심사업무·조서 작성에서 쓴다: 감사보고서(전자공시 주소·접수번호 또는 파일), 회사가 낸 자료(엑셀 등), 이미 쓴 심사조서(엑셀·한글 표)를 맞춰
중요한 **차이**와 감사보고서 본표 안의 **내부 불일치**(오류 후보)를 백만원 단위로 정리한다. 규칙만 쓴다 — AI 는 화면의 [AI 보강]에서만(따로 동의).

  감사보고서   전자공시 원문(document.xml, OpenDART API)의 본표(재무상태표·손익계산서·현금흐름표) — 단위·해를 읽어 백만원으로
  대사 자료    엑셀·한글(hwpx) 표에서 「계정 이름 + 숫자」 줄 — 이름이 같은(씻은 이름) 계정끼리 맞추고, 단위(원·천원·백만원)는 맞는 금액 수가 가장 많은 쪽으로 자동
  결과         findings = [{kind 차이|내부|증감, level 상|중|하, account, a_amt, b_amt, diff, note, loc, search(참고 기준서 검색어)}]
추측하지 않는다 — 읽지 못한 칸·애매한 칸은 버리고, 못 맞춘 것은 「읽은 계정 수」로 알린다. 저장하지 않는다.
"""
from __future__ import annotations

import io
import re
import zipfile
from decimal import Decimal
from typing import Any

from lxml import etree

from gumiho.integrations.external.dart import DartError
from gumiho.integrations.external.dart_finance import SCALE, _label, _text, amount, receipt_no
from gumiho.integrations.external.dart_statements import KIND, _utf8, _years

TOL = 1.0                      # 백만원 — 반올림 차이
ALIASES = [                    # 같은 계정으로 보는 이름(씻은 이름)
    {"매출액", "영업수익", "수익매출액", "매출", "수익"},
    {"당기순이익", "당기순손익", "당기순이익손실", "당기순손실이익", "당기순이익(손실)"},
    {"자산총계", "자산총액", "자산합계", "총자산"},
    {"부채총계", "부채총액", "부채합계", "총부채"},
    {"자본총계", "자본총액", "자본합계", "총자본"},
    {"현금및현금성자산", "현금과현금성자산", "현금및예금", "현금및현금등가물"},
    {"매출채권", "매출채권및기타채권", "매출채권및기타유동채권"},
    {"재고자산", "재고자산합계"},
    {"유형자산", "유형자산합계"},
    {"판매비와관리비", "판매비와일반관리비", "판관비", "판매관리비"},
    {"영업이익", "영업이익손실", "영업손익", "영업이익(손실)"},
    {"법인세비용차감전순이익", "법인세차감전순이익", "법인세비용차감전계속사업이익", "세전이익", "법인세비용차감전순손익"},
]
_ALIAS = {k: min(g) for g in ALIASES for k in g}
TOPIC = [   # 계정 → 기준서 검색어(참고 기준서·질의회신을 찾을 때)
    (r"재고", "재고자산 순실현가능가치 저가법 평가손실"), (r"매출채권|대손|손상", "매출채권 기대신용손실 손실충당금"), (r"유형자산", "유형자산 인식 감가상각 손상"),
    (r"무형|개발비", "무형자산 개발비 인식요건 상각"), (r"충당부채|우발", "충당부채 인식 측정 우발부채"), (r"리스|사용권", "리스 사용권자산 리스부채"),
    (r"매출|수익|계약", "수익 인식 수행의무 계약"), (r"법인세|이연", "법인세 이연법인세 인식"), (r"차입|사채|금융부채", "금융부채 상각후원가 유효이자율"),
    (r"투자부동산", "투자부동산 측정"), (r"종속|관계|지분법", "관계기업 지분법 종속기업 투자"), (r"외화|환율", "외화환산 환율변동효과"),
    (r"현금", "현금흐름표 현금및현금성자산 표시"), (r"자본|배당|자기주식", "자본 배당 자기주식"), (r"종업원|퇴직|급여", "종업원급여 확정급여제도"),
]


def receipts(text: str) -> list[str]:
    """붙여 넣은 글(주소·접수번호, 줄바꿈·쉼표·세미콜론·빈 칸 구분) → 접수번호 목록(중복 없이)."""
    out: list[str] = []
    for tok in re.split(r"[\s,;]+", str(text or "").strip()):
        if not tok:
            continue
        try:
            no = receipt_no(tok)
        except DartError:
            continue
        if no and no not in out:
            out.append(no)
    return out


def key_of(label: str) -> str:
    k = _label(str(label or ""))
    return _ALIAS.get(k, k)


def _mn(v: Decimal, scale: Decimal) -> float:
    return float(v * scale / Decimal(1000))          # SCALE 은 천원 단위 → 백만원


# ── 감사보고서(전자공시 원문) ────────────────────────────────────────────────

def dart_tables(raw: bytes) -> list[dict[str, Any]]:
    """원문 XML 한 건 → 본표 목록 [{stmt, basis, title, years, rows:[{label, key, vals(백만원)}]}]. 못 읽는 표는 버린다."""
    raw = _utf8(raw)
    root = etree.fromstring(raw, etree.XMLParser(recover=True, resolve_entities=False, no_network=True, huge_tree=False))
    if root is None:
        raise DartError("공시 원문을 읽을 수 없습니다.")
    report_name = root.findtext(".//DOCUMENT-NAME") or ""
    out: list[dict[str, Any]] = []
    last_unit = ""
    for table in root.iter("TABLE"):
        group = table.getparent()
        if group is None:
            continue
        title = re.sub(r"\s+", "", " ".join(_text(e) for e in group.findall("./TITLE")))
        prefix = ""
        if re.search(r"재무상태표|대차대조표|손익계산서|현금흐름표", title) and "주석" not in title:
            kids = list(group)
            prefix = " ".join(_text(el) for el in kids if el is not table and kids.index(el) < kids.index(table))
        else:
            if "재무제표" not in title or table.find("./THEAD/TR") is None:
                continue
            head = table.getprevious()
            while head is not None and head.tag == "P" and not _text(head).strip():
                head = head.getprevious()
            if head is None or head.tag != "TABLE" or head.find("./THEAD") is not None:
                continue
            first = head.find(".//TR")
            name = re.sub(r"\s+", "", _text(first) if first is not None else "")
            if not re.search(r"재무상태표|대차대조표|손익계산서|현금흐름표", name) or len(name) > 20:
                continue
            title, prefix = name, _text(head)
        kind = next((k for k, rx in KIND if re.search(rx, title)), None)
        if kind is None or not prefix:
            continue
        units = re.findall(r"단위\s*[:：]\s*(백만원|천원|원)", prefix) or ([last_unit] if last_unit else [])
        if not units:
            continue
        last_unit = units[-1]
        scale = SCALE[units[-1]]
        years = _years(prefix)
        header = table.find("./THEAD/TR")
        if header is None or not 1 <= len(years) <= 4:
            continue
        groups, others, offset = [], [], 0
        for index, cell in enumerate([c for c in header if c.tag in ("TH", "TD", "TE")]):
            span = int(cell.get("COLSPAN", "1"))
            if re.search(r"제\s*\d+|당기|전기|20\d{2}", _text(cell)):
                groups.append((offset, offset + span))
            if index and not re.search(r"주\s*석|과\s*목|구\s*분", _text(cell)):
                others.append((offset, offset + span))
            offset += span
        if len(groups) != len(years) and len(others) == len(years):
            groups = others
        if len(groups) != len(years):
            continue
        basis = "연결" if "연결" in title or ("연결" in report_name and "별도" not in title) else "별도"
        rows = []
        for row in table.findall("./TBODY/TR"):
            cells = [c for c in row if c.tag in ("TD", "TE", "TH")]
            if not cells:
                continue
            label = _text(cells[0])
            if not _label(label):
                continue
            expanded: list[str] = []
            for cell in cells:
                expanded += [_text(cell)] * int(cell.get("COLSPAN", "1"))
            vals: list[float | None] = []
            for start, end in groups:
                got = list(dict.fromkeys(v for v in (amount(x) for x in expanded[start:end]) if v is not None))
                vals.append(_mn(got[0], scale) if len(got) == 1 else None)
            if any(v is not None for v in vals):
                rows.append({"label": label.strip(), "key": key_of(label), "vals": vals})
        if rows:
            out.append({"stmt": kind, "basis": basis, "title": title, "years": years, "rows": rows})
    return out


def dart_zip(zip_bytes: bytes, rcept_no: str) -> list[dict[str, Any]]:
    """document.xml(zip) → 본표 목록(원문 안의 XML 모두). zip 이 아니면 전자공시 오류 문구를 그대로."""
    if not zip_bytes.startswith(b"PK"):
        try:
            err = etree.fromstring(zip_bytes)
            raise DartError(f"전자공시({err.findtext('status') or ''}): {err.findtext('message') or '원문을 받지 못했습니다.'}")
        except etree.XMLSyntaxError:
            raise DartError("공시 원문을 받지 못했습니다.") from None
    tables: list[dict[str, Any]] = []
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
        for e in z.infolist():
            if e.filename.lower().endswith(".xml"):
                tables += dart_tables(z.read(e))
    for t in tables:
        t["rcept_no"] = rcept_no
    if not tables:
        raise DartError("원문에서 재무상태표·손익계산서를 찾지 못했습니다(감사보고서 접수번호가 맞는지 확인).")
    return tables


# ── 엑셀·한글 표(대사 자료) ─────────────────────────────────────────────────

def grid_rows(grid_tables: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """qc_sample_other.tables_from_file 의 표 → 「이름 + 숫자」 줄. {sheet, row, label, key, nums:[(열, 숫자)]}"""
    rows: list[dict[str, Any]] = []
    for t in grid_tables:
        for i, r in enumerate(t["rows"], start=1):
            label, nums = None, []
            for c, v in enumerate(r):
                if isinstance(v, bool):
                    continue
                if isinstance(v, (int, float)):
                    nums.append((c, float(v)))
                    continue
                s = str(v if v is not None else "").strip()
                if not s:
                    continue
                a = amount(s)
                if a is not None and re.search(r"\d", s):
                    nums.append((c, float(a)))
                elif label is None and re.search(r"[가-힣]{2,}", s) and not nums:
                    label = s
            if label and nums and _label(label):
                rows.append({"sheet": t["name"], "row": i, "label": label, "key": key_of(label), "nums": nums})
    return rows


# ── 대사 ────────────────────────────────────────────────────────────────

def _level(diff: float, mat: float) -> str:
    d = abs(diff)
    return "상" if d >= mat else ("중" if d >= max(mat / 5, TOL * 5) else "하")


def _topic(account: str) -> str:
    for rx, q in TOPIC:
        if re.search(rx, account):
            return q
    return f"{account} 회계처리"


def _pick_unit(a_rows: dict[str, float], b_rows: list[dict[str, Any]]) -> float:
    """대사 자료의 단위 배율(원→백만원 1e-6 · 천원 1e-3 · 백만원 1) — 같은 이름 계정이 금액까지 맞는 수가 가장 많은 쪽."""
    best, best_n = 1e-6, -1
    for f in (1e-6, 1e-3, 1.0):
        n = 0
        for r in b_rows:
            a = a_rows.get(r["key"])
            if a is not None and any(abs(v * f - a) <= TOL for _c, v in r["nums"]):
                n += 1
        if n > best_n:
            best, best_n = f, n
    return best


def _internal(tbl: dict[str, Any], mat: float, name: str) -> list[dict[str, Any]]:
    """감사보고서 본표 안의 산식 — 자산=부채+자본, 손익계산서의 이익 산식, 현금흐름 기말현금 ↔ 재무상태표."""
    rows = {r["key"]: r["vals"][0] for r in tbl["rows"] if r["vals"] and r["vals"][0] is not None}
    f: list[dict[str, Any]] = []

    def add(account: str, a_name: str, a: float, b_name: str, b: float, note: str) -> None:
        d = b - a
        if abs(d) > TOL:
            f.append({"kind": "내부", "level": _level(d, mat), "account": account, "stmt": tbl["stmt"], "basis": tbl["basis"], "a_name": a_name, "a_amt": round(a),
                      "b_name": b_name, "b_amt": round(b), "diff": round(d), "note": note, "loc": f"{name} {tbl['basis']} {tbl['title']}", "search": _topic(account)})

    if tbl["stmt"] == "bs":
        a, l, e = rows.get("자산총계"), rows.get("부채총계"), rows.get("자본총계")
        if None not in (a, l, e):
            add("자산총계 = 부채총계 + 자본총계", "자산총계", a, "부채+자본", l + e, "재무상태표가 균형을 이루지 않습니다(반올림 1백만원은 제외).")
    if tbl["stmt"] == "pl":
        s, cost, gp = rows.get("매출액"), rows.get("매출원가"), rows.get("매출총이익")
        if None not in (s, cost, gp):
            add("매출총이익 = 매출액 − 매출원가", "매출총이익", gp, "매출액−매출원가", s - cost, "손익계산서 산식 불일치(원가 표기 부호·소계 확인).")
        sga, op = rows.get("판매비와관리비"), rows.get("영업이익")
        if None not in (gp, sga, op):
            add("영업이익 = 매출총이익 − 판매비와관리비", "영업이익", op, "매출총이익−판관비", gp - sga, "손익계산서 산식 불일치(영업외 항목 포함 여부 확인).")
    return f


def review(dart: list[dict[str, Any]], others: list[dict[str, Any]], *, materiality: float | None = None, min_diff: float = TOL) -> dict[str, Any]:
    """dart = dart_zip 결과(여러 건 가능, 접수번호별) · others = [{name, role('제출자료'|'심사조서'), rows: grid_rows 결과}]."""
    findings: list[dict[str, Any]] = []
    notes: list[str] = []
    # 기준(감사보고서): 연결·별도 따로 {key: 당기}
    ref: dict[tuple[str, str], dict[str, dict[str, Any]]] = {}
    for t in dart:
        for r in t["rows"]:
            if r["vals"] and r["vals"][0] is not None:
                ref.setdefault((t.get("rcept_no", ""), t["basis"]), {}).setdefault(r["key"], {"label": r["label"], "cur": r["vals"][0],
                                                                                                "prev": r["vals"][1] if len(r["vals"]) > 1 else None, "stmt": t["stmt"], "title": t["title"]})
    assets = next((v["자산총계"]["cur"] for v in ref.values() if "자산총계" in v), None)
    mat = materiality if materiality is not None else max(1.0, round((assets or 0) * 0.005)) if assets else 100.0
    for t in dart:
        findings += _internal(t, mat, f"감사보고서 {t.get('rcept_no', '')}")
    # 현금흐름 기말현금 ↔ 재무상태표 현금
    for (no, basis), rows in ref.items():
        cash_bs = rows.get("현금및현금성자산")
        cash_cf = next((rows[k] for k in ("기말의현금및현금성자산", "기말현금및현금성자산", "기말현금") if k in rows), None)
        if cash_bs and cash_cf and abs(cash_bs["cur"] - cash_cf["cur"]) > TOL:
            d = cash_cf["cur"] - cash_bs["cur"]
            findings.append({"kind": "내부", "level": _level(d, mat), "account": "현금흐름표 기말현금 = 재무상태표 현금및현금성자산", "stmt": "cf", "basis": basis, "a_name": "재무상태표 현금및현금성자산",
                             "a_amt": round(cash_bs["cur"]), "b_name": "현금흐름표 기말현금", "b_amt": round(cash_cf["cur"]), "diff": round(d),
                             "note": "현금흐름표의 기말 현금이 재무상태표와 다릅니다(당좌차월·사용제한 현금 표시 차이일 수 있음).", "loc": f"감사보고서 {no} {basis}", "search": _topic("현금")})
    # 대사: 감사보고서 ↔ 제출자료·심사조서
    stats = []
    for o in others:
        best: tuple[int, tuple[str, str]] | None = None
        for k, rows in ref.items():
            a_cur = {key: v["cur"] for key, v in rows.items()}
            f_unit = _pick_unit(a_cur, o["rows"])
            n = sum(1 for r in o["rows"] if (a := a_cur.get(r["key"])) is not None and any(abs(v * f_unit - a) <= TOL for _c, v in r["nums"]))
            if best is None or n > best[0]:
                best = (n, k)
        if not ref or best is None:
            continue
        k = best[1]
        rows = ref[k]
        a_cur = {key: v["cur"] for key, v in rows.items()}
        unit = _pick_unit(a_cur, o["rows"])
        unit_txt = {1e-6: "원", 1e-3: "천원", 1.0: "백만원"}[unit]
        matched = same = 0
        for r in o["rows"]:
            a = rows.get(r["key"])
            if a is None:
                continue
            matched += 1
            vals = [v * unit for _c, v in r["nums"]]
            if any(abs(v - a["cur"]) <= TOL for v in vals):
                same += 1
                continue
            if a["prev"] is not None and any(abs(v - a["prev"]) <= TOL for v in vals) and abs((a["prev"] or 0) - a["cur"]) > TOL:
                findings.append({"kind": "차이", "level": _level(a["cur"] - a["prev"], mat), "account": a["label"], "stmt": a["stmt"], "basis": k[1], "a_name": f"감사보고서 {a['title']}", "a_amt": round(a["cur"]),
                                 "b_name": o["name"], "b_amt": round(a["prev"]), "diff": round(a["prev"] - a["cur"]), "note": "대사 자료의 금액이 감사보고서의 전기 금액과 같습니다(당기 금액이 아님 — 기준일 확인).",
                                 "loc": f"{r['sheet']} {r['row']}행", "search": _topic(a["label"]), "role": o["role"]})
                continue
            b = min(vals, key=lambda v: abs(v - a["cur"])) if vals else None
            if b is None:
                continue
            d = b - a["cur"]
            if abs(d) >= max(min_diff, TOL):
                findings.append({"kind": "차이", "level": _level(d, mat), "account": a["label"], "stmt": a["stmt"], "basis": k[1], "a_name": f"감사보고서 {a['title']}", "a_amt": round(a["cur"]),
                                 "b_name": o["name"], "b_amt": round(b), "diff": round(d), "note": f"{o['role']}가 감사보고서와 다릅니다(단위 {unit_txt} 자동 인식).",
                                 "loc": f"{r['sheet']} {r['row']}행", "search": _topic(a["label"]), "role": o["role"]})
        stats.append({"name": o["name"], "role": o["role"], "rows": len(o["rows"]), "matched": matched, "same": same, "unit": unit_txt, "basis": k[1]})
        if matched == 0:
            notes.append(f"「{o['name']}」에서 감사보고서와 이름이 같은 계정을 찾지 못했습니다(계정 이름 표기·표 모양 확인).")
    # 감사보고서 전기 대비 큰 증감(참고)
    for k, rows in ref.items():
        for key, v in rows.items():
            if v["stmt"] not in ("bs", "pl") or v["prev"] is None:
                continue
            d = v["cur"] - v["prev"]
            if abs(d) >= mat and v["prev"] and abs(d) / abs(v["prev"]) >= 0.3:
                findings.append({"kind": "증감", "level": "하", "account": v["label"], "stmt": v["stmt"], "basis": k[1], "a_name": f"전기 {round(v['prev']):,}", "a_amt": round(v["prev"]), "b_name": "당기", "b_amt": round(v["cur"]),
                                 "diff": round(d), "note": f"전기 대비 {d / abs(v['prev']):+.0%} — 중요한 증감, 원인(회계처리 변경·일회성 거래) 확인.", "loc": f"감사보고서 {k[0]} {k[1]} {v['title']}", "search": _topic(v["label"])})
    swing = sorted([x for x in findings if x["kind"] == "증감"], key=lambda x: -abs(x["diff"]))
    findings = [x for x in findings if x["kind"] != "증감"] + swing[:10]          # 큰 증감은 큰 것 열 건만(참고)
    order = {"상": 0, "중": 1, "하": 2}
    findings.sort(key=lambda x: (order[x["level"]], -abs(x["diff"])))
    for n, x in enumerate(findings, start=1):
        x["id"] = n
    return {"materiality": round(mat), "min_diff": min_diff, "findings": findings, "stats": stats, "notes": notes,
            "dart": [{"rcept_no": t.get("rcept_no"), "stmt": t["stmt"], "basis": t["basis"], "title": t["title"], "rows": len(t["rows"]), "years": t["years"]} for t in dart]}
