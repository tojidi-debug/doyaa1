"""[품감] 통합 — 제출자료 대사 한 번에 (2026-11-12). 서버(api/v1/qc_sample.py)와 브라우저(GitHub 사이트의 Pyodide, qc/static/py/qs_web.py)가 **같은 코드**를 쓴다.

올린 자료를 종류별로 가른다: 사전제출자료(2-3·2-8·2-10 …) · 매출장 · 회사 목록(기업진단) · 그 밖의 첨부(감사시간집계표·감사보고서 …).
기존 세 대사를 같은 규칙 그대로 돌린다 — 중요 체크포인트(qc_sample) · 첨부 자료 대사(qc_sample_other) · 매출장 대사(독립성, qc_indep).
왼쪽(회계법인 관련 자료) 문서는 요약만 하고 회사별 체크에는 넣지 않는다(회사 감사보고서가 아니므로). 저장하지 않는다.

`run` 은 일을 어디서 돌릴지(`offload`)와 첨부 자료 대사 함수(`compare`)를 받는다 — 서버는 스레드로, 브라우저는 그 자리에서(스레드가 없다).
"""
from __future__ import annotations

import asyncio
import re
from datetime import UTC, datetime
from typing import Any, Awaitable, Callable

from gumiho.services import qc_indep, qc_review_tables, qc_sample, qc_sample_docs, qc_sample_other

XLSX_SUFFIX = (".xlsx", ".xlsm", ".xls")
GRADE = {"위반의심": "상", "중점확인": "중", "불일치": "중", "참고": "하"}


class ReviewError(Exception):
    def __init__(self, status: int, detail: str) -> None:
        super().__init__(detail)
        self.status, self.detail = status, detail


async def _to_thread(fn: Callable[..., Any], *a: Any, **k: Any) -> Any:
    return await asyncio.to_thread(fn, *a, **k)


def sort_books(blobs: list[tuple[str, bytes, str]], fy: int | None) -> dict[str, Any]:
    """엑셀을 종류별로: 사전제출자료 · 매출장 · 회사 목록 · 첨부(대사)."""
    have: dict[str, Any] = {}
    summary: list[dict[str, Any]] = []
    books: list[tuple[str, Any, str, dict[str, Any]]] = []
    txs: list[dict[str, Any]] = []
    refs: list[dict[str, Any]] = []
    attach: list[tuple[str, bytes]] = []
    for name, raw, side in blobs:
        if not name.lower().endswith(XLSX_SUFFIX):
            continue
        row: dict[str, Any] = {"name": name, "kind": "엑셀", "side": side}
        summary.append(row)
        try:
            wb = qc_sample._open(raw, name)
        except qc_sample.PresubmitError as exc:
            row.update(role="오류", error=str(exc))
            continue
        got = qc_sample._collect(wb, have, fallback=False)
        if got:
            row.update(role="사전제출자료", found=[qc_sample.SHEET_TITLES[k] for k in got], sheets=wb.sheetnames)
            continue
        books.append((name, wb, side, row))
    for name, wb, side, row in books:
        got_tx, sheets = qc_indep.ledger_rows(wb, name, fy=fy)
        if got_tx:
            txs += got_tx
            row.update(role="매출장", rows=len(got_tx), sheets=sheets)
            continue
        if re.search(r"기업\s*진단|인증|진단", name):
            got_ref = qc_indep.clients_from_reference(wb, name)
            if got_ref:
                refs += got_ref
                row.update(role="회사 목록", rows=len(got_ref), sheets=wb.sheetnames)
                continue
        row.update(role="첨부(대사)" if side == "check" else "회계법인 자료", sheets=wb.sheetnames)
    if "s23" not in have:                       # 시트 이름이 달라도 「회사명」 머리가 있는 첫 시트(매출장·회사 목록이 아닌 것)
        for name, wb, side, row in books:
            if row.get("role") not in ("첨부(대사)", "회계법인 자료"):
                continue
            got = qc_sample._collect(wb, have, fallback=True)
            if got:
                row.update(role="사전제출자료", found=[qc_sample.SHEET_TITLES[k] for k in got])
                break
    for name, raw, side in blobs:
        row = next((r for r in summary if r["name"] == name and r["side"] == side), None)
        if row and row.get("role") == "첨부(대사)" and side == "check":
            attach.append((name, raw))
    return {"have": have, "summary": summary, "txs": txs, "refs": refs, "attach": attach}


async def run(blobs: list[tuple[str, bytes, str]], fy: int | None = None, *,
              offload: Callable[..., Awaitable[Any]] = _to_thread,
              compare: Callable[..., Awaitable[Any]] | None = None) -> dict[str, Any]:
    """blobs = [(파일 이름, 바이트, 「firm」(왼쪽) | 「check」(오른쪽))]"""
    async def default_compare(result: Any, attach: Any, fy_used: int) -> Any:
        return await offload(qc_sample_other.compare, result, attach, fy=fy_used)

    compare = compare or default_compare
    sorted_ = await offload(sort_books, blobs, fy)
    summary = sorted_["summary"]

    docs: list[dict[str, Any]] = []
    names: list[str] = []
    s23 = sorted_["have"].get("s23")
    if s23:
        letter = s23["roles"].get("company")
        names = [str(r["values"].get(letter) or "") for r in s23["rows"]] if letter else []
    for name, raw, side in blobs:
        if name.lower().endswith(XLSX_SUFFIX):
            continue
        row: dict[str, Any] = {"name": name, "kind": "문서", "side": side}
        try:
            text = await qc_sample_docs.read_text(raw, name)
        except Exception as exc:  # noqa: BLE001 — 파일 하나가 안 읽혀도 나머지는 맞춘다(PDF·워드 읽기 오류의 꼴이 환경마다 다르다)
            row.update(role="오류", error=str(exc))
            summary.append(row)
            continue
        f = qc_sample_docs.facts(text)
        company, hits = qc_sample_docs.best_company(text, names) if side == "check" else (None, 0)
        row.update(role="회계법인 자료" if side == "firm" else ("감사보고서" if f.get("type") == "감사보고서" else "첨부(대사)"),
                   chars=len(text), facts=f, company=company, hits=hits)
        summary.append(row)
        if side == "check":
            docs.append({"name": name, "company": company, "facts": f})
            sorted_["attach"].append((name, raw))

    result: dict[str, Any] | None = None
    if s23:
        try:
            result = await offload(qc_sample._with_checks, sorted_["have"], fy, docs or None)
        except qc_sample.PresubmitError as exc:
            raise ReviewError(422, str(exc)) from exc
    fy_used = (result["checks"]["fy"] if result else None) or fy or datetime.now(UTC).year - 1

    other = None
    if result and sorted_["attach"]:
        other = await compare(result, sorted_["attach"], fy_used)

    sales = None
    if sorted_["txs"]:
        clients = (qc_indep.clients_from_presubmit(result, fy_used) if result else []) + sorted_["refs"]
        sales = await offload(qc_indep.analyze, sorted_["txs"], clients)
        sales["no_clients"] = not clients

    notes = []
    if not result:
        notes.append("사전제출자료(2-3. 외부감사 수행회사 현황)를 찾지 못해 회사별 체크와 첨부 자료 대사는 하지 못했습니다.")
    if sales and sales["no_clients"]:
        notes.append("매출장은 읽었지만 맞출 감사대상 회사(사전제출자료 2-3)가 없어 기업진단 거래끼리만 보았습니다.")

    # 점검 항목을 항목별 표로(화면·엑셀 같은 표) — 순서는 화면의 reviewItems(= 사전제출자료 점검 → 첨부 자료 대사)와 같다
    all_items = [*(((result or {}).get("checks") or {}).get("items") or []), *((other or {}).get("items") or [])]
    all_ok = [*(((result or {}).get("checks") or {}).get("ok") or []), *((other or {}).get("ok") or [])]
    tables = qc_review_tables.build(all_items, all_ok, summary, GRADE)
    return {"fy": fy_used, "files": summary, "result": result, "other": other, "sales": sales, "grades": GRADE, "notes": notes, "tables": tables}
