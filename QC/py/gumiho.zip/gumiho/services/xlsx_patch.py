"""엑셀 통합문서에 **값만** 꽂아 넣는다 — 나머지는 한 바이트도 안 건드린다.

## 왜 openpyxl 을 안 쓰나

심사조서 서식을 openpyxl 로 열었다 저장만 해 봤다(2026-09-01 실측):

    zip 항목        324 → 177
    도형(drawing)    36 →  28      ← 8개 사라짐
    인쇄설정         80 →   0      ← 전부 사라짐

조서는 **인쇄물**이다. 쪽 나눔·인쇄 영역이 통째로 날아가면 채워진 숫자가 맞아도
쓸 수 없는 파일이 된다. 그래서 openpyxl 로는 못 쓴다.

## 어떻게 하나

xlsx·xlsm 은 속이 zip 이다. **건드릴 시트의 XML 하나만** 고쳐 쓰고 나머지
항목은 원본 바이트를 그대로 복사한다. 도형·인쇄설정·매크로(xlsm 의
`vbaProject.bin`)·조건부서식은 우리가 아예 만지지 않으므로 보존이 보장된다.

## ⚠️ 수식 다시 계산

조서의 보이는 시트는 전부 수식이다(`=BS!D4`). 값만 바꾸면 엑셀이 **캐시된 옛
결과**를 그대로 보여 줄 수 있다. 그래서 두 가지를 한다.

  1. `xl/calcChain.xml` 을 지운다 — 계산 순서 캐시다. 없으면 엑셀이 다시 만든다.
  2. `workbook.xml` 의 `<calcPr>` 에 `fullCalcOnLoad="1"` 을 박는다.

⚠️ 값을 쓴 칸에 원래 수식이 있었다면 그 `<f>` 를 지운다. 남겨 두면 엑셀이
   다시 계산해서 우리가 넣은 값을 덮어쓴다.
"""
from __future__ import annotations

import copy
import re
import zipfile
from io import BytesIO
from typing import Any
from xml.etree import ElementTree as ET

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"

_CELL_RE = re.compile(r"^([A-Z]+)([0-9]+)$")
# 루트 태그에 선언된 이름공간을 그대로 되살리기 위해 훑는다. 등록하지 않으면
# ElementTree 가 ns0·ns1 로 바꿔 써서 엑셀이 파일을 못 연다.
_XMLNS_RE = re.compile(rb'xmlns:?([A-Za-z0-9_.-]*)="([^"]+)"')


class PatchError(RuntimeError):
    """서식이 예상과 다르다. 조용히 빈 파일을 주지 않기 위해 던진다."""


def col_index(ref: str) -> int:
    """`D` → 4. 칸을 열 순서대로 끼워 넣으려면 숫자가 필요하다."""
    n = 0
    for ch in ref:
        n = n * 26 + (ord(ch) - 64)
    return n


def split_ref(ref: str) -> tuple[str, int]:
    m = _CELL_RE.match(ref.strip().upper())
    if not m:
        raise PatchError(f"칸 주소가 아닙니다: {ref}")
    return m.group(1), int(m.group(2))


class Workbook:
    """읽고 → 값 꽂고 → 바이트로 돌려준다. 원본 파일은 건드리지 않는다."""

    def __init__(self, data: bytes) -> None:
        self._src = zipfile.ZipFile(BytesIO(data))
        self._names = self._src.namelist()
        self._patched: dict[str, bytes] = {}
        self._drop: set[str] = set()
        self._sheet_path = self._read_sheet_map()
        # 시트 XML 은 한 번만 파싱해 두고 여러 칸을 이어서 꽂는다.
        self._trees: dict[str, tuple[ET.ElementTree, dict[str, str]]] = {}

    # ── 시트 이름 → XML 경로 ───────────────────────────────────────────────

    def _read_sheet_map(self) -> dict[str, str]:
        wb = ET.fromstring(self._src.read("xl/workbook.xml"))
        rels = ET.fromstring(self._src.read("xl/_rels/workbook.xml.rels"))
        target = {
            r.get("Id"): r.get("Target")
            for r in rels.findall(f"{{{PKG_REL_NS}}}Relationship")
        }
        out: dict[str, str] = {}
        for sheet in wb.iter(f"{{{MAIN_NS}}}sheet"):
            rid = sheet.get(f"{{{REL_NS}}}id")
            path = target.get(rid or "")
            if not path:
                continue
            # 관계 경로는 xl/ 기준 상대경로다(`worksheets/sheet1.xml`).
            out[sheet.get("name") or ""] = "xl/" + path.lstrip("/")
        return out

    @property
    def sheet_names(self) -> list[str]:
        return list(self._sheet_path)

    def has_sheet(self, name: str) -> bool:
        return name in self._sheet_path

    # ── 시트 XML ──────────────────────────────────────────────────────────

    def _tree(self, sheet: str) -> tuple[ET.ElementTree, dict[str, str]]:
        if sheet in self._trees:
            return self._trees[sheet]
        path = self._sheet_path.get(sheet)
        if path is None:
            raise PatchError(f"없는 시트입니다: {sheet}")
        raw = self._src.read(path)

        # 루트에 선언된 이름공간을 전부 등록한다(위 주석의 이유).
        head = raw[:4000]
        ns = {
            (prefix.decode() or ""): uri.decode()
            for prefix, uri in _XMLNS_RE.findall(head)
        }
        for prefix, uri in ns.items():
            ET.register_namespace(prefix, uri)
        tree = ET.ElementTree(ET.fromstring(raw))
        self._trees[sheet] = (tree, ns)
        return self._trees[sheet]

    # ── 값 꽂기 ───────────────────────────────────────────────────────────

    def set(self, sheet: str, ref: str, value: Any) -> None:
        """칸 하나에 값을 넣는다. `None` 이면 **비운다**(0 이 아니다).

        0 과 빈 칸은 조서에서 뜻이 다르다 — 서식의 수식이
        `IF(ISBLANK(D4),…)` 로 그 둘을 갈라 본다.
        """
        tree, _ = self._tree(sheet)
        col, row_no = split_ref(ref)
        data = tree.getroot().find(f"{{{MAIN_NS}}}sheetData")
        if data is None:
            raise PatchError(f"{sheet} 에 sheetData 가 없습니다.")

        row = self._row(data, row_no)
        cell = self._cell(row, col, row_no)

        # 원래 수식이 있었으면 지운다. 남기면 엑셀이 다시 계산해 우리 값을 덮는다.
        for f in cell.findall(f"{{{MAIN_NS}}}f"):
            cell.remove(f)
        for v in cell.findall(f"{{{MAIN_NS}}}v"):
            cell.remove(v)
        for is_ in cell.findall(f"{{{MAIN_NS}}}is"):
            cell.remove(is_)

        if value is None or value == "":
            cell.attrib.pop("t", None)
            return

        if isinstance(value, (int, float)) and not isinstance(value, bool):
            cell.attrib.pop("t", None)
            v = ET.SubElement(cell, f"{{{MAIN_NS}}}v")
            # 정수는 정수로 적는다. 1.0 은 조서에서 1 로 보여야 한다.
            v.text = str(int(value)) if float(value).is_integer() else repr(float(value))
        else:
            # 공유문자열 표를 건드리지 않으려고 inlineStr 을 쓴다. 표를 고치면
            # 그 표를 쓰는 **모든 시트**의 인덱스가 밀려 통째로 깨진다.
            cell.set("t", "inlineStr")
            is_ = ET.SubElement(cell, f"{{{MAIN_NS}}}is")
            t = ET.SubElement(is_, f"{{{MAIN_NS}}}t")
            t.text = str(value)
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")

    def set_formula(self, sheet: str, ref: str, formula: str, style: int | None = None) -> None:
        """칸에 **수식**을 넣는다(앞의 「=」 없이 줘도 된다). 값은 비워 두고 엑셀이 열 때 계산한다(`fullCalcOnLoad`).
        `style` 을 주면 그 서식 번호(`cellXfs` 의 순번)를 붙인다 — 숫자 쉼표 따위(`number_style`)."""
        tree, _ = self._tree(sheet)
        col, row_no = split_ref(ref)
        data = tree.getroot().find(f"{{{MAIN_NS}}}sheetData")
        if data is None:
            raise PatchError(f"{sheet} 에 sheetData 가 없습니다.")
        cell = self._cell(self._row(data, row_no), col, row_no)
        for tag in ("f", "v", "is"):
            for e in cell.findall(f"{{{MAIN_NS}}}{tag}"):
                cell.remove(e)
        cell.attrib.pop("t", None)
        if style is not None:
            cell.set("s", str(style))
        f = ET.SubElement(cell, f"{{{MAIN_NS}}}f")
        f.text = formula[1:] if formula.startswith("=") else formula

    def number_style(self) -> int:
        """천 단위 쉼표 숫자 서식(#,##0, 테두리·채움 없음)의 `cellXfs` 번호 — 없으면 하나 덧붙인다.
        styles.xml 은 다시 직렬화하지 않고 글자 그대로 한 줄만 끼운다(이름공간·mc:Ignorable 보존)."""
        if getattr(self, "_num_style", None) is not None:
            return self._num_style
        path = "xl/styles.xml"
        text = (self._patched.get(path) or self._src.read(path)).decode("utf-8")
        m = re.search(r"<cellXfs\b[^>]*>(.*?)</cellXfs>", text, re.S)
        if not m:
            raise PatchError("styles.xml 에 cellXfs 가 없습니다.")
        xfs = re.findall(r"<xf\b[^>]*?(?:/>|>.*?</xf>)", m.group(1), re.S)
        for i, xf in enumerate(xfs):
            head = xf.split(">", 1)[0]
            attr = dict(re.findall(r'(\w+)="([^"]*)"', head))
            if attr.get("numFmtId") == "3" and attr.get("borderId", "0") == "0" and attr.get("fillId", "0") == "0":
                self._num_style = i
                return i
        new = '<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
        start, end = m.span(1)
        body = m.group(1) + new
        opening = re.sub(r'count="\d+"', f'count="{len(xfs) + 1}"', text[m.start():start])
        text = text[:m.start()] + opening + body + text[end:]
        self._patched[path] = text.encode("utf-8")
        self._num_style = len(xfs)
        return self._num_style

    @staticmethod
    def _row(data: ET.Element, row_no: int) -> ET.Element:
        rows = data.findall(f"{{{MAIN_NS}}}row")
        for row in rows:
            if int(row.get("r") or 0) == row_no:
                return row
        # 없으면 번호 순서에 맞춰 끼워 넣는다. 엑셀은 순서가 어긋난 행을 싫어한다.
        new = ET.Element(f"{{{MAIN_NS}}}row", {"r": str(row_no)})
        for i, row in enumerate(rows):
            if int(row.get("r") or 0) > row_no:
                data.insert(list(data).index(row), new)
                return new
        data.append(new)
        return new

    @staticmethod
    def _cell(row: ET.Element, col: str, row_no: int) -> ET.Element:
        want = col_index(col)
        cells = row.findall(f"{{{MAIN_NS}}}c")
        for cell in cells:
            ref = cell.get("r") or ""
            m = _CELL_RE.match(ref)
            if m and col_index(m.group(1)) == want:
                return cell        # ⚠️ 있으면 그대로 쓴다 — 서식(s 속성)을 지키려고.
        new = ET.Element(f"{{{MAIN_NS}}}c", {"r": f"{col}{row_no}"})
        for cell in cells:
            m = _CELL_RE.match(cell.get("r") or "")
            if m and col_index(m.group(1)) > want:
                row.insert(list(row).index(cell), new)
                return new
        row.append(new)
        return new

    # ── 내보내기 ──────────────────────────────────────────────────────────

    def _force_recalc(self) -> None:
        """열 때 전부 다시 계산하게 한다. 위 머리말의 이유."""
        self._drop.add("xl/calcChain.xml")
        raw = self._src.read("xl/workbook.xml")
        text = raw.decode("utf-8")
        if "<calcPr" in text:
            text = re.sub(
                r"<calcPr\b([^/>]*)/?>",
                lambda m: "<calcPr%s fullCalcOnLoad=\"1\"/>"
                % re.sub(r'\s*fullCalcOnLoad="[^"]*"', "", m.group(1)),
                text, count=1,
            )
        else:
            text = text.replace("</workbook>", '<calcPr fullCalcOnLoad="1"/></workbook>')
        self._patched["xl/workbook.xml"] = text.encode("utf-8")

    # ── xlsm → xlsx ───────────────────────────────────────────────────────

    # 매크로가 들어간 통합문서와 안 들어간 통합문서는 **본문 형식 이름만** 다르다.
    WORKBOOK_MACRO = "application/vnd.ms-excel.sheet.macroEnabled.main+xml"
    WORKBOOK_PLAIN = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
    )
    VBA_PART = "application/vnd.ms-office.vbaProject"

    def _strip_macros(self) -> bool:
        """매크로 흔적을 걷어 **엑셀이 여는 xlsx** 로 만든다. 걷을 것이 있었으면 True.

        xlsm 과 xlsx 의 차이는 셋뿐이다:

            1. `xl/vbaProject.bin` (그리고 서명이 있으면 그것도)
            2. `[Content_Types].xml` 의 그 부품 선언과 **본문 형식 이름**
            3. `xl/_rels/workbook.xml.rels` 의 vbaProject 관계

        셋을 걷으면 나머지는 그대로 xlsx 다. 시트도 서식도 도형도 안 건드린다.

        ⚠️ **부품이 없어도 형식 이름은 남을 수 있다.** 전에는 `vbaProject.bin` 이
           없으면 여기서 그냥 빠져나갔는데, 그러면 `[Content_Types].xml` 에
           `…sheet.macroEnabled.main+xml` 이 그대로 남는다. 그 파일을 `.xlsx`
           이름과 xlsx MIME 으로 내려보내면 **엑셀이 「손상된 파일」이라고 한다.**

           실제로 그랬다(담당부서 신고, 2026-09-03). [IPO,혐의심사조서] 서식은
           매크로 없이 `.xlsm` 으로 저장돼 있어 부품이 없고 형식 이름만 남아
           있었다 — 그래서 그 단추만 깨진 파일을 내려보냈다.
           ([일반심사조서] 서식에는 부품이 있어 멀쩡히 걷혔다.)

           그래서 **부품 유무와 상관없이 형식 이름을 먼저 바로잡는다.**

        ⚠️ 매크로는 **정말로 사라진다.** 되돌릴 수 없다. 부르는 쪽이 그것을
           알고 부르게 하려고 이름에 strip 을 넣었다.
        """
        vba = [n for n in self._names if "vbaProject" in n]
        types = self._src.read("[Content_Types].xml").decode("utf-8")
        rels_path = "xl/_rels/workbook.xml.rels"
        rels = self._src.read(rels_path).decode("utf-8")

        changed = self.WORKBOOK_MACRO in types or bool(vba)
        if not changed:
            return False

        self._drop.update(vba)
        # 본문 형식 이름을 바꾸고(그래야 엑셀이 xlsx 로 연다)
        types = types.replace(self.WORKBOOK_MACRO, self.WORKBOOK_PLAIN)
        # vbaProject 부품 선언을 지운다
        types = re.sub(r"<Override[^>]*vbaProject[^>]*/>", "", types)
        # ⚠️ `Extension="bin"` 은 매크로만 쓰는 것이 아니다 — **인쇄설정**
        #    (`printerSettings*.bin`)도 .bin 이다. 부품이 남아 있는데 선언을
        #    지우면 그것대로 못 여는 파일이 된다. 남은 .bin 이 없을 때만 지운다.
        keep = [n for n in self._names if n.lower().endswith(".bin") and n not in self._drop]
        if not keep:
            types = re.sub(r'<Default[^>]*Extension="bin"[^>]*/>', "", types)
        self._patched["[Content_Types].xml"] = types.encode("utf-8")

        rels = re.sub(r"<Relationship[^>]*vbaProject[^>]*/>", "", rels)
        self._patched[rels_path] = rels.encode("utf-8")
        return True

    def to_bytes(self, *, strip_macros: bool = False) -> bytes:
        for sheet, (tree, _) in self._trees.items():
            buf = BytesIO()
            tree.write(buf, xml_declaration=True, encoding="UTF-8")
            self._patched[self._sheet_path[sheet]] = buf.getvalue()
        self._force_recalc()
        if strip_macros:
            self._strip_macros()

        out = BytesIO()
        # ⚠️ 원본의 항목 **순서와 압축 방식**을 그대로 따른다. [Content_Types].xml 이
        #    맨 앞에 없으면 엑셀이 못 여는 경우가 있다.
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for info in self._src.infolist():
                if info.filename in self._drop:
                    continue
                data = self._patched.get(info.filename)
                if data is None:
                    data = self._src.read(info.filename)   # 손 안 댄 것은 그대로
                # ⚠️ 원본 ZipInfo 를 그대로 넘기면 writestr 이 그 위치값을 새 파일 기준으로 바꿔, 이후 원본 읽기가 깨진다(2026-10-15)
                zf.writestr(copy.copy(info), data)
        return out.getvalue()
