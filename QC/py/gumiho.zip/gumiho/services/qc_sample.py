"""[품감] 개별감사 샘플 선정(개발) — 회계법인 사전제출자료 「2-3. 외부감사 수행회사 현황」 읽기와
인뎁스 조서의 입력 칸 채우기 (2026-10-14, 개발서버 전용).

## 열은 **머리 이름으로** 찾는다

사전제출자료는 회계법인이 채워 보내는 엑셀이라 열이 한두 칸씩 밀려 온다(실제로 담당부서가
붙여 준 판에는 「해당 회사에서 사용하는 회계(기장)시스템」 열이 하나 더 끼어 있다).
그래서 글자 자리(C·N·AC …)를 코드에 박지 않는다 — 「회사명」 칸이 있는 줄을 머리로 보고,
그 아래 회사명이 빈 줄들을 하위 머리로 읽어 열마다 이름을 만든다. 화면의 슬라이서도
이 이름 목록에서 나온다(사용자 지정: 「사전제출자료(서버에 올린 것)의 행열 정보를 기준으로」).

`roles` 는 화면이 기본 슬라이서·회사 찾기에 쓰는 열 몇 개의 이름표다. 못 찾으면 그 역할이
빠질 뿐 나머지는 그대로 나간다(`warnings` 에 적는다).

## 서버에 남기지 않는다

올린 파일은 메모리에서 읽고 버린다 — 회사 목록·보수·감사시간이 든 자료다.
"""
from __future__ import annotations

import re
import zipfile
from datetime import date, datetime
from io import BytesIO
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

MAX_BYTES = 10 * 1024 * 1024
MAX_ROWS = 3000

# 한 엑셀에 세 시트가 함께 올 수 있다(사용자 지정 2026-10-14). 시트 이름의 글자로 가린다 —
# 번호(2-3·2-8·2-10)보다 이름 글자를 먼저 본다(「2-1」이 「2-10」 안에 들어가는 따위를 피한다).
SHEETS: dict[str, tuple[str, ...]] = {
    "s23": ("외부감사수행회사", "2-3"),
    "s28": ("감사조서자체점검", "2-8"),
    "s210": ("담당이사교체", "2-10"),
    "s410": ("비감사서비스", "비감사용역", "4-10"),
    "s83": ("사후심리", "8-3"),
}
# 4-10·8-3 은 양식이 회계법인마다 다를 수 있어 못 읽어도 나머지 대사는 한다
OPTIONAL = ("s410", "s83")
SHEET_TITLES = {"s23": "2-3. 외부감사 수행회사 현황", "s28": "2-8. 감사조서 자체점검 결과",
                "s210": "2-10. 담당이사 교체현황", "s410": "4-10. 비감사서비스 수행내역",
                "s83": "8-3. 사후심리 실시내역"}

# 역할 → 머리 이름(공백 없앤 것, 묶음은 「·」)에 거는 식. **위에서부터 처음 맞는 열 하나**를 잡는다.
ROLES: dict[str, list[tuple[str, str]]] = {
    "s23": [
        ("no", r"^(NO|번호)\.?$"),
        ("year", r"^사업연도$"),
        ("company", r"^회사명$"),
        ("corp_no", r"법인등록번호"),
        ("biz_no", r"사업자등록번호"),
        ("bookkeeping", r"기장|회계시스템"),
        ("designated", r"지정감사여부"),
        ("new_audit", r"신규감사여부"),
        ("predecessor", r"^전임감사인"),
        ("firm_years", r"^(수임후)?계속감사년수$"),
        ("branch", r"사업본부$|^소속$|^본부$"),
        ("partner", r"^담당이사(·성명)?$"),
        ("partner_years", r"^담당이사·계속감사년수$"),
        ("reviewer", r"^개별심리담당자(현황)?·성명$"),
        ("con_reviewer", r"^연결심리담당자(현황)?·성명$"),
        ("company_type", r"회사분류|상장등여부"),
        ("large_unlisted", r"대형비상장"),
        ("industry", r"^(회사)?업종$"),
        ("fiscal", r"^결산기$|^결산월$"),
        ("gaap", r"회계기준$"),
        ("assets", r"^자산총(계|액)(\(.*\))?$"),
        ("net_income", r"^당기순(이익|손익)(\(.*\))?$"),
        ("assets_prev", r"^직전(연도|사업연도)?자산총(계|액)"),
        ("consolidated", r"^연결여부$"),
        ("sme1200", r"1200"),
        ("report_date", r"^감사보고서일자?$"),
        ("opinion", r"^감사의견$"),
        ("audit_fee", r"^총?감사보수(\(.*\))?$"),
        ("nonaudit_fee", r"^비감사보수$"),
        ("archive", r"^개별감사조서취합완료일·전산"),
        ("warehouse", r"^개별감사조서취합완료일·서면"),
        ("con_archive", r"^연결감사조서취합완료일·전산"),
        ("con_warehouse", r"^연결감사조서취합완료일·서면"),
        ("con_report_date", r"^연결감사보고서일자?$"),
        ("inspection", r"감리/?조사"),
        ("subsidiaries", r"종속회사수"),
        ("review_done", r"^심리완료일$"),
        ("partner_close", r"^담당이사감사조서서명일·개별종결"),
        ("reviewer_close", r"^심리담당자감사조서서명일·개별종결"),
        ("partner_con_close", r"^담당이사감사조서서명일·연결종결"),
        ("reviewer_con_close", r"^심리담당자감사조서서명일·연결종결"),
        ("total_hours", r"^총(감사)?(투입)?시간|^감사투입시간"),
        ("partner_hours", r"^담당이사투입시간$"),
        ("reviewer_hours", r"^심리담당자투입시간$"),
        ("submit_date", r"^개별감사보고서제출일$"),
    ],
    "s28": [
        ("no", r"^(NO|번호)\.?$"),
        ("year", r"^사업연도$"),
        ("company", r"^회사명$"),
        ("place", r"보관장소"),
        ("reviewer", r"실사담당자|검토자|리뷰어|심리담당자"),
        ("report_date", r"^감사보고서일자?$"),
        ("collect_date", r"취합완료일"),
        ("timely", r"적시취합"),
        ("existence", r"실재성"),
        ("completeness", r"완전성"),
        ("physical", r"물리적통제"),
        ("access", r"접근기록"),
    ],
    "s210": [
        ("no", r"^(NO|번호)\.?$"),
        ("company", r"^회사명$"),
        ("assets_prev", r"자산총액"),
        ("large_unlisted", r"대형비상장"),
    ],
    # 4-10 · 8-3 은 양식을 아직 못 봐서 머리 이름을 넓게 잡는다(사용자 지정 2026-10-15). 관련 감사대상회사 열을 회사명보다 먼저.
    "s410": [
        ("no", r"^(NO|번호|연번)\.?$"),
        ("year", r"사업연도|회계연도|^연도$"),
        ("audit_client", r"^(?!.*관계)(?=.*(감사대상|피감사|관련.*회사))"),     # 「…와의 관계」는 관계 열
        ("company", r"회사명|고객(사)?명?|업체명|거래처|의뢰인|^상호$|법인명|용역대상|대상회사"),
        ("biz_no", r"사업자(등록)?번호"),
        ("relation", r"관계"),
        ("service", r"(용역|업무|서비스)(의)?(내용|종류|명|구분|유형|범위)|^비감사(서비스|용역)$|^용역$"),
        # 비감사 보수 열을 먼저, 없으면 보수·금액 아무 열 — 비율(%)·「대비」 열은 빼고(사용자 질문 2026-10-15: 「보수 0백만원」)
        ("fee", r"^(?!.*(비율|율$|%|대비)).*비감사.*(보수|금액|수수료|대가)"),
        ("fee_any", r"^(?!.*(비율|율$|%|대비)).*(보수|금액|수수료|대가)"),
        ("period", r"기간"),
        ("partner", r"담당이사|수행이사|책임자"),
    ],
    "s83": [
        ("no", r"^(NO|번호|연번)\.?$"),
        ("year", r"사업연도|회계연도|^연도$|대상연도"),
        ("company", r"회사명|피감사|대상회사|^법인명$"),
        ("partner", r"담당이사|업무수행이사"),
        ("post_reviewer", r"(사후)?심리(담당)?(자|이사)?(성명)?$|검토자|심리위원|심리담당|사후심리자"),
        ("post_date", r"(실시|심리|검토)(일|일자|완료일)$|^일자$"),
        ("result", r"결과|지적|의견"),
    ],
}
# 화면이 기본으로 쓰는 것. 없으면 경고만 한다.
NEEDED = ("company", "year", "partner", "gaap", "consolidated", "opinion")
FY_LABEL = re.compile(r"(?:FY|회계연도|사업연도)?\s*'?(\d{4})(?:년|년도)?$", re.I)


class PresubmitError(ValueError):
    """사용자가 읽고 고칠 수 있는 문장."""


def _text(value: Any) -> str:
    """머리 글자 정리 — 줄바꿈은 붙여 쓰되(「사업\\n연도」→「사업연도」) 앞뒤에 빈칸이
    있었으면 한 칸으로(「개별감사조서 \\n취합완료일」→「개별감사조서 취합완료일」)."""
    if value is None:
        return ""
    s = str(value).replace("\r", "")
    s = re.sub(r"[ \t]*\n[ \t]*", lambda m: " " if m.group(0).strip("\n") else "", s)
    return re.sub(r"\s+", " ", s).strip()


def _key(label: str) -> str:
    return re.sub(r"\s+", "", label)


def _value(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, (int, float)):
        return v
    s = re.sub(r"\s+", " ", str(v)).strip()
    return s or None


def _find_sheet(wb: Any, kind: str) -> Any | None:
    for hint in SHEETS[kind]:
        for ws in wb.worksheets:
            title = ws.title.replace(" ", "")
            if hint.isascii():
                # 번호는 앞머리로만 본다 — 「2-1」 이 「2-10」 에 걸리지 않게 뒤에 숫자가 오면 안 된다.
                if re.match(rf"^{re.escape(hint)}(?!\d)", title):
                    return ws
            elif hint in title:
                return ws
    return None


# 4-10·8-3 은 회계법인마다 머리 이름이 달라(「회사명(용역대상)」·「업체명」·「거래처」·「의뢰인」 …) 넓게 —
# 「…와의 관계」 같은 설명 열, 긴 제목·안내 글은 빼고(사용자 지정 2026-10-15)
_NAME_HEAD = {"s410": re.compile(r"^(?!.*관계)(?=.{2,20}$).*((회사|고객|업체|거래처|법인)(명|사)|의뢰인|상호|용역대상|피감사)"),
              "s83": re.compile(r"^(?!.*관계)(?=.{2,20}$).*((회사|법인)명|피감사|대상회사)")}


def _header_row(ws: Any, kind: str = "") -> tuple[int, int] | None:
    pat = _NAME_HEAD.get(kind)
    for r in range(1, min(ws.max_row, 20) + 1):
        for c in range(1, min(ws.max_column, 40) + 1):
            k = _key(_text(ws.cell(r, c).value))
            if k == "회사명" or (pat is not None and pat.match(k)):
                return r, c
    return None


def _parse_sheet(ws: Any, kind: str) -> dict[str, Any]:
    found = _header_row(ws, kind)
    if not found:
        raise PresubmitError(f"「{ws.title}」 시트에서 「회사명」 머리를 찾지 못했습니다.")
    head, name_col = found
    width = ws.max_column

    # 병합: 칸 → (왼쪽 위 행, 열, 가로 폭, 세로로 덮인 칸인지)
    merged: dict[tuple[int, int], tuple[int, int, int]] = {}
    for rng in ws.merged_cells.ranges:
        for rr in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                merged[(rr, c)] = (rng.min_row, rng.min_col, rng.max_col - rng.min_col + 1)

    def is_sub_header(r: int) -> bool:
        """하위 머리 줄인가 — 회사명 칸이 비었고, 글이 든 칸 중 하나라도 **바로 윗칸이 묶음 머리**
        (가로 병합)이거나 병합되지 않은 칸 아래에 있다. 세로 병합으로 덮인 칸 아래에만
        글이 있으면(2-10 의 「대형비상장 여부」 아래 「여/부」 같은 목록 값) 머리가 아니다."""
        if ws.cell(r, name_col).value not in (None, ""):
            return False
        hit = False
        for c in range(1, width + 1):
            if ws.cell(r, c).value in (None, ""):
                continue
            above = merged.get((r - 1, c))
            if above is None or above[2] > 1:
                hit = True     # 묶음 머리(가로 병합) 아래, 또는 병합 없이 적은 하위 이름(붙여 넣은 판)
        return hit

    rows = [head]
    r = head + 1
    while r <= min(ws.max_row, head + 3) and is_sub_header(r):
        rows.append(r)
        r += 1
    data_start = r

    grid: dict[tuple[int, int], str] = {}
    span: dict[tuple[int, int], int] = {}
    for rr in rows:
        for c in range(1, width + 1):
            m = merged.get((rr, c))
            if m and m[0] != rr:
                continue          # 세로 병합의 아래 칸은 비워 둔다(같은 이름 겹침 방지)
            if m:
                grid[(rr, c)] = _text(ws.cell(m[0], m[1]).value)
                span[(rr, c)] = m[2]
            else:
                grid[(rr, c)] = _text(ws.cell(rr, c).value)

    columns: list[dict[str, Any]] = []
    for c in range(1, width + 1):
        parts: list[str] = []
        for i, rr in enumerate(rows):
            t = grid.get((rr, c), "")
            if not t or t in parts:
                continue
            # 맨 윗줄의 큰 묶음(세 칸 이상 — 피감사회사현황·연결현황·감사수행 현황 …)은 이름에서 뺀다 —
            # 그 아래 이름만으로 뜻이 서고, 붙이면 슬라이서 이름이 길어지기만 한다.
            if i == 0 and span.get((rr, c), 1) >= 3 and any(grid.get((x, c)) for x in rows[1:]):
                continue
            parts.append(t)
        if not parts:
            continue
        columns.append({"col": c, "letter": get_column_letter(c), "label": " · ".join(parts)})

    roles: dict[str, str] = {}
    for role, pattern in ROLES[kind]:
        for col in columns:
            key = _key(col["label"])
            if role == "branch" and "심리" in key:
                continue
            if re.search(pattern, key, re.I) and col["letter"] not in roles.values():
                roles[role] = col["letter"]
                col["role"] = role
                break
    if kind == "s210":
        # 연도별 담당이사 열: 「담당이사 성명 · FY2017」 → fy:2017
        for col in columns:
            last = col["label"].split(" · ")[-1].strip()
            m = FY_LABEL.fullmatch(last.replace(" ", ""))
            if m and "role" not in col:
                col["role"] = f"fy:{m.group(1)}"
                roles[col["role"]] = col["letter"]

    out_rows: list[dict[str, Any]] = []
    name_letter = get_column_letter(name_col)
    in_notes = False
    skipped: list[int] = []
    # 사업연도 칸이 빈 줄은 위 줄의 사업연도를 이어받는다(사용자 지정 2026-10-15) — 「당기」를 첫 줄에만 적거나 세로로 병합해도 당기,
    # 빈 줄 뒤에 「전기」가 나오면 그 아래는 전기.
    year_letter, last_year = roles.get("year"), None
    for rr in range(data_start, ws.max_row + 1):
        values = {}
        for col in columns:
            v = _value(ws.cell(rr, col["col"]).value)
            if v is not None:
                values[col["letter"]] = v
        if not values.get(name_letter):
            # 회사명은 없는데 다른 칸(연번 말고)에 값이 있으면 빠뜨린 줄일 수 있다 — 완전성 점검에 알린다.
            if not in_notes and any(k not in (name_letter, "A") for k in values):
                skipped.append(rr)
            continue
        if _is_note(values, name_letter):
            in_notes = True
            continue
        if in_notes and set(values) <= {name_letter, "A"}:
            continue        # 안내 줄이 이어지는 중(글이 회사명 칸에만 있는 줄)
        if year_letter:
            if values.get(year_letter) not in (None, ""):
                last_year = values[year_letter]
            elif last_year is not None:
                values[year_letter] = last_year
        out_rows.append({"row": rr, "values": values})
        if len(out_rows) >= MAX_ROWS:
            break

    # 금액 단위 — 머리 위·머리 안의 「(단위: 원)」 따위(없으면 None)
    unit = None
    for rr in range(1, data_start):
        for c in range(1, width + 1):
            m = re.search(r"단위\s*[:：]?\s*(억원|백만원|천원|원)", _text(ws.cell(rr, c).value))
            if m:
                unit = m.group(1)
                break
        if unit:
            break
    return {
        "sheet": ws.title, "header_rows": rows, "data_start": data_start,
        "columns": [{k: v for k, v in c.items() if k != "col"} for c in columns],
        "roles": roles, "rows": out_rows, "skipped_rows": skipped[:200], "unit": unit,
    }


_OLE = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def _open(raw: bytes, name: str = "") -> Any:
    """.xlsx/.xlsm 은 openpyxl 로, 옛 엑셀(.xls)은 xlrd 로 읽어 **같은 모양**(openpyxl 통합문서)으로 넘긴다.
    회계법인이 보내 오는 사전제출자료에 .xls 가 섞여 온다(사용자 확인 2026-10-14)."""
    label = name or "파일"
    if not raw or len(raw) > MAX_BYTES:
        raise PresubmitError(f"{label}: 비었거나 10MB 를 넘습니다.")
    if raw.startswith(_OLE):
        try:
            return _xls_book(raw)
        except Exception as exc:  # noqa: BLE001
            raise PresubmitError(f"{label}: 옛 엑셀(.xls)을 열지 못했습니다({exc}). 엑셀에서 .xlsx 로 저장해 올려 주세요.") from exc
    if not zipfile.is_zipfile(BytesIO(raw)):
        head = raw[:2048].lstrip().lower()
        if head.startswith(b"<") or b"<table" in head:
            raise PresubmitError(f"{label}: 이름은 엑셀이지만 속은 웹페이지(HTML) 형식입니다. "
                                 "엑셀에서 열어 「다른 이름으로 저장 → Excel 통합 문서(.xlsx)」로 저장해 올려 주세요.")
        raise PresubmitError(f"{label}: 엑셀 파일이 아닙니다(.xlsx·.xlsm·.xls 만 읽습니다).")
    try:
        # 병합 정보가 필요해 read_only 를 쓰지 않는다. 수식은 저장된 값으로 읽는다.
        return load_workbook(BytesIO(raw), data_only=True)
    except Exception as exc:  # noqa: BLE001
        raise PresubmitError(f"{label}: 엑셀을 열지 못했습니다: {exc}") from exc


def _xls_book(raw: bytes) -> Any:
    """옛 엑셀 → openpyxl 통합문서(값·날짜·병합만). 서식은 옮기지 않는다 — 읽기만 하므로 필요 없다."""
    import xlrd
    from openpyxl import Workbook as NewBook
    try:
        book = xlrd.open_workbook(file_contents=raw, formatting_info=True)   # 병합 정보는 이것이 있어야 온다
    except NotImplementedError:
        book = xlrd.open_workbook(file_contents=raw)
    wb = NewBook()
    wb.remove(wb.active)
    used: set[str] = set()
    for sh in book.sheets():
        title = re.sub(r"[\\/*?:\[\]]", "_", sh.name)[:31] or "Sheet"
        while title in used:
            title = title[:28] + f"_{len(used)}"
        used.add(title)
        ws = wb.create_sheet(title=title)
        for r in range(sh.nrows):
            for c in range(sh.ncols):
                cell = sh.cell(r, c)
                if cell.ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK, xlrd.XL_CELL_ERROR):
                    continue
                v = cell.value
                if cell.ctype == xlrd.XL_CELL_DATE:
                    try:
                        v = xlrd.xldate.xldate_as_datetime(v, book.datemode)
                    except Exception:  # noqa: BLE001 — 날짜로 못 바꾸면 숫자 그대로
                        pass
                elif cell.ctype == xlrd.XL_CELL_BOOLEAN:
                    v = bool(v)
                ws.cell(r + 1, c + 1, v)
        for rlo, rhi, clo, chi in getattr(sh, "merged_cells", []) or []:
            if rhi - rlo > 1 or chi - clo > 1:
                ws.merge_cells(start_row=rlo + 1, start_column=clo + 1, end_row=rhi, end_column=chi)
    return wb


def _collect(wb: Any, have: dict[str, Any], *, fallback: bool) -> list[str]:
    """이 통합문서에서 아직 없는 시트(2-3·2-8·2-10)를 찾아 `have` 에 채우고, 찾은 것을 돌려준다."""
    got = []
    for kind in SHEETS:
        if kind in have:
            continue
        ws = _find_sheet(wb, kind)
        if ws is not None:
            try:
                have[kind] = _parse_sheet(ws, kind)
            except PresubmitError as exc:
                if kind not in OPTIONAL:
                    raise
                continue            # 못 읽은 4-10·8-3 은 말없이 건너뛴다(사용자 지정 2026-10-15 — 경고 띠 필요 없음)
            got.append(kind)
    if fallback and "s23" not in have:
        # 시트 이름이 달라도 「회사명」 머리가 있는 첫 시트를 2-3 으로 본다(한 시트만 올린 경우).
        taken = {p["sheet"] for p in have.values()}
        for ws in wb.worksheets:
            if ws.title not in taken and _header_row(ws):
                have["s23"] = _parse_sheet(ws, "s23")
                got.append("s23")
                break
    return got


def _with_checks(have: dict[str, Any], fy: int | None, docs: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    if "s23" not in have:
        raise PresubmitError("「2-3. 외부감사 수행회사 현황」 시트를 찾지 못했습니다.")
    out = dict(have["s23"])
    out["warnings"] = [f"「{_ROLE_NAMES[k]}」 열을 찾지 못했습니다." for k in NEEDED if k not in out["roles"]]
    out["others"] = {k: v for k, v in have.items() if k != "s23"}
    from gumiho.services import qc_sample_checks
    out["checks"] = qc_sample_checks.run(have, fy=fy, docs=docs)
    return out


_NOTE = re.compile(r"^\(?\s*기재요령|^\(.*\)$|^\d+\.\s|^[※*]|\s:\s")


def _is_note(values: dict[str, Any], name_letter: str) -> bool:
    """양식 아래의 안내 줄(「(기재요령)」·「1. 적시 취합 : …」)은 회사가 아니다 — 회사명 칸에만 글이 있고
    그 글이 안내 꼴이거나, 다른 칸이 모두 비었는데 글이 긴 줄."""
    name = str(values.get(name_letter) or "")
    rest = [k for k in values if k != name_letter and k != "A"]
    if re.match(r"^\(?\s*기재\s*요령", name):
        return True
    return (not rest and (bool(_NOTE.search(name)) or len(name) > 40)) or bool(_NOTE.search(name) and len(name) > 30)


def parse_presubmit(raw: bytes, *, fy: int | None = None, name: str = "") -> dict[str, Any]:
    """2-3 시트(샘플 선정용)를 맨 위에 두고, 같은 파일에 2-8·2-10 이 있으면 `others` 에 싣고
    세 시트를 맞춰 본 결과를 `checks` 에 싣는다(`qc_sample_checks`)."""
    have: dict[str, Any] = {}
    _collect(_open(raw, name), have, fallback=True)
    return _with_checks(have, fy)


def parse_many(files: list[tuple[str, bytes]], *, fy: int | None = None,
               docs: list[dict[str, Any]] | None = None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """엑셀 여러 개 — 시트가 여러 파일에 흩어져 있어도 모은다(먼저 나온 것이 이긴다).
    `(대사 결과, 파일별 요약)`. 세 시트 어디에도 안 맞는 엑셀은 시트 이름만 요약에 남긴다."""
    have: dict[str, Any] = {}
    summary = []
    books = []
    for name, raw in files:
        wb = _open(raw, name)
        books.append((name, wb))
        got = _collect(wb, have, fallback=False)
        summary.append({"name": name, "kind": "엑셀", "sheets": wb.sheetnames,
                        "found": [SHEET_TITLES[k] for k in got]})
    if "s23" not in have:
        for (name, wb), row in zip(books, summary):
            got = _collect(wb, have, fallback=True)
            if got:
                row["found"] += [SHEET_TITLES[k] for k in got]
                break
    return _with_checks(have, fy, docs), summary


_ROLE_NAMES = {
    "company": "회사명", "year": "사업연도", "partner": "담당이사", "gaap": "적용한 회계기준",
    "consolidated": "연결 여부", "opinion": "감사의견",
}


# ── 인뎁스 조서의 입력 칸 ─────────────────────────────────────────────────

INPUT_SHEETS = ("심사조서(일반용)입력문서", "심사조서(IFRS)입력문서")
OVERVIEW = "회사개요(공통)"


def fiscal_span(base_dt: str) -> str:
    """결산일자 → 「25/1 - 25/12」(서식의 회계연도 괄호 안 모양)."""
    y, m = int(base_dt[:4]), int(base_dt[4:6])
    sy, sm = (y, 1) if m == 12 else (y - 1, m + 1)
    return f"{sy % 100:02d}/{sm} - {y % 100:02d}/{m}"


def with_span(current: Any, span_text: str) -> str:
    """「제XX기(…)」의 괄호만 바꾼다 — 기수는 사람이 넣는 자리라 그대로 둔다."""
    s = str(current or "").strip()
    if "(" in s:
        return re.sub(r"\(.*\)", f"({span_text})", s, count=1)
    return f"{s or '제XX기'}({span_text})"


def _labels(raw: bytes) -> dict[str, dict[str, tuple[int, Any]]]:
    """입력 시트마다 {B열 이름표(공백 없앰): (행, C열 지금 값)}."""
    wb = load_workbook(BytesIO(raw), read_only=True, data_only=False)
    out: dict[str, dict[str, tuple[int, Any]]] = {}
    try:
        for name in INPUT_SHEETS:
            if name not in wb.sheetnames:
                continue
            seen: dict[str, tuple[int, Any]] = {}
            for r, row in enumerate(wb[name].iter_rows(min_row=1, max_row=40, min_col=2, max_col=3,
                                                         values_only=True), start=1):
                b, c = (row + (None, None))[:2]
                k = _key(_text(b))
                if k and k not in seen:
                    seen[k] = (r, c)
            out[name] = seen
        if OVERVIEW in wb.sheetnames:
            ws = wb[OVERVIEW]
            cells = {}
            for r, row in enumerate(ws.iter_rows(min_row=44, max_row=49, min_col=7, max_col=8,
                                                 values_only=True), start=44):
                g, h = (row + (None, None))[:2]
                cells[_key(_text(g)).rstrip(":")] = (r, h)
            out[OVERVIEW] = cells
    finally:
        wb.close()
    return out


def fill_inputs(patch: Any, raw: bytes, extra: dict[str, Any]) -> list[str]:
    """심사팀장·일정·회계연도·감사보고서일·연결 여부·업종을 입력 시트에 넣는다.

    ⚠️ 이름표(B열)를 대조한 칸에만, **수식이 아닌 칸**에만 쓴다. 서식이 바뀌어 줄이 밀려도
       엉뚱한 칸을 덮지 않는다. 값을 안 준 항목은 서식에 있던 그대로 둔다.
    """
    done: list[str] = []
    maps = _labels(raw)
    base_dt = str(extra.get("base_dt") or "")
    plan = [
        ("심사팀장명", (extra.get("lead") or "").strip() or None),
        ("심사일정", (extra.get("schedule") or "").strip() or None),
        ("감사보고서일", (extra.get("report_date") or "").strip() or None),
        ("업종명", (extra.get("industry") or "").strip() or None),
    ]
    if extra.get("consolidated"):
        plan.append(("연결F/S공시여부", "여"))
    for sheet, rows in maps.items():
        if sheet == OVERVIEW:
            continue
        todo = list(plan)
        if re.fullmatch(r"\d{8}", base_dt) and "회계연도" in rows:
            todo.append(("회계연도", with_span(rows["회계연도"][1], fiscal_span(base_dt))))
        for label, value in todo:
            if value is None or label not in rows:
                continue
            r, current = rows[label]
            if isinstance(current, str) and current.startswith("="):
                continue
            patch.set(sheet, f"C{r}", value)
            done.append(f"{sheet}!C{r}")
    ov = maps.get(OVERVIEW) or {}
    member = (extra.get("member") or "").strip()
    if member and "담당자명" in ov:
        patch.set(OVERVIEW, f"H{ov['담당자명'][0]}", member)
        done.append(f"{OVERVIEW}!H{ov['담당자명'][0]}")
    if "작성일" in ov:
        today = extra.get("today") or f"{date.today().year}. {date.today().month}. {date.today().day}."
        patch.set(OVERVIEW, f"H{ov['작성일'][0]}", today)
        done.append(f"{OVERVIEW}!H{ov['작성일'][0]}")
    return done


# ── 명부: 직전개별선정회사 · 차기수임신고내역 (사용자 지정 2026-10-14) ─────────────────
#
# 직전 감사인감리에서 개별대상으로 고른 회사는 되도록 다시 고르지 않는다. 차기에 같은 법인이 수임신고하지 않은
# 회사를 고르면 이행보고를 받기 어렵다. 그래서 회사를 고를 때 두 명부와 맞춰 알린다.
# 서식이 정해져 있지 않아 머리 이름으로 찾는다 — 회계법인(감사인) 열이 없으면 그 명부는 모든 법인에 적용.

_REG_COLS = [
    ("firm", r"^(감사인|회계법인)(명|이름)?$|^감사인\(회계법인\)$|^회계법인명$"),
    ("company", r"^(피감사)?회사(명)?$|^피감사회사(명)?$|^감사대상회사(명)?$|^회사명칭$|^업체명$"),
    ("corp_no", r"법인등록번호"),
    ("biz_no", r"^사업자등록번호$|^사업자번호$"),
    ("year", r"^(사업|회계|감리|선정|수임)?연도$|^기수$|^사업연도$|^연도별감사인$"),
    ("kind", r"^감리구분$|^구분$|^심사감리구분$"),
    ("period", r"^대상연월$|^결산연월$"),
    ("note", r"^비고$|선정사유|^메모$"),
    ("finding", r"혐의감리"),
    ("violation", r"법규위반"),
    ("cancel", r"^해약일(자)?$|^해지일(자)?$|^계약해지일$"),     # 해약한 회사는 완전성 대사에서 뺀다(사용자 확인 2026-10-15)
]


def parse_register(raw: bytes, name: str = "") -> dict[str, Any]:
    wb = _open(raw, name)
    items: list[dict[str, Any]] = []
    for ws in wb.worksheets:
        head, cols = None, {}
        for r in range(1, min(ws.max_row, 15) + 1):
            # 머리가 두 줄이고 세로로 병합된 칸(「혐의감리 발견 여부」)은 윗줄에 글이 있다 — 빈 칸은 윗줄 글로.
            keys = {c: _key(_text(ws.cell(r, c).value)) or (_key(_text(ws.cell(r - 1, c).value)) if r > 1 else "")
                    for c in range(1, min(ws.max_column, 40) + 1)}
            found = {}
            for role, pat in _REG_COLS:
                for c, k in keys.items():
                    if k and re.search(pat, k) and c not in found.values():
                        found[role] = c
                        break
            if "company" in found:
                head, cols = r, found
                break
        if not head:
            continue
        last_firm = None
        for r in range(head + 1, ws.max_row + 1):
            company = _value(ws.cell(r, cols["company"]).value)
            if "firm" in cols and _value(ws.cell(r, cols["firm"]).value):
                last_firm = _value(ws.cell(r, cols["firm"]).value)
            if not company or _is_note({"C": company}, "C"):
                continue
            rec = {k: _value(ws.cell(r, c).value) for k, c in cols.items()}
            rec = {k: v for k, v in rec.items() if v not in (None, "", "#N/A")}
            if "firm" in cols and not rec.get("firm") and last_firm:
                rec["firm"] = last_firm        # 감사인명은 법인 첫 줄에만 적는 명부가 있다(아래 줄은 비움)
            if "year" not in rec:
                # 머리 없는 연도 칸(「2023년」)
                for c in range(1, min(ws.max_column, 40) + 1):
                    m = re.fullmatch(r"(?:FY)?\s*(20\d{2})\s*년?(?:도)?", str(ws.cell(r, c).value or "").strip())
                    if m and c != cols.get("company"):
                        rec["year"] = m.group(0)
                        break
            rec["company"] = str(company)
            rec["sheet"], rec["row"] = ws.title, r
            if not rec.get("kind") and re.search(r"품감|배정법인", f"{ws.title} {ws.cell(1, 1).value or ''}"):
                rec["kind"] = "감사인감리(품감) 선정"
            y = re.search(r"(?:FY)?\s*(20\d{2})", str(rec.get("year") or ""))
            if y:
                rec["fy"] = int(y.group(1))
            items.append(rec)
    if not items:
        raise PresubmitError("명부에서 「회사명」 열을 찾지 못했습니다(머리에 「회사명」·「피감사회사명」이 있어야 합니다).")
    return {"name": name, "items": items, "firms": sorted({str(i.get("firm") or "") for i in items} - {""})}


def _firm_key(v: Any) -> str:
    return re.sub(r"회계\s*법인|\(주\)|주식회사|\s", "", str(v or ""))


def register_for(reg: dict[str, Any] | None, firm: str) -> list[dict[str, Any]]:
    """그 회계법인 몫 — 법인 열이 빈 줄(모든 법인에 적용)도 함께."""
    if not reg:
        return []
    fk = _firm_key(firm)
    out = []
    for i in reg.get("items") or []:
        ik = _firm_key(i.get("firm"))
        if not ik or (fk and (ik == fk or fk in ik or ik in fk)):
            out.append(i)
    return out
