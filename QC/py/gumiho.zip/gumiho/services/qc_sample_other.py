"""[품감] 개별선정(개발) — 「기타 대사」: 첨부 자료(감사시간집계표 등)를 사전제출자료 2-3 과 맞춘다 (2026-10-15).

    엑셀(xlsx·xls)   시트마다 표 하나 — 병합된 머리는 펼쳐서 읽는다
    한글(hwpx)       문서 안의 표들(`xcheck.hwpx_reader`)
    워드(docx)       MarkItDown 이 만든 마크다운 표
    PDF              표로는 읽지 않는다 — 감사보고서면 보고서일·의견·업무수행이사만(`qc_sample_docs.facts`)

표마다 **머리 이름으로** 회사명·감사보고서일·담당이사·계속감사년수·감사시간(총·이사·심리)·감사보수·감사의견·심리담당자 열을
찾는다(서식이 회계법인마다 달라 열 자리를 박지 않는다). 회사는 `qc_sample_checks.company_key` 로 2-3 과 이어 붙인다.

결과는 `items`(다른 것) · `ok`(같은 것 — 화면이 접어 둔다) · `summary`(항목별 일치·다름 건수) · `files`(파일별로 읽은 표 수).
모델을 쓰지 않는다 — 회사 문서를 밖으로 보내지 않는다.
"""
from __future__ import annotations

import re
from io import BytesIO
from typing import Any

from gumiho.services import qc_sample, qc_sample_checks as C, qc_sample_docs

MAX_ROWS = 5000
MAX_COLS = 80

FIELDS = {
    "report_date": "감사보고서일", "partner": "담당이사", "partner_years": "계속감사년수", "reviewer": "심리담당자",
    "total_hours": "총 감사시간", "partner_hours": "담당이사 투입시간", "reviewer_hours": "심리 투입시간",
    "audit_fee": "감사보수", "opinion": "감사의견",
}
_TOTAL_ROW = re.compile(r"^(합계|소계|총계|계|total|sum)$", re.I)


def _t(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v if v is not None else "")).strip()


def _k(v: Any) -> str:
    return re.sub(r"\s+", "", str(v if v is not None else ""))


def _role(key: str) -> str | None:
    """머리 이름(공백 없앰, 묶음은 「·」) → 역할."""
    if not key:
        return None
    if "시간" in key:
        if "이사" in key or "파트너" in key:
            return "partner_hours"
        if "심리" in key or "검토" in key or "eqcr" in key.lower():
            return "reviewer_hours"
        if re.search(r"총|합계|전체|투입시간$|감사시간$", key) or key.endswith("시간"):
            return "total_hours"
        return None
    if re.search(r"피감사회사|감사대상회사|업체명|^회사명|·회사명|^회사$|회사명$", key):
        return "company"
    if re.search(r"감사보고서일", key):
        return "report_date"
    if re.search(r"계속감사(년|연)수|연속감사|감사연차|계속연수", key):
        return "partner_years"
    if re.search(r"심리담당|검토자|eqcr|심리자|심리$", key, re.I):
        return "reviewer"
    if re.search(r"담당이사|업무수행이사|담당파트너|^이사$|·이사$", key):
        return "partner"
    if re.search(r"감사보수", key):
        return "audit_fee"
    if re.search(r"감사의견|^의견$", key):
        return "opinion"
    if re.search(r"사업연도|회계연도|^연도$|^기수$", key):
        return "year"
    return None


# ── 표 읽기 ────────────────────────────────────────────────────────────

def tables_from_file(raw: bytes, name: str) -> list[dict[str, Any]]:
    low = name.lower()
    if low.endswith((".xlsx", ".xlsm", ".xls")):
        wb = qc_sample._open(raw, name)
        out = []
        for ws in wb.worksheets:
            grid = [[ws.cell(r, c).value for c in range(1, min(ws.max_column, MAX_COLS) + 1)]
                    for r in range(1, min(ws.max_row, MAX_ROWS) + 1)]
            for rng in ws.merged_cells.ranges:           # 병합 머리는 펼친다(가로 묶음 머리가 아래 칸에 이름을 준다)
                top = ws.cell(rng.min_row, rng.min_col).value
                for r in range(rng.min_row, min(rng.max_row, len(grid)) + 1):
                    for c in range(rng.min_col, min(rng.max_col, MAX_COLS) + 1):
                        if r - 1 < len(grid) and c - 1 < len(grid[r - 1]) and grid[r - 1][c - 1] in (None, ""):
                            grid[r - 1][c - 1] = top if r == rng.min_row else (top if rng.max_row - rng.min_row < 2 and r <= 15 else None)
            out.append({"name": f"{name} › {ws.title}", "rows": grid})
        return out
    if low.endswith(".hwpx"):
        from gumiho.services.xcheck.hwpx_reader import read_hwpx
        doc = read_hwpx(bytes(raw), name)
        out = []
        for i, tb in enumerate(doc.all_tables(), start=1):
            grid = [["" for _ in range(tb.cols)] for _ in range(tb.rows)]
            for cell in tb.cells:
                for r in range(cell.r, min(cell.r + max(cell.rs, 1), tb.rows)):
                    for c in range(cell.c, min(cell.c + max(cell.cs, 1), tb.cols)):
                        grid[r][c] = cell.text.strip() if (r == cell.r or r < 3) else grid[r][c]
            out.append({"name": f"{name} › 표{i}", "rows": grid})
        return out
    return []


def tables_from_markdown(md: str, name: str) -> list[dict[str, Any]]:
    out, cur = [], []
    for line in (md or "").splitlines():
        s = line.strip()
        if s.startswith("|") and s.endswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                continue
            cur.append(cells)
        elif cur:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return [{"name": f"{name} › 표{i}", "rows": t} for i, t in enumerate(out, start=1)]


def map_table(table: dict[str, Any]) -> dict[str, Any] | None:
    """머리 줄을 찾아 열 역할을 붙인다. 회사명 열과 비교할 열이 하나 이상 있어야 표로 본다."""
    rows = table["rows"]
    for r in range(min(len(rows), 15)):
        width = len(rows[r])
        for depth in (2, 1):                         # 두 줄 머리를 먼저(묶음 · 아래 이름)
            if r + depth > len(rows):
                continue
            cols: dict[str, int] = {}
            for c in range(width):
                parts = []
                for d in range(depth):
                    v = _t(rows[r + d][c]) if c < len(rows[r + d]) else ""
                    if v and v not in parts and not isinstance(rows[r + d][c], (int, float)):
                        parts.append(v)
                role = _role("·".join(_k(p) for p in parts))
                if role and role not in cols:
                    cols[role] = c
            # 머리 첫 줄(r)에 회사명 머리가 있어야 한다 — 위의 빈 줄과 묶여 한 줄 일찍 잡히지 않게
            if "company" in cols and _t(rows[r][cols["company"]]) and len(set(cols) - {"company", "year"}) >= 1:
                return {"name": table["name"], "cols": cols, "start": r + depth, "rows": rows}
    return None


# ── 대사 ────────────────────────────────────────────────────────────────

def _num(v: Any) -> float | None:
    return C._num(v)


def _opinion(v: Any) -> str | None:
    return C._opinion(v)


def _same(field: str, a: Any, b: Any) -> tuple[bool, str]:
    """(같은가, 덧붙일 말)"""
    if field == "report_date":
        da, db = C.parse_date(a), C.parse_date(b)
        return (da == db, "") if da and db else (True, "")
    if field in ("partner", "reviewer"):
        if C.same_person(a, b):
            return True, ""
        return False, " — 비슷한 이름(표기 차이인지 확인)" if C.similar_person(a, b) else ""
    if field == "opinion":
        return _opinion(a) == _opinion(b), ""
    na, nb = _num(a), _num(b)
    if na is None or nb is None:
        return True, ""
    return abs(na - nb) < 0.5, ""


def _show(field: str, v: Any) -> str:
    if field == "report_date":
        d = C.parse_date(v)
        return d.isoformat() if d else _t(v)
    if isinstance(v, float) and v.is_integer():
        return f"{int(v):,}"
    if isinstance(v, (int, float)):
        return f"{v:,}"
    return _t(v)


def compare(s23: dict[str, Any], files: list[tuple[str, bytes]], *, fy: int | None = None) -> dict[str, Any]:
    roles = s23.get("roles") or {}
    recs = C._records(s23, "s23")
    fy = fy or C.guess_fy(recs, [])
    for r in recs:
        r["y"] = C.year_of(r.get("year"), fy) if r.get("year") not in (None, "") else fy
    by_key: dict[str, list[dict[str, Any]]] = {}
    for r in recs:
        by_key.setdefault(r["ckey"], []).append(r)

    items: list[dict[str, Any]] = []
    ok: list[dict[str, Any]] = []
    tally: dict[str, dict[str, int]] = {f: {"ok": 0, "diff": 0} for f in FIELDS}
    out_files = []

    def compare_row(src: str, row_no: Any, company: str, year_v: Any, values: dict[str, Any]) -> None:
        key = C.company_key(company)
        cands = by_key.get(key) or []
        y = C.year_of(year_v, fy) if year_v not in (None, "") else fy
        m = next((r for r in cands if r["y"] == y), None) or next((r for r in cands if r["y"] == fy), None) or (cands[0] if cands else None)
        where = f"{src} {row_no}행" if row_no else src
        if not m:
            items.append({"level": "참고", "code": "other_unmatched", "field": "", "title": "2-3 현황에 없는 회사",
                          "company": company, "year": year_v or "", "detail": "회사명 표기·누락 여부 확인", "refs": [where]})
            return
        for field, theirs in values.items():
            if field not in FIELDS or theirs in (None, ""):
                continue
            mine = m.get(field)
            if field == "reviewer":
                mine = m.get("reviewer") or m.get("con_reviewer")
            if mine in (None, ""):
                continue
            same, note = _same(field, mine, theirs)
            rec = {"code": f"other_{field}", "field": field, "company": m["name"], "year": m.get("year") or "",
                   "refs": [C._where(m), where]}
            if same:
                tally[field]["ok"] += 1
                ok.append({**rec, "level": "일치", "title": FIELDS[field], "detail": _show(field, mine)})
            else:
                tally[field]["diff"] += 1
                items.append({**rec, "level": "불일치", "title": f"{FIELDS[field]} 다름",
                              "detail": f"2-3 {_show(field, mine)} ↔ {src} {_show(field, theirs)}{note}"})

    for name, raw in files:
        low = name.lower()
        info: dict[str, Any] = {"name": name, "tables": 0, "rows": 0, "note": ""}
        try:
            tables = []
            if low.endswith((".xlsx", ".xlsm", ".xls", ".hwpx")):
                tables = tables_from_file(raw, name)
            if low.endswith(".docx"):
                from gumiho.services.review2.targets import _markitdown
                tables = tables_from_markdown(_markitdown(raw, ".docx"), name)
            for t in tables:
                mt = map_table(t)
                if not mt:
                    continue
                info["tables"] += 1
                cols = mt["cols"]
                for i in range(mt["start"], len(mt["rows"])):
                    row = mt["rows"][i]
                    company = _t(row[cols["company"]]) if cols["company"] < len(row) else ""
                    if not company or _TOTAL_ROW.match(_k(company)) or len(company) > 60:
                        continue
                    vals = {f: row[c] for f, c in cols.items() if f not in ("company", "year") and c < len(row)}
                    if not any(v not in (None, "") for v in vals.values()):
                        continue
                    info["rows"] += 1
                    compare_row(mt["name"], i + 1 if low.endswith((".xlsx", ".xlsm", ".xls")) else None, company,
                                row[cols["year"]] if "year" in cols and cols["year"] < len(row) else None, vals)
            # 감사보고서(PDF·한글·워드) — 보고서일·의견·업무수행이사
            if low.endswith((".pdf", ".hwpx", ".hwp", ".docx")):
                import asyncio
                text = asyncio.run(qc_sample_docs.read_text(raw, name)) if not _in_loop() else ""
                f = qc_sample_docs.facts(text) if text else {"type": "기타"}
                if f.get("type") == "감사보고서":
                    company, _ = qc_sample_docs.best_company(text, [r["name"] for r in recs])
                    if company:
                        info["report"] = True
                        compare_row(name, None, company, None,
                                    {"report_date": f.get("report_date"), "opinion": f.get("opinion"), "partner": f.get("partner")})
            if not info["tables"] and not info.get("report"):
                info["note"] = "회사명 열이 있는 표나 감사보고서를 찾지 못했습니다(머리에 「회사명」·「피감사회사」 등이 있어야 합니다)."
        except Exception as exc:  # noqa: BLE001 — 파일 하나가 안 읽혀도 나머지는 맞춘다
            info["note"] = f"읽지 못했습니다: {exc}"
        out_files.append(info)

    summary = [{"field": f, "label": FIELDS[f], **tally[f]} for f in FIELDS if tally[f]["ok"] or tally[f]["diff"]]
    return {"fy": fy, "items": items, "ok": ok, "summary": summary, "files": out_files}


def _in_loop() -> bool:
    import asyncio
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False
