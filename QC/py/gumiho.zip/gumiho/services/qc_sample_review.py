"""[품감] 개별선정(개발) — 인뎁스(상근용) 「1-1.요약BS」·「1-2.요약PL,CF,중요성」 비고 칸의 분석적 검토 문구(사용자 지정 2026-10-15).

감사보고서 원문(전자공시 XML)의 본표·주석에서 계정별 당기·전기 금액(`dart_accounts.account_values`)과
특수관계자 거래표를 읽어 **규칙으로** 문구를 만든다 — AI 모델은 쓰지 않는다(이 화면의 원칙).

  매출액     「전기 대비 상품매출 51억, 제품매출 32억 감소로 매출 68억 감소 · 특수관계자 매출: ○○ 103억」
  매출채권   「전기말 대비 15억 감소(매출 68억 감소 영향)」
  유형자산   「토지 107억, 건물 72억, 기계장치 69억(장부금액)」
  기타부채   「선수금 34억, 미지급금 22억」 …

금액은 억원(10억 이상은 정수, 그 아래는 소수 한 자리). 1억 미만 항목·변동은 적지 않는다. 읽지 못한 계정은 비워 둔다(짐작하지 않음).
"""
from __future__ import annotations

import re
from typing import Any

from lxml import etree

from gumiho.integrations.external.dart_accounts import UNIT, _before, _cells, account_values
from gumiho.integrations.external.dart_finance import SCALE, _label, amount

EOK = 100_000          # 천원 → 억원
MIN = 1 * EOK          # 1억 미만은 적지 않는다

SALES = ["매출액", "매출", "영업수익", "수익(매출액)"]
SALES_PARTS = ["제품매출", "상품매출", "공사수익", "공사매출", "용역매출", "용역수익", "분양수익", "분양매출", "임대수익", "임대료수익",
               "수수료수익", "기타매출", "부산물매출", "수출매출", "내수매출", "제품매출액", "상품매출액"]
COGS = ["매출원가", "영업비용"]
SGA = ["급여", "퇴직급여", "복리후생비", "감가상각비", "지급수수료", "광고선전비", "운반비", "경상연구개발비", "대손상각비", "지급임차료",
       "세금과공과", "여비교통비", "접대비", "보험료", "판매수수료", "외주용역비", "무형자산상각비", "사용권자산상각비", "수출제비용"]
NONOP_INC = ["이자수익", "배당금수익", "외환차익", "외화환산이익", "유형자산처분이익", "잡이익", "임대료수익", "지분법이익", "대손충당금환입"]
NONOP_EXP = ["이자비용", "외환차손", "외화환산손실", "기부금", "유형자산처분손실", "잡손실", "기타의대손상각비", "유형자산손상차손", "지분법손실"]
INVENTORY = ["상품", "제품", "반제품", "재공품", "원재료", "부재료", "저장품", "미착품", "미완성공사", "용지", "완성주택", "미분양주택"]
OTHER_CA = ["미수금", "미수수익", "선급금", "선급비용", "단기금융상품", "단기투자자산", "당기법인세자산", "계약자산"]
PPE = ["토지", "건물", "구축물", "기계장치", "건설중인자산", "차량운반구", "비품", "공기구비품", "공구와기구", "시설장치", "사용권자산", "선박", "항공기"]
INTANGIBLE = ["영업권", "개발비", "소프트웨어", "산업재산권", "회원권", "시설이용권", "기타의무형자산", "기타무형자산"]
OTHER_NCA = ["보증금", "임차보증금", "장기선급비용", "이연법인세자산", "투자부동산", "장기미수금", "장기금융상품", "관계기업투자", "종속기업투자"]
OTHER_CL = ["미지급금", "미지급비용", "선수금", "예수금", "부가세예수금", "당기법인세부채", "계약부채", "분양선수금", "선수수익", "유동성리스부채"]
OTHER_NCL = ["퇴직급여충당부채", "확정급여부채", "장기미지급금", "임대보증금", "리스부채", "이연법인세부채", "장기선수금", "장기충당부채", "판매보증충당부채"]
SINGLE = {"receivable": ["매출채권"], "payable": ["매입채무"], "loan_st": ["단기대여금"],
          "borrow_st": ["단기차입금", "유동성장기부채", "유동성장기차입금"], "borrow_lt": ["장기차입금", "사채"]}


def eok(v: float) -> str:
    x = abs(v) / EOK
    s = f"{x:,.0f}" if x >= 10 else f"{x:,.1f}".rstrip("0").rstrip(".")
    return f"{s}억"


def _updown(d: float) -> str:
    return "증가" if d > 0 else "감소"


class _Book:
    """계정 → {해: 천원} · 출처"""

    def __init__(self, accounts: dict[str, Any], cur: int):
        self.acc = accounts
        self.cur, self.prev = str(cur), str(cur - 1)

    def get(self, name: str, year: str) -> float | None:
        v = (self.acc.get(name) or {}).get(year)
        return v["value"] if v else None

    def first(self, names: list[str], year: str) -> tuple[str, float] | None:
        for n in names:
            v = self.get(n, year)
            if v is not None:
                return n, v
        return None

    def sum(self, names: list[str], year: str) -> float | None:
        vals = [self.get(n, year) for n in names]
        vals = [v for v in vals if v is not None]
        return sum(vals) if vals else None

    def top(self, names: list[str], k: int = 3, with_delta: bool = False) -> list[str]:
        items = [(n, self.get(n, self.cur), self.get(n, self.prev)) for n in names]
        items = [(n, c, p) for n, c, p in items if c is not None and abs(c) >= MIN]
        items.sort(key=lambda x: -abs(x[1]))
        out = []
        for n, c, p in items[:k]:
            t = f"{n} {eok(c)}"
            if with_delta and p is not None and abs(c - p) >= MIN:
                t += f"({'+' if c > p else '−'}{eok(c - p)})"
            out.append(t)
        return out


def related_party(raw: bytes) -> dict[str, list[tuple[str, float]]]:
    """특수관계자 표에서 상대별 매출·매입·채권·대여금(천원). 「합계」 줄은 뺀다."""
    root = etree.fromstring(raw, etree.XMLParser(recover=True, resolve_entities=False, no_network=True, huge_tree=False))
    out: dict[str, list[tuple[str, float]]] = {"sales": [], "purchase": [], "receivable": [], "loan": []}
    if root is None:
        return out
    for table in root.iter("TABLE"):
        before = _before(table)
        if "특수관계" not in before:
            continue
        rows = [r for r in (_cells(tr) for tr in table.iter("TR")) if r]
        unit = UNIT.findall(before)
        if len(rows) < 2 or not unit:
            continue
        scale = float(SCALE[unit[-1]])
        head = [re.sub(r"\s+", "", h) for h in rows[0]]
        # 「당기」 표만(전기 표는 앞글에 「전기」만 있고 「당기」가 없다)
        if re.search(r"전기", before) and not re.search(r"당기", before):
            continue
        name_col = next((i for i, h in enumerate(head) if re.search(r"회사명|특수관계자명|거래처|성명", h)), 1 if len(head) > 2 else 0)
        cols = {
            "sales": next((i for i, h in enumerate(head) if re.search(r"^매출|매출등|^수익", h)), None),
            "purchase": next((i for i, h in enumerate(head) if re.search(r"^매입|매입등|원재료매입|^비용", h)), None),
            "receivable": next((i for i, h in enumerate(head) if re.search(r"채권", h)), None),
            "loan": next((i for i, h in enumerate(head) if re.search(r"대여", h)), None),
        }
        for row in rows[1:]:
            if name_col >= len(row):
                continue
            who = re.sub(r"\s+", " ", row[name_col]).strip()
            if not who or re.search(r"^합\s*계|^계$|^소\s*계", who) or re.search(r"합\s*계", " ".join(row[:2])):
                continue
            for kind, c in cols.items():
                if c is None or c >= len(row):
                    continue
                v = amount(row[c])
                if v is not None and float(v) * scale >= MIN:
                    out[kind].append((who, float(v) * scale))
    for k in out:
        seen: dict[str, float] = {}
        for who, v in out[k]:
            seen[who] = max(v, seen.get(who, 0))
        out[k] = sorted(seen.items(), key=lambda x: -x[1])
    return out


def note_table(raw: bytes, title: str, exclude: str = r"부가가치") -> dict[str, tuple[float | None, float | None]]:
    """앞글이 `title` 인 주석 표(줄 = 항목, 칸 = 당기·전기) → {항목: (당기, 전기) 천원}. 판관비처럼 다른 주석(부가가치 계산 —
    제조원가 + 판관비)에도 같은 이름이 나오는 것을 가르려고 쓴다."""
    root = etree.fromstring(raw, etree.XMLParser(recover=True, resolve_entities=False, no_network=True, huge_tree=False))
    out: dict[str, tuple[float | None, float | None]] = {}
    if root is None:
        return out
    for table in root.iter("TABLE"):
        before = _before(table)
        flat = re.sub(r"\s+", "", before)
        if not re.search(title, flat) or re.search(exclude, flat):
            continue
        unit = UNIT.findall(before)
        rows = [r for r in (_cells(tr) for tr in table.iter("TR")) if r]
        if not unit or len(rows) < 2:
            continue
        scale = float(SCALE[unit[-1]])
        head = [re.sub(r"\s+", "", h) for h in rows[0]]
        cur = next((i for i, h in enumerate(head) if i and re.search(r"^당기|당기$", h)), None)
        prev = next((i for i, h in enumerate(head) if i and re.search(r"^전기|전기$", h)), None)
        if cur is None:
            continue
        for row in rows[1:]:
            name = _label(row[0])
            if not name or re.search(r"합계|^계$|소계", name):
                continue
            c = amount(row[cur]) if cur < len(row) else None
            p = amount(row[prev]) if prev is not None and prev < len(row) else None
            out.setdefault(name, (float(c) * scale if c is not None else None, float(p) * scale if p is not None else None))
    return out


def comments(raw: bytes, number: str) -> dict[str, str]:
    """비고 칸 문구 — 키: sales·cogs·sga·nonop_inc·nonop_exp·receivable·loan_st·inventory·other_ca·ppe·intangible·
    other_nca·payable·borrow_st·other_cl·borrow_lt·other_ncl"""
    names = sorted(set(SALES + SALES_PARTS + COGS + SGA + NONOP_INC + NONOP_EXP + INVENTORY + OTHER_CA + PPE + INTANGIBLE
                       + OTHER_NCA + OTHER_CL + OTHER_NCL + sum(SINGLE.values(), []) + ["재고자산", "유형자산", "판매비와관리비"]))
    got = account_values(raw, number, names)
    accounts = got["accounts"].get("indi") or got["accounts"].get("con") or {}
    b = _Book(accounts, int(got["current_year"]))
    cur, prev = b.cur, b.prev
    rp = related_party(raw)
    out: dict[str, str] = {}

    def change(names: list[str]) -> tuple[float, float, float] | None:
        c, p = b.sum(names, cur), b.sum(names, prev)
        if c is None or p is None:
            return None
        return c, p, c - p

    # ── 손익 ──
    s = b.first(SALES, cur), b.first(SALES, prev)
    sales_d = None
    if s[0] and s[1]:
        sc, sp = s[0][1], s[1][1]
        sales_d = sc - sp
        parts = [(n, b.get(n, cur), b.get(n, prev)) for n in SALES_PARTS]
        parts = [(n, c - p) for n, c, p in parts if c is not None and p is not None and abs(c - p) >= max(MIN, abs(sp) * 0.03)]
        parts = [x for x in parts if (x[1] > 0) == (sales_d > 0)]
        parts.sort(key=lambda x: -abs(x[1]))
        bits = []
        if abs(sales_d) >= max(MIN, abs(sp) * 0.03):
            if parts:
                bits.append(f"전기 대비 {', '.join(f'{n} {eok(d)}' for n, d in parts[:2])} {_updown(sales_d)}로 매출 {eok(sales_d)} {_updown(sales_d)}")
            else:
                pct = f"({abs(sales_d) / abs(sp) * 100:.0f}%)" if sp else ""
                bits.append(f"전기 대비 매출 {eok(sales_d)}{pct} {_updown(sales_d)}")
        big = [(w, v) for w, v in rp["sales"] if v >= max(MIN, abs(sc) * 0.05)]
        if big:
            bits.append("특수관계자 매출: " + ", ".join(f"{w} {eok(v)}" for w, v in big[:2]))
        if bits:
            out["sales"] = " · ".join(bits)
        cg = b.first(COGS, cur), b.first(COGS, prev)
        if cg[0] and cg[1] and sc and sp:
            r1, r0 = cg[1][1] / sp * 100, cg[0][1] / sc * 100
            if abs(r1 - r0) >= 1:
                out["cogs"] = f"매출원가율 전기 {r1:.1f}% → 당기 {r0:.1f}%"
        if rp["purchase"]:
            big = [(w, v) for w, v in rp["purchase"] if v >= max(MIN, abs(sc) * 0.05)]
            if big:
                out["cogs"] = " · ".join(filter(None, [out.get("cogs"), "특수관계자 매입: " + ", ".join(f"{w} {eok(v)}" for w, v in big[:2])]))
    # 판관비는 「판매비와관리비」 주석 표에서만(부가가치 계산 주석의 급여는 제조원가까지 합친 것), 없으면 본표의 판관비 항목만
    note = note_table(raw, r"판매비와관리비|판매비및관리비|판매비와일반관리비")
    if note:
        items = [(n, c, p) for n, (c, p) in note.items() if c is not None and abs(c) >= MIN]
    else:
        items = [(n, b.get(n, cur), b.get(n, prev)) for n in SGA
                 if (accounts.get(n) or {}).get(cur, {}).get("from") == "본표" and b.get(n, cur) is not None and abs(b.get(n, cur)) >= MIN]
    items.sort(key=lambda x: -abs(x[1]))
    if items:
        out["sga"] = "주요 항목: " + ", ".join(
            f"{n} {eok(c)}" + (f"({'+' if c > p else '−'}{eok(c - p)})" if p is not None and abs(c - p) >= MIN else "") for n, c, p in items[:3])
    for key, names_ in (("nonop_inc", NONOP_INC), ("nonop_exp", NONOP_EXP)):
        top = b.top(names_, 2, with_delta=True)
        if top:
            out[key] = ", ".join(top)

    # ── 재무상태 ──
    rc = change(SINGLE["receivable"])
    if rc and abs(rc[2]) >= max(MIN, abs(rc[1]) * 0.05):
        txt = f"전기말 대비 {eok(rc[2])} {_updown(rc[2])}"
        if sales_d is not None and abs(sales_d) >= MIN and (sales_d > 0) == (rc[2] > 0):
            txt += f"(매출 {eok(sales_d)} {_updown(sales_d)} 영향)"
        out["receivable"] = txt
    if rp["receivable"]:
        big = [(w, v) for w, v in rp["receivable"] if v >= MIN]
        if big:
            out["receivable"] = " · ".join(filter(None, [out.get("receivable"), "특수관계자 채권: " + ", ".join(f"{w} {eok(v)}" for w, v in big[:2])]))
    lo = change(SINGLE["loan_st"])
    bits = []
    if lo and abs(lo[2]) >= MIN:
        bits.append(f"전기말 대비 {eok(lo[2])} {_updown(lo[2])}")
    if rp["loan"]:
        bits.append("특수관계자 대여금: " + ", ".join(f"{w} {eok(v)}" for w, v in rp["loan"][:2]))
    if bits:
        out["loan_st"] = " · ".join(bits)
    inv = b.top(INVENTORY, 3)
    ic = change(["재고자산"])
    if inv or (ic and abs(ic[2]) >= MIN):
        out["inventory"] = " · ".join(filter(None, [", ".join(inv), f"전기말 대비 {eok(ic[2])} {_updown(ic[2])}" if ic and abs(ic[2]) >= MIN else ""]))
    for key, names_ in (("other_ca", OTHER_CA), ("intangible", INTANGIBLE), ("other_nca", OTHER_NCA), ("other_cl", OTHER_CL), ("other_ncl", OTHER_NCL)):
        top = b.top(names_, 3)
        if top:
            out[key] = ", ".join(top)
    ppe = b.top(PPE, 4)
    if ppe:
        moves = all((accounts.get(n.split(" ")[0]) or {}).get(cur, {}).get("from", "").startswith("주석 변동") for n in ppe)
        out["ppe"] = ", ".join(ppe) + ("(순장부금액)" if moves else "")
    pc = change(SINGLE["payable"])
    if pc and abs(pc[2]) >= max(MIN, abs(pc[1]) * 0.05):
        out["payable"] = f"전기말 대비 {eok(pc[2])} {_updown(pc[2])}"
    # 차입금은 항목별로(합계가 같아도 「단기차입금 30억 → 75억 · 유동성장기부채 45억 → 0」처럼 갈아탄 것이 보이게)
    for key in ("borrow_st", "borrow_lt"):
        bits = []
        for n in SINGLE[key]:
            c, p = b.get(n, cur), b.get(n, prev)
            if c is None or p is None or abs(c - p) < MIN:
                continue
            bits.append(f"{n} {eok(p) if p else '0'} → {eok(c) if c else '0'}")
        if bits:
            out[key] = " · ".join(bits)
    return out


# ── 서식에 넣기 ─────────────────────────────────────────────────────────────

ROW_KEYS = {
    "매출채권": "receivable", "단기대여금": "loan_st", "재고자산": "inventory", "기타유동자산": "other_ca", "유형자산": "ppe",
    "무형자산": "intangible", "기타비유동자산": "other_nca", "매입채무": "payable", "단기차입금": "borrow_st",
    "기타유동부채": "other_cl", "장기차입금": "borrow_lt", "기타비유동부채": "other_ncl",
    "매출액": "sales", "매출원가": "cogs", "판매비와관리비": "sga", "영업외수익": "nonop_inc", "영업외비용": "nonop_exp",
}


def place(patch: Any, raw_template: bytes, notes: dict[str, str]) -> list[str]:
    """요약BS·요약PL 시트(일반·K-IFRS 둘 다)의 「비고」 칸에 넣는다. 서식에 남아 있던 예시 글은 지운다."""
    from io import BytesIO
    from openpyxl import load_workbook
    wb = load_workbook(BytesIO(raw_template), read_only=True, data_only=False)
    done: list[str] = []
    try:
        for name in wb.sheetnames:
            if not re.search(r"요약\s*BS|요약\s*PL", name):
                continue
            ws = wb[name]
            note_col, head_row = None, None
            grid = list(ws.iter_rows(min_row=1, max_row=min(ws.max_row or 0, 40), values_only=True))
            for r, row in enumerate(grid, start=1):
                for c, v in enumerate(row, start=1):
                    if v is not None and re.sub(r"\s+", "", str(v)) == "비고":
                        note_col, head_row = c, r
                        break
                if note_col:
                    break
            if not note_col:
                continue
            from openpyxl.utils import get_column_letter
            col = get_column_letter(note_col)
            for r in range(head_row + 1, min(len(grid), head_row + 35) + 1):
                label = grid[r - 1][1] if len(grid[r - 1]) > 1 else None   # B열
                key = ROW_KEYS.get(re.sub(r"[\s()]", "", str(label or "")))
                if not key:
                    continue
                current = grid[r - 1][note_col - 1] if len(grid[r - 1]) >= note_col else None
                text = notes.get(key)
                if text:
                    patch.set(name, f"{col}{r}", text)
                    done.append(f"{name}!{col}{r}")
                elif current not in (None, ""):
                    patch.set(name, f"{col}{r}", None)      # 서식의 예시 글은 지운다
    finally:
        wb.close()
    return done


# ── 1-1.요약BS M~P열: 심사중요성금액의 4배 이상인 계정(사용자 지정 2026-10-15) ───────────────────────────
#
# 입력문서·요약표·중요성금액('1-2.요약PL,CF,중요성'!D41)이 모두 엑셀 수식이라 서버가 값을 정하지 않고 **수식으로** 넣는다.
# 줄마다 「|당기| ≥ 4 × 중요성금액이면 보이기」 조건을 걸고, 줄 차례를 당기 금액이 큰 순으로 두면 보이는 줄이 위에서부터
# 빈칸 없이 이어진다. 정렬에 쓰는 당기 금액만 서버가 작은 계산기(`_Calc`)로 센다.
# 매출액·매출원가·매출채권·매입채무·유형자산(합계)·장단기차입금(단기·유동성장기부채·사채·장기)은 4배 미만이어도 늘 넣는다.
# 다른 계정을 더하고 뺀 줄(합계·「상기외」 차액)·이익잉여금·당기순이익과 괄호 속 세부 줄·대손충당금은 넣지 않는다.

INPUT = "심사조서(일반용)입력문서"
SUMMARY = "1-1.요약BS"
MATERIAL = "'1-2.요약PL,CF,중요성'!$D$41"
ALWAYS = [("매출액", ["매출액"]), ("매출원가", ["매출원가"]), ("매출채권", ["매출채권"]), ("매입채무", ["매입채무"]),
          ("유형자산", ["유형자산"]), ("장단기차입금", ["단기차입금", "유동성장기부채", "사채", "장기차입금"])]
NOT_ACCOUNTS = {"유동자산", "비유동자산", "자산총계", "유동부채", "비유동부채", "부채총계", "자본총계", "부채와자본총계",
                "이익잉여금", "당기순이익", "검증", "재무상태표", "손익계산서", "현금흐름표"}
_REF = re.compile(r"(?:'([^']+)'!|([A-Za-z가-힣0-9_]+)!)?\$?([A-Z]{1,3})\$?(\d+)(?::\$?([A-Z]{1,3})\$?(\d+))?")


class _Calc:
    """+ − × ÷ · SUM · 칸/범위 참조(시트 이름 포함)만 아는 작은 계산기. 모르는 함수가 나오면 None."""

    def __init__(self, wb: Any):
        self.wb, self.memo = wb, {}

    def cell(self, sheet: str, ref: str, depth: int = 0) -> float | None:
        key = (sheet, ref)
        if key in self.memo:
            return self.memo[key]
        self.memo[key] = None
        try:
            v = self.wb[sheet][ref].value
        except KeyError:
            return None
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out = float(v)
        elif isinstance(v, str) and v.startswith("=") and depth < 40:
            out = self.expr(sheet, v[1:], depth + 1)
        else:
            out = 0.0 if v in (None, "") else None
        self.memo[key] = out
        return out

    def _range(self, sheet: str, a: str, b: str, depth: int) -> float | None:
        from openpyxl.utils import column_index_from_string, get_column_letter
        (c1, r1), (c2, r2) = re.match(r"([A-Z]+)(\d+)", a).groups(), re.match(r"([A-Z]+)(\d+)", b).groups()
        total = 0.0
        for c in range(column_index_from_string(c1), column_index_from_string(c2) + 1):
            for r in range(int(r1), int(r2) + 1):
                v = self.cell(sheet, f"{get_column_letter(c)}{r}", depth)
                if v is None:
                    return None
                total += v
        return total

    def expr(self, sheet: str, text: str, depth: int) -> float | None:
        def val(m: re.Match) -> str:
            sh = m.group(1) or m.group(2) or sheet
            if m.group(5):
                v = self._range(sh, f"{m.group(3)}{m.group(4)}", f"{m.group(5)}{m.group(6)}", depth)
            else:
                v = self.cell(sh, f"{m.group(3)}{m.group(4)}", depth)
            if v is None:
                raise ValueError
            return f"({v!r})"
        try:
            body = _REF.sub(val, text.replace("SUM(", "_S(").replace("sum(", "_S("))
        except ValueError:
            return None
        if re.search(r"[A-Za-z가-힣\"]", body.replace("_S", "")):
            return None                         # IF·VLOOKUP 따위 — 모른다
        try:
            return float(eval(body, {"__builtins__": {}}, {"_S": lambda *a: sum(a)}))  # noqa: S307 — 숫자·괄호·사칙연산만 남은 식
        except Exception:  # noqa: BLE001
            return None


def material_list(patch: Any) -> list[str]:
    """1-1.요약BS M5:P… 에 「계정과목 · 당기(말) · 전기(말) · 증감」 수식 줄을 넣는다(서식에 그 시트·입력문서가 있을 때만)."""
    from io import BytesIO
    from openpyxl import load_workbook
    if not (patch.has_sheet(INPUT) and patch.has_sheet(SUMMARY)):
        return []
    wb = load_workbook(BytesIO(patch.to_bytes()), read_only=False, data_only=False)
    ws = wb[INPUT]
    calc = _Calc(wb)
    rows: dict[str, int] = {}
    accounts: list[tuple[str, int]] = []
    for r in range(22, 120):
        label = re.sub(r"\s+", "", str(ws[f"B{r}"].value or ""))
        if label.startswith("현금흐름표"):
            break                               # 재무상태표·손익계산서까지만
        formula = ws[f"C{r}"].value
        if not label or not isinstance(formula, str) or not formula.startswith("="):
            continue
        rows.setdefault(label, r)
        if label in NOT_ACCOUNTS or label.startswith(("(", "-", "※")) or "상기외" in label or "대손충당금" in label:
            continue
        if "!" not in formula:                  # 입력문서 안의 다른 줄을 더하고 뺀 줄(합계·차액)
            continue
        accounts.append((label, r))
    always_rows = {r for _, names in ALWAYS for n in names for r in [rows.get(n)] if r}
    q = f"'{INPUT}'!"
    out_rows: list[tuple[str, str, str, bool]] = []      # (이름, 당기 식, 전기 식, 늘)
    for name, names in ALWAYS:
        rs = [rows[n] for n in names if n in rows]
        if rs:
            out_rows.append((name, "+".join(f"{q}C{r}" for r in rs), "+".join(f"{q}D{r}" for r in rs), True))
    cand = [(label, r, abs(calc.cell(INPUT, f"C{r}") or 0)) for label, r in accounts if r not in always_rows]
    cand.sort(key=lambda x: -x[2])
    for label, r, _ in cand:
        name = re.sub(r"\(.*?\)", "", label).replace("계속사업손익법인세비용", "법인세비용")   # 「재고자산(평가충 차감후)」 → 「재고자산」
        out_rows.append((name, f"{q}C{r}", f"{q}D{r}", False))

    num = patch.number_style()
    done = []
    for col, head in zip("MNOP", ("계정과목", "당기(말)", "전기(말)", "증감")):
        patch.set(SUMMARY, f"{col}5", head)
    for i, (name, cur, prev, always) in enumerate(out_rows):
        r = 6 + i
        if always:
            patch.set(SUMMARY, f"M{r}", name)
        else:
            patch.set_formula(SUMMARY, f"M{r}", f'IF(ABS({cur})>=4*{MATERIAL},"{name}","")')
        show = f'IF($M{r}="","",' if not always else "("
        patch.set_formula(SUMMARY, f"N{r}", f"{show}{cur})", num)
        patch.set_formula(SUMMARY, f"O{r}", f"{show}{prev})", num)
        patch.set_formula(SUMMARY, f"P{r}", f'IF($M{r}="","",N{r}-O{r})', num)
        done.append(f"{SUMMARY}!M{r}")
    return done
