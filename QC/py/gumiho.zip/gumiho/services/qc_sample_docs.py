"""[품감] 제출자료 대사(개발) — 엑셀 밖의 제출자료(PDF·워드·한글)에서 맞춰 볼 값을 뽑는다 (2026-10-14).

모델을 쓰지 않는다. 회사 문서를 밖으로 보내지 않는다는 원칙(마스킹과 같은 원칙)이라 규칙으로만 읽는다:

    감사보고서   「감사보고서일(2026년 3월 20일)」 · 의견 머리(한정의견 근거 …) · 「업무수행이사는 ○○○」 ·
                 「20XX년 X월 X일 현재」(재무상태표일)
    그 밖의 문서 글자 수와, 2-3 현황의 회사 중 본문에 가장 많이 나온 회사

글자는 PDF·워드는 MarkItDown(`review2.targets._markitdown`, 바깥 모델 없이), 한글은 `attachment_text`
(HWPX=section*.xml, 옛 HWP=rhwp)가 뽑는다. 대사하려고 내용을 읽을 뿐, 원문 보존·마스킹 대상이 아니다. 올린 파일은 메모리에서 읽고 버린다.
"""
from __future__ import annotations

import html
import io
import re
import zipfile
from typing import Any

from gumiho.services import attachment_text, company_name

DOC_SUFFIXES = (".pdf", ".hwpx", ".hwp", ".docx")
_YMD = r"(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일"


def _docx_text(data: bytes) -> str:
    try:
        xml = zipfile.ZipFile(io.BytesIO(data)).read("word/document.xml").decode("utf-8", "replace")
    except (zipfile.BadZipFile, KeyError) as exc:
        raise attachment_text.AttachmentTextError("워드(.docx) 본문을 찾지 못했습니다.") from exc
    lines = []
    for para in re.split(r"<w:p[ >]", xml):
        runs = re.findall(r"<w:t[^>]*>(.*?)</w:t>", para, re.S)
        line = "".join(html.unescape(r) for r in runs).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


async def read_text(data: bytes, name: str) -> str:
    """PDF·워드는 MarkItDown 으로 읽는다(사용자 지정 2026-10-14 — [오류검증(검토)2]가 쓰는 같은 함수,
    바깥 모델 연결 없이). 대사용으로 **내용을 읽기만** 한다 — 원문 보존·마스킹 대상이 아니다.
    MarkItDown 이 못 읽는 PDF 는 pdftotext 로, 한글(hwpx/hwp)은 `attachment_text` 로 읽는다."""
    import asyncio
    from gumiho.services.review2.targets import _markitdown
    low = name.lower()
    suf = ".pdf" if low.endswith(".pdf") or data[:4] == b"%PDF" else ".docx" if (
        low.endswith(".docx") or "word/document.xml" in _names(data)) else ""
    if suf:
        try:
            text = await asyncio.to_thread(_markitdown, data, suf)
            if text.strip():
                return text
        except Exception:  # noqa: BLE001 — 아래 읽개로 한 번 더
            pass
        if suf == ".docx":
            return _docx_text(data)
    return await attachment_text.extract_text(data, label=name)


def _names(data: bytes) -> list[str]:
    try:
        return zipfile.ZipFile(io.BytesIO(data)).namelist()
    except zipfile.BadZipFile:
        return []


def _ymd(m: re.Match[str]) -> str:
    return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"


def facts(text: str) -> dict[str, Any]:
    """감사보고서로 보이면 보고서일·의견·업무수행이사·재무상태표일을 뽑는다. 못 찾은 값은 None."""
    flat = re.sub(r"[ \t]+", " ", text or "")
    head = flat[:4000]
    is_report = "감사보고서" in head and ("감사의견" in flat or "의견거절" in flat)
    out: dict[str, Any] = {"type": "감사보고서" if is_report else "기타", "report_date": None,
                           "opinion": None, "partner": None, "period_end": None}
    if not is_report:
        return out
    m = re.search(r"감사보고서일\s*[(（]?\s*" + _YMD, flat)
    if m:
        out["report_date"] = _ymd(m)
    if re.search(r"의견\s*거절\s*근거|의견을\s*표명하지\s*않", flat):
        out["opinion"] = "의견거절"
    elif re.search(r"부적정\s*의견\s*근거", flat):
        out["opinion"] = "부적정"
    elif re.search(r"한정\s*의견\s*근거", flat):
        out["opinion"] = "한정"
    elif re.search(r"감사의견\s*근거", flat) or "공정하게 표시하고 있습니다" in flat:
        out["opinion"] = "적정"
    m = re.search(r"업무수행이사는\s*([가-힣]{2,4}?)\s*(?:입니다|이다|임|\.|$)", flat, re.M)
    if m:
        out["partner"] = m.group(1)
    m = re.search(_YMD + r"\s*(현재|로\s*종료)", flat)
    if m:
        out["period_end"] = _ymd(m)
    return out


def best_company(text: str, names: list[str]) -> tuple[str | None, int]:
    """2-3 회사 중 본문에 가장 많이 나온 것. 두 번 이상 나와야 고른다."""
    flat = re.sub(r"\s+", "", text or "").lower()
    best, hits = None, 0
    for name in dict.fromkeys(n for n in names if n):
        core = company_name.name_key(name)
        if len(core) < 2:
            continue
        n = flat.count(core)
        if n > hits:
            best, hits = name, n
    return (best, hits) if hits >= 2 else (None, hits)


# ── 변형의견 사유(한정·부적정·의견거절 근거) ─────────────────────────────────
_BASIS_HEAD = re.compile(r"(한정\s*의견|부적정\s*의견|의견\s*거절)\s*(?:의\s*)?근거")
_NEXT_HEAD = re.compile(r"\n\s*(?:#+\s*)?(핵심\s*감사\s*사항|강조\s*사항|기타\s*사항|계속기업\s*관련\s*중요한\s*불확실성|"
                        r"재무제표에\s*대한\s*경영진|감사인의\s*책임|재무제표\s*감사에\s*대한\s*감사인|"
                        r"기타\s*법규|이\s*감사보고서의\s*근거가)")
# 초도 수임에 따른 기초잔액 범위제한 — 흔하고 그 자체로 중요한 특이사항은 아니다(사용자 지정 2026-10-14).
_ROUTINE = [
    re.compile(r"(선임|수임|최초\s*감사|초도).{0,120}(재고|기초\s*잔액|전기말|기초)"),
    re.compile(r"(재고자산\s*실사|실사에\s*입회).{0,80}(입회할\s*수\s*없|입회하지\s*못|참관할\s*수\s*없)"),
    re.compile(r"기초\s*(재고자산|잔액).{0,80}(충분하고\s*적합한\s*감사증거를\s*입수할\s*수\s*없)"),
]


def opinion_basis(text: str) -> dict[str, Any]:
    """감사보고서 원문 → {opinion, text(근거 단락, 1500자까지), routine(초도 범위제한 같은 일반적 사유)}."""
    flat = re.sub(r"[ \t]+", " ", text or "")
    m = _BASIS_HEAD.search(flat)
    if not m:
        return {"opinion": None, "text": "", "routine": False}
    word = re.sub(r"\s+", "", m.group(1))
    opinion = "의견거절" if "거절" in word else "부적정" if "부적정" in word else "한정"
    body = flat[m.end():]
    nxt = _NEXT_HEAD.search(body)
    body = (body[: nxt.start()] if nxt else body[:3000]).strip()
    body = re.sub(r"\n{2,}", "\n", body)[:1500]
    hits = sum(1 for r in _ROUTINE if r.search(body))
    routine = opinion == "한정" and hits >= 2
    return {"opinion": opinion, "text": body, "routine": routine}
